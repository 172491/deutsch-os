-- Deutsch OS 1.7.1 incremental migration.
alter table if exists public.words add column if not exists introduced_on date;
create index if not exists words_user_introduced_idx on public.words(user_id, introduced_on);


-- V1.7.1: separate personal intake from textbook intake and persist effective study time.
alter table if exists public.user_settings add column if not exists daily_personal_new integer not null default 5;

create table if not exists public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  seconds integer not null check (seconds > 0),
  started_at timestamptz not null,
  ended_at timestamptz not null,
  created_at timestamptz not null default now()
);
alter table public.study_sessions enable row level security;
drop policy if exists "users own study sessions" on public.study_sessions;
create policy "users own study sessions" on public.study_sessions for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create index if not exists study_sessions_user_date_idx on public.study_sessions(user_id, date desc);

grant select, insert, update, delete on public.study_sessions to authenticated;
