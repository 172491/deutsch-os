-- Deutsch OS 1.7.2: 16-week Goethe B2 sprint tracking.
alter table if exists public.user_settings add column if not exists b2_sprint_enabled boolean not null default true;
alter table if exists public.user_settings add column if not exists b2_target_date date not null default (current_date + 120);
alter table if exists public.user_settings add column if not exists b2_current_level text not null default 'A1';
alter table if exists public.user_settings add column if not exists b2_daily_minutes integer not null default 240;

do $$
begin
  alter table public.user_settings add constraint user_settings_b2_current_level_check check (b2_current_level in ('A1','A2','B1','B2-'));
exception
  when duplicate_object then null;
end $$;

create table if not exists public.b2_practice_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  area text not null check (area in ('vocabulary','grammar','reading','listening','writing','speaking')),
  kind text not null check (kind in ('drill','timed','mock')),
  minutes integer not null check (minutes > 0 and minutes <= 600),
  score double precision check (score is null or (score >= 0 and score <= 100)),
  note text,
  created_at timestamptz not null default now()
);

alter table public.b2_practice_sessions enable row level security;
drop policy if exists "users own b2 practice sessions" on public.b2_practice_sessions;
create policy "users own b2 practice sessions" on public.b2_practice_sessions
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create index if not exists b2_practice_user_date_idx on public.b2_practice_sessions(user_id, date desc);
grant select, insert, update, delete on public.b2_practice_sessions to authenticated;
