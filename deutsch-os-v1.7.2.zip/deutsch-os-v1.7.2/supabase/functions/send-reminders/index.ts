import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'npm:@supabase/supabase-js@2'
import webpush from 'npm:web-push@3.6.7'

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const secretKeys = Deno.env.get('SUPABASE_SECRET_KEYS')
let serviceRole = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
if (secretKeys) {
  try { serviceRole = JSON.parse(secretKeys).default || serviceRole } catch { /* legacy fallback below */ }
}
if (!serviceRole) throw new Error('Missing Supabase secret/service-role key')
const vapidPublic = Deno.env.get('VAPID_PUBLIC_KEY')!
const vapidPrivate = Deno.env.get('VAPID_PRIVATE_KEY')!
const vapidSubject = Deno.env.get('VAPID_SUBJECT') || 'mailto:you@example.com'

webpush.setVapidDetails(vapidSubject, vapidPublic, vapidPrivate)
const admin = createClient(supabaseUrl, serviceRole, { auth: { persistSession: false } })

Deno.serve(async () => {
  const { data: candidates, error } = await admin.rpc('reminder_candidates', { at_time: new Date().toISOString() })
  if (error) return Response.json({ ok: false, error: error.message }, { status: 500 })

  let sent = 0
  for (const candidate of candidates || []) {
    const { data: subscriptions } = await admin.from('push_subscriptions').select('*').eq('user_id', candidate.user_id)
    let delivered = false
    for (const sub of subscriptions || []) {
      try {
        await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify({
          title: 'Deutsch · 学习提醒',
          body: `现在有 ${candidate.due_count} 个复习项目等待完成。`,
          tag: 'deutsch-daily-reminder',
          url: '/',
        }))
        delivered = true
        sent += 1
      } catch (err: any) {
        if (err?.statusCode === 404 || err?.statusCode === 410) {
          await admin.from('push_subscriptions').delete().eq('id', sub.id)
        } else console.error('push failed', err)
      }
    }
    if (delivered) await admin.from('user_settings').update({ last_reminded_at: new Date().toISOString() }).eq('user_id', candidate.user_id)
  }
  return Response.json({ ok: true, users: candidates?.length || 0, sent })
})
