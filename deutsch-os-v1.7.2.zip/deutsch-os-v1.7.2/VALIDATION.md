# Deutsch OS 1.7.2 — validation record

Release validation performed on 2026-09-01.

## Passed

- Original textbook JSON integrity: 4563 / 4563 entries unchanged; 3430 `study_ready`.
- Per-book counts: 1162/917, 1270/1032, 976/807, 1155/674 (total / study_ready).
- Original `src/data/textbook-v13.json` SHA-256 is unchanged from 1.7.1.
- Content layer: 153 manual gloss overrides; 176 curated example lemmas; Vorkurs 50/50 example coverage.
- Textbook units preserve the stored source order and stay at <=18 study-ready entries per unit.
- B2 layer contains four exam modules, four phases and 16 milestones.
- Goethe B2 module durations encoded in the UI: Lesen 65, Hören 40, Schreiben 75, Sprechen 15 minutes.
- 120-day runway maps from stage/week 1 to stage/week 16.
- A 240-minute Phase-1 plan contains vocabulary, grammar, reading, listening, writing and speaking; current allocation totals 235 minutes because task lengths are rounded to 5-minute blocks.
- A weak scored module receives no less daily allocation than the same plan without the weak score signal.
- A1 recommended new-word intensity is higher than A2, which is higher than B1; this is an internal heuristic, not a Goethe vocabulary requirement.
- Today-page vocabulary queue includes not-yet-introduced textbook/personal intake instead of showing 0 and adding words only after click-through.
- Reader receives `settings` and can date newly added words in the configured timezone.
- Cloud-newer FSRS cards win during cross-device merge; local-newer cards are uploaded.
- Obsolete visible `daily_goal_minutes` control is removed; the field remains only for 1.x data compatibility.
- All 13 TS/TSX source files (excluding `.d.ts`) pass TypeScript `transpileModule` syntax diagnostics.
- Service Worker cache key and package version are 1.7.2.
- Final ZIP integrity checked with `unzip -t`.

## Not claimed

This sandbox could not complete `npm install` from the npm registry within the allowed network window, so a dependency-resolved `npm run check` / `npm run build` was not completed here. The source-level TypeScript checks above do **not** replace the first real Cloudflare build. The first Pages deployment should therefore be treated as the final dependency/build-environment verification.
