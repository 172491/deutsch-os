import { supabase } from './supabase'

export function notificationSupport() {
  return typeof window !== 'undefined' && 'Notification' in window && 'serviceWorker' in navigator
}

async function ensureServiceWorker() {
  const existing = await navigator.serviceWorker.getRegistration()
  return existing || navigator.serviceWorker.register('/sw.js')
}

export async function requestNotificationPermission() {
  if (!notificationSupport()) return 'unsupported' as const
  await ensureServiceWorker()
  return Notification.requestPermission()
}

export async function showTestNotification(dueCount = 0) {
  const permission = await requestNotificationPermission()
  if (permission !== 'granted') return permission
  await ensureServiceWorker()
  const registration = await navigator.serviceWorker.ready
  await registration.showNotification('Deutsch · 学习提醒', {
    body: dueCount ? `现在有 ${dueCount} 个复习项目等待完成。` : '系统通知已经可以正常显示。',
    icon: '/icon.svg',
    badge: '/icon.svg',
    tag: 'deutsch-test',
    data: { url: '/' },
  })
  return 'shown' as const
}

function base64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(base64)
  return Uint8Array.from([...raw].map(ch => ch.charCodeAt(0)))
}

export async function enableWebPush(userId: string) {
  const publicKey = import.meta.env.VITE_VAPID_PUBLIC_KEY as string | undefined
  if (!publicKey) throw new Error('尚未配置 VITE_VAPID_PUBLIC_KEY')
  if (!supabase) throw new Error('Web Push 需要先启用 Supabase 云端同步')
  const permission = await requestNotificationPermission()
  if (permission !== 'granted') throw new Error('没有获得系统通知权限')
  await ensureServiceWorker()
  const registration = await navigator.serviceWorker.ready
  const existing = await registration.pushManager.getSubscription()
  const subscription = existing || await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: base64ToUint8Array(publicKey),
  })
  const json = subscription.toJSON()
  const { error } = await supabase.from('push_subscriptions').upsert({
    user_id: userId,
    endpoint: subscription.endpoint,
    p256dh: json.keys?.p256dh || '',
    auth: json.keys?.auth || '',
    user_agent: navigator.userAgent,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,endpoint' })
  if (error) throw error
  return subscription
}

export async function disableWebPush(userId: string) {
  if (!supabase) return
  await ensureServiceWorker()
  const registration = await navigator.serviceWorker.ready
  const subscription = await registration.pushManager.getSubscription()
  if (subscription) {
    await supabase.from('push_subscriptions').delete().eq('user_id', userId).eq('endpoint', subscription.endpoint)
    await subscription.unsubscribe()
  }
}
