import rawLexicon from './data/de-core.json'
import type { LexiconEntry, Word } from './types'

export const coreLexicon = rawLexicon as unknown as LexiconEntry[]

export const lexiconStats = {
  total: coreLexicon.length,
  translated: coreLexicon.filter(x => Boolean(x.gloss_zh)).length,
  a1: coreLexicon.filter(x => x.level === 'A1').length,
  a2: coreLexicon.filter(x => x.level === 'A2').length,
  b1: coreLexicon.filter(x => x.level === 'B1').length,
}

export function lexiconDisplay(entry: LexiconEntry) {
  return `${entry.article ? `${entry.article} ` : ''}${entry.lemma}`
}

export function lexiconToWord(entry: LexiconEntry): Word {
  const now = new Date().toISOString()
  return {
    id: crypto.randomUUID(),
    lemma: entry.lemma,
    article: entry.article,
    plural: entry.plural,
    part_of_speech: entry.pos_zh,
    translation: entry.gloss_zh,
    example_de: '',
    example_zh: '',
    level: entry.level,
    source: 'Deutsch OS 基础词库',
    source_note: `WordHoard Top 2000 · frequency rank #${entry.frequency_rank} · ${entry.license}`,
    tags: ['基础词库', entry.level, entry.pos_zh].filter(Boolean),
    status: 'new',
    due_at: now,
    interval_days: 0,
    ease: 2.5,
    meaning_score: 0,
    article_score: 0,
    plural_score: 0,
    spelling_score: 0,
    created_at: now,
    updated_at: now,
  }
}

function norm(s: string) {
  return s.toLocaleLowerCase('de-DE').replace(/[„“”"'’.,;:!?()[\]{}]/g, '')
}

const lemmaIndex = new Map<string, LexiconEntry>()
const formIndex = new Map<string, LexiconEntry>()
for (const entry of coreLexicon) {
  const lemmaKey = norm(entry.lemma)
  if (!lemmaIndex.has(lemmaKey)) lemmaIndex.set(lemmaKey, entry)
  for (const values of Object.values(entry.forms || {})) {
    for (const form of values) {
      const key = norm(form)
      if (key && !formIndex.has(key)) formIndex.set(key, entry)
    }
  }
}

export function lookupLexiconToken(token: string) {
  const t = norm(token)
  const exact = lemmaIndex.get(t)
  if (exact) return { entry: exact, reason: '基础词库原形匹配', confidence: 1 }
  const inflected = formIndex.get(t)
  if (inflected) return { entry: inflected, reason: '基础词库词形匹配', confidence: .99 }
  return null
}

export function isInPersonalLexicon(entry: LexiconEntry, words: Word[]) {
  const lemma = norm(entry.lemma)
  return words.some(w => norm(w.lemma) === lemma)
}
