import type { Word } from './types'

const irregular: Record<string, string[]> = {
  bin: ['sein'], bist: ['sein'], ist: ['sein'], sind: ['sein'], seid: ['sein'], war: ['sein'], waren: ['sein'], gewesen: ['sein'],
  habe: ['haben'], hast: ['haben'], hat: ['haben'], haben: ['haben'], hatte: ['haben'], hatten: ['haben'], gehabt: ['haben'],
  werde: ['werden'], wirst: ['werden'], wird: ['werden'], werden: ['werden'], wurde: ['werden'], wurden: ['werden'], geworden: ['werden'],
  gehe: ['gehen'], gehst: ['gehen'], geht: ['gehen'], ging: ['gehen'], gingen: ['gehen'], gegangen: ['gehen'],
  lese: ['lesen'], liest: ['lesen'], las: ['lesen'], lasen: ['lesen'], gelesen: ['lesen'],
  spreche: ['sprechen'], sprichst: ['sprechen'], spricht: ['sprechen'], sprach: ['sprechen'], sprachen: ['sprechen'], gesprochen: ['sprechen'],
  sehe: ['sehen'], siehst: ['sehen'], sieht: ['sehen'], sah: ['sehen'], sahen: ['sehen'], gesehen: ['sehen'],
}

function norm(s: string) { return s.toLocaleLowerCase('de-DE').replace(/[„“”"'’.,;:!?()[\]{}]/g, '') }

export function resolveToken(token: string, words: Word[]) {
  const t = norm(token)
  const exact = words.find(w => norm(w.lemma) === t)
  if (exact) return { word: exact, lemma: exact.lemma, confidence: 1, reason: '原形匹配' }

  const plural = words.find(w => w.plural && norm(w.plural) === t)
  if (plural) return { word: plural, lemma: plural.lemma, confidence: .99, reason: '复数匹配' }

  for (const lemma of irregular[t] || []) {
    const word = words.find(w => norm(w.lemma) === norm(lemma))
    if (word) return { word, lemma: word.lemma, confidence: .98, reason: '常见不规则变化' }
  }

  for (const candidate of candidates(t)) {
    const word = words.find(w => norm(w.lemma) === candidate)
    if (word) return { word, lemma: word.lemma, confidence: .78, reason: '规则词形还原' }
  }

  const guess = candidates(t)[0] || token
  return { word: undefined, lemma: preserveNounCase(token, guess), confidence: .35, reason: '规则推测，需核对' }
}

function candidates(t: string) {
  const set = new Set<string>()
  // Finite verb -> infinitive.
  for (const suffix of ['est', 'st', 'et', 't', 'e']) {
    if (t.endsWith(suffix) && t.length > suffix.length + 2) set.add(t.slice(0, -suffix.length) + 'en')
  }
  if (t.endsWith('n') && !t.endsWith('en')) set.add(t + 'en')
  if (t.startsWith('ge') && t.endsWith('t') && t.length > 5) set.add(t.slice(2, -1) + 'en')
  if (t.startsWith('ge') && t.endsWith('en') && t.length > 6) set.add(t.slice(2))

  // Adjective / weak noun endings, checked only against the user's known lemmas.
  for (const suffix of ['ern', 'en', 'em', 'er', 'es', 'e', 'n', 's']) {
    if (t.endsWith(suffix) && t.length > suffix.length + 2) set.add(t.slice(0, -suffix.length))
  }
  set.add(t)
  return [...set]
}

function preserveNounCase(original: string, guess: string) {
  return /^[A-ZÄÖÜ]/.test(original) ? guess.charAt(0).toLocaleUpperCase('de-DE') + guess.slice(1) : guess
}

export function sentenceAround(text: string, token: string) {
  const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const match = text.match(new RegExp(`[^.!?]*\\b${escaped}\\b[^.!?]*[.!?]?`, 'i'))
  return match?.[0].trim() || ''
}
