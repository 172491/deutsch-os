export type ReviewRating = 'again' | 'hard' | 'good' | 'easy'
export type ReviewMode = 'meaning' | 'article' | 'plural' | 'spelling' | 'conjugation'
export type B2TrainingArea = 'vocabulary' | 'grammar' | 'reading' | 'listening' | 'writing' | 'speaking'
export type B2PracticeKind = 'drill' | 'timed' | 'mock'

export type VerbForms = {
  present?: string[]
  praeteritum?: string
  partizip_ii?: string
  auxiliary?: string
  separable_prefix?: string
}

export type Word = {
  id: string
  user_id?: string
  lemma: string
  article?: 'der' | 'die' | 'das' | ''
  plural?: string
  part_of_speech: string
  translation: string
  example_de?: string
  example_zh?: string
  level?: string
  source?: string
  source_note?: string
  tags?: string[]
  textbook_entry_id?: string
  verb_forms?: VerbForms
  status: 'new' | 'learning' | 'mastered'
  due_at: string
  interval_days: number
  ease: number
  meaning_score: number
  article_score: number
  plural_score: number
  spelling_score: number
  created_at: string
  updated_at: string
  /** ISO date when this word was intentionally introduced into the daily learning queue. */
  introduced_on?: string
}

export type MemoryCard = {
  id: string
  user_id?: string
  word_id: string
  mode: ReviewMode
  due_at: string
  stability: number
  difficulty: number
  elapsed_days: number
  scheduled_days: number
  learning_steps: number
  reps: number
  lapses: number
  state: number
  last_review?: string | null
  created_at: string
  updated_at: string
}

export type B2PracticeSession = {
  id: string
  user_id?: string
  date: string
  area: B2TrainingArea
  kind: B2PracticeKind
  minutes: number
  score?: number
  note?: string
  created_at: string
}

export type StudySession = {
  id: string
  user_id?: string
  date: string
  seconds: number
  started_at: string
  ended_at: string
}

export type ReviewEvent = {
  id: string
  user_id?: string
  word_id: string
  mode: ReviewMode
  rating: ReviewRating
  reviewed_at: string
  due_before: string
  due_after: string
  scheduled_days: number
  stability: number
  difficulty: number
}

export type Settings = {
  /** Daily textbook intake. Personal words have a separate intake quota. */
  daily_new: number
  daily_personal_new: number
  reminder_time: string
  reminder_enabled: boolean
  push_enabled: boolean
  daily_goal_minutes: number
  timezone: string
  request_retention: number
  textbook_plan_enabled: boolean
  active_textbook_book: number
  active_textbook_lesson: number
  active_textbook_unit: number
  /** Kept for migration compatibility; this now means “only auto-study checked study_ready entries”. */
  textbook_only_translated: boolean
  /** 16-week Goethe B2 sprint layer. */
  b2_sprint_enabled: boolean
  b2_target_date: string
  b2_current_level: 'A1' | 'A2' | 'B1' | 'B2-'
  b2_daily_minutes: number
}


export type GrammarItem = {
  id: string
  title: string
  subtitle: string
  level: string
  progress: number
  example: string
}

export type ImportDraft = {
  lemma: string
  article: 'der' | 'die' | 'das' | ''
  plural: string
  translation: string
  part_of_speech: string
  source: string
}

export type LexiconEntry = {
  id: string
  lemma: string
  pos: string
  pos_zh: string
  article: 'der' | 'die' | 'das' | ''
  plural: string
  level: 'A1' | 'A2' | 'B1' | string
  frequency_rank: number
  frequency_count: number
  gloss_zh: string
  forms: Record<string, string[]>
  source: string
  license: string
}

export type TextbookEntry = {
  id: string
  book: number
  lesson: number
  lesson_title: string
  order: number
  lemma: string
  article: 'der' | 'die' | 'das' | ''
  article_label: string
  plural: string
  pos: string
  pos_zh: string
  core_level?: string
  level: string
  level_is_estimate: boolean
  gloss_zh: string
  gloss_source?: string
  verb_forms: VerbForms
  textbook_notation: string
  source: string
  source_note: string
  study_ready?: boolean
  quality_note?: string
  example_de?: string
  example_zh?: string
  morphology_source?: string
  vocab_page?: number
}
