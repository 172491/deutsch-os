import type { GrammarItem, Word } from './types'

const now = new Date()
const past = (days = 0) => new Date(now.getTime() - days * 86400000).toISOString()
const future = (days: number) => new Date(now.getTime() + days * 86400000).toISOString()

export const demoWords: Word[] = [
  {
    id: 'w1', lemma: 'Staat', article: 'der', plural: 'Staaten', part_of_speech: '名词', translation: '国家；国家政体',
    example_de: 'Der Staat ist mehr als eine bloße Maschine.', example_zh: '国家不只是一台单纯的机器。', level: 'A1', source: 'Demo · 基础示例', tags: ['政治', '核心词'],
    status: 'learning', due_at: past(1), interval_days: 2, ease: 2.35, meaning_score: 82, article_score: 61, plural_score: 68, spelling_score: 94,
    created_at: past(14), updated_at: past(2)
  },
  {
    id: 'w2', lemma: 'Gemeinschaft', article: 'die', plural: 'Gemeinschaften', part_of_speech: '名词', translation: '共同体；团体；群体',
    example_de: 'Die politische Gemeinschaft braucht Formen der Verbindung.', example_zh: '政治共同体需要联结的形式。', level: 'A2', source: 'Demo · 学术示例', tags: ['共同体', '学术'],
    status: 'learning', due_at: past(0), interval_days: 3, ease: 2.2, meaning_score: 91, article_score: 72, plural_score: 52, spelling_score: 84,
    created_at: past(12), updated_at: past(3)
  },
  {
    id: 'w3', lemma: 'Verhältnis', article: 'das', plural: 'Verhältnisse', part_of_speech: '名词', translation: '关系；比例；状况',
    example_de: 'Das Verhältnis zwischen Individuum und Gemeinschaft ist zentral.', example_zh: '个体与共同体之间的关系是核心问题。', level: 'B1', source: 'Demo · 学术示例', tags: ['学术'],
    status: 'learning', due_at: past(2), interval_days: 1, ease: 2.1, meaning_score: 76, article_score: 55, plural_score: 47, spelling_score: 64,
    created_at: past(10), updated_at: past(1)
  },
  {
    id: 'w4', lemma: 'Freiheit', article: 'die', plural: 'Freiheiten', part_of_speech: '名词', translation: '自由',
    example_de: 'Freiheit zeigt sich im freien Wechsel.', example_zh: '自由在自由的交往中显现。', level: 'A2', source: 'Demo · 学术示例', tags: ['学术'],
    status: 'mastered', due_at: future(5), interval_days: 12, ease: 2.65, meaning_score: 96, article_score: 96, plural_score: 78, spelling_score: 93,
    created_at: past(20), updated_at: past(4)
  },
  {
    id: 'w5', lemma: 'lesen', article: '', plural: '', part_of_speech: '动词', translation: '阅读；读',
    example_de: 'Ich lese jeden Tag ein wenig Deutsch.', example_zh: '我每天读一点德语。', level: 'A1', source: 'Demo · 基础示例', tags: ['基础'],
    status: 'new', due_at: past(0), interval_days: 0, ease: 2.5, meaning_score: 0, article_score: 100, plural_score: 100, spelling_score: 0,
    created_at: past(1), updated_at: past(1)
  },
  {
    id: 'w6', lemma: 'sprechen', article: '', plural: '', part_of_speech: '动词', translation: '说；讲话',
    example_de: 'Wir sprechen heute Deutsch.', example_zh: '我们今天说德语。', level: 'A1', source: 'Demo · 基础示例', tags: ['基础'],
    status: 'new', due_at: past(0), interval_days: 0, ease: 2.5, meaning_score: 0, article_score: 100, plural_score: 100, spelling_score: 0,
    created_at: past(1), updated_at: past(1)
  }
]

export const grammarItems: GrammarItem[] = [
  { id:'g1', title:'动词第二位 V2', subtitle:'主句先把有限动词位置固定住', level:'A1', progress:0, example:'Heute lerne ich drei Stunden Deutsch.' },
  { id:'g2', title:'第四格 Akkusativ', subtitle:'直接宾语与阳性冠词变化', level:'A1', progress:0, example:'Ich lese jeden Abend einen Artikel.' },
  { id:'g3', title:'第三格 Dativ', subtitle:'间接宾语与常见 Dativ 动词', level:'A1', progress:0, example:'Ich helfe meinem Freund beim Lernen.' },
  { id:'g4', title:'情态动词', subtitle:'können / müssen / sollen / dürfen / wollen', level:'A1', progress:0, example:'Ich muss heute noch einen Text schreiben.' },
  { id:'g5', title:'Perfekt', subtitle:'haben/sein + Partizip II；先掌握口语常用过去时', level:'A1', progress:0, example:'Ich habe gestern zwei Stunden gelernt.' },
  { id:'g6', title:'可分与不可分动词', subtitle:'前缀决定主句位置和 Partizip II', level:'A1', progress:0, example:'Der Kurs fängt um neun Uhr an.' },
  { id:'g7', title:'weil / dass / wenn 从句', subtitle:'从句有限动词放到句末', level:'A2', progress:0, example:'Ich lerne weiter, obwohl ich müde bin.' },
  { id:'g8', title:'Wechselpräpositionen', subtitle:'位置 Dativ，方向 Akkusativ', level:'A2', progress:0, example:'Das Buch liegt auf dem Tisch; ich lege es auf den Tisch.' },
  { id:'g9', title:'形容词词尾', subtitle:'先按冠词类型判断，再看格与性数', level:'A2', progress:0, example:'Ich suche einen ruhigen Ort zum Lernen.' },
  { id:'g10', title:'反身动词与代词', subtitle:'sich erinnern / sich interessieren 等高频结构', level:'A2', progress:0, example:'Ich interessiere mich für deutsche Literatur.' },
  { id:'g11', title:'关系从句', subtitle:'关系代词的格由从句内部功能决定', level:'B1', progress:0, example:'Das ist ein Thema, über das häufig diskutiert wird.' },
  { id:'g12', title:'Konjunktiv II', subtitle:'假设、建议、礼貌请求', level:'B1', progress:0, example:'Wenn ich mehr Zeit hätte, würde ich täglich sprechen.' },
  { id:'g13', title:'被动态 Passiv', subtitle:'werden + Partizip II；关注过程而非行动者', level:'B1', progress:0, example:'In vielen Städten wird über den Verkehr diskutiert.' },
  { id:'g14', title:'Infinitiv mit zu', subtitle:'um ... zu / ohne ... zu / statt ... zu', level:'B1', progress:0, example:'Man kann viel lernen, ohne jedes Wort zu übersetzen.' },
  { id:'g15', title:'连接词与语序', subtitle:'deshalb / trotzdem / außerdem 与 obwohl / während', level:'B1', progress:0, example:'Die Methode ist anstrengend; trotzdem ist sie wirksam.' },
  { id:'g16', title:'间接问句', subtitle:'ob / W-Frage + 从句语序', level:'B1', progress:0, example:'Ich möchte wissen, ob der Kurs noch Plätze hat.' },
  { id:'g17', title:'复杂让步与对比', subtitle:'obwohl / während / wohingegen / dennoch', level:'B2', progress:0, example:'Während manche dafür sind, lehnen andere den Vorschlag ab.' },
  { id:'g18', title:'原因、结果与条件', subtitle:'zumal / sodass / sofern / falls / vorausgesetzt, dass', level:'B2', progress:0, example:'Die Maßnahme ist sinnvoll, sofern sie richtig umgesetzt wird.' },
  { id:'g19', title:'名词化 Nominalisierung', subtitle:'把动词/从句压缩成书面语结构', level:'B2', progress:0, example:'Durch die Einführung flexibler Arbeitszeiten lässt sich Zeit sparen.' },
  { id:'g20', title:'被动替代表达', subtitle:'sich lassen + Infinitiv / sein + zu + Infinitiv', level:'B2', progress:0, example:'Das Problem lässt sich nicht leicht lösen.' },
  { id:'g21', title:'Konjunktiv I 间接引语', subtitle:'理解新闻与转述；输出先掌握高频形式', level:'B2', progress:0, example:'Die Expertin sagt, die Maßnahme sei notwendig.' },
  { id:'g22', title:'Mittelfeld 语序', subtitle:'代词、时间、原因、方式、地点与否定成分的自然排序', level:'B2', progress:0, example:'Ich habe mich gestern wegen der Prüfung lange in der Bibliothek vorbereitet.' },
  { id:'g23', title:'功能动词结构', subtitle:'eine Entscheidung treffen / zur Verfügung stehen 等书面表达', level:'B2', progress:0, example:'Die Universität stellt den Studierenden neue Räume zur Verfügung.' },
  { id:'g24', title:'分词作定语', subtitle:'Partizip I/II 扩展名词短语，重点先读懂', level:'B2', progress:0, example:'Die in der Studie genannten Gründe sind nachvollziehbar.' },
]
