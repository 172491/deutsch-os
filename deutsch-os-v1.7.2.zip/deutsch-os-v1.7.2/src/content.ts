import { coreLexicon } from './lexicon'
import type { TextbookEntry } from './types'

type ContentOverride = Partial<Pick<TextbookEntry, 'lemma' | 'article' | 'plural' | 'pos' | 'pos_zh' | 'gloss_zh' | 'study_ready' | 'quality_note'>> & {
  example_de?: string
  example_zh?: string
}

const byLemma: Record<string, ContentOverride> = {
  'abschied': { gloss_zh: '告别；离别', example_de: 'Der Abschied fällt uns schwer.', example_zh: '这次告别让我们很难过。' },
  'ah': { gloss_zh: '啊；哦', example_de: 'Ah, jetzt verstehe ich.', example_zh: '啊，我现在明白了。' },
  'alle': { gloss_zh: '所有人；全部', example_de: 'Alle lernen heute Deutsch.', example_zh: '大家今天都在学德语。' },
  'alt': { gloss_zh: '老的；旧的；……岁的', example_de: 'Wie alt bist du?', example_zh: '你多大了？' },
  'alter': { gloss_zh: '年龄', example_de: 'Bitte geben Sie Ihr Alter an.', example_zh: '请填写您的年龄。' },
  'arbeiten': { gloss_zh: '工作；劳动', example_de: 'Ich arbeite heute zu Hause.', example_zh: '我今天在家工作。' },
  'bald': { gloss_zh: '很快；不久', example_de: 'Bis bald!', example_zh: '回头见！' },
  'beruf': { gloss_zh: '职业', example_de: 'Was sind Sie von Beruf?', example_zh: '您的职业是什么？' },
  'brille': { gloss_zh: '眼镜', example_de: 'Ich brauche meine Brille.', example_zh: '我需要我的眼镜。' },
  'buchstabieren': { gloss_zh: '拼写；逐字母拼读', example_de: 'Können Sie Ihren Namen buchstabieren?', example_zh: '您能逐字母拼一下您的名字吗？' },
  'dolmetscher': { gloss_zh: '口译员；翻译', example_de: 'Er arbeitet als Dolmetscher.', example_zh: '他从事口译工作。' },
  'du': { gloss_zh: '你', example_de: 'Wo wohnst du?', example_zh: '你住在哪里？' },
  'e-mail': { gloss_zh: '电子邮件', example_de: 'Ich schreibe dir eine E-Mail.', example_zh: '我给你写一封电子邮件。' },
  'familie': { gloss_zh: '家庭；家人', example_de: 'Meine Familie wohnt in China.', example_zh: '我的家人住在中国。' },
  'familienfoto': { gloss_zh: '家庭照片；全家福', example_de: 'Das ist unser Familienfoto.', example_zh: '这是我们的全家福。' },
  'frage': { gloss_zh: '问题；提问', example_de: 'Ich habe eine Frage.', example_zh: '我有一个问题。' },
  'fußball': { gloss_zh: '足球；足球运动', example_de: 'Wir spielen am Wochenende Fußball.', example_zh: '我们周末踢足球。' },
  'geschäftsfrau': { gloss_zh: '女商人；女企业家', example_de: 'Sie ist eine erfolgreiche Geschäftsfrau.', example_zh: '她是一位成功的女企业家。' },
  'hausfrau': { gloss_zh: '家庭主妇', example_de: 'Sie ist Hausfrau und arbeitet außerdem in Teilzeit.', example_zh: '她是家庭主妇，同时也做兼职。' },
  'ihr': { gloss_zh: '你们；她的；他们的；她（第三格）', example_de: 'Kommt ihr morgen?', example_zh: '你们明天来吗？' },
  'international': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '国际的；国际化的', example_de: 'Die Universität ist sehr international.', example_zh: '这所大学非常国际化。' },
  'kollege': { gloss_zh: '同事', example_de: 'Mein Kollege kommt aus Berlin.', example_zh: '我的同事来自柏林。' },
  'landkarte': { gloss_zh: '地图', example_de: 'Wo ist München auf der Landkarte?', example_zh: '慕尼黑在地图上的什么位置？' },
  'leben': { gloss_zh: '生活；活着', example_de: 'Meine Großeltern leben auf dem Land.', example_zh: '我的祖父母住在乡下。' },
  'lernen': { gloss_zh: '学习', example_de: 'Ich lerne jeden Tag Deutsch.', example_zh: '我每天学德语。' },
  'mann': { gloss_zh: '男人；丈夫', example_de: 'Der Mann wartet vor der Tür.', example_zh: '那个男人在门外等。' },
  'medizin': { gloss_zh: '医学；药物', example_de: 'Sie studiert Medizin.', example_zh: '她学医。' },
  'musik': { gloss_zh: '音乐', example_de: 'Ich höre gern Musik.', example_zh: '我喜欢听音乐。' },
  'punkt': { gloss_zh: '点；句号；要点', example_de: 'Bitte setzen Sie hier einen Punkt.', example_zh: '请在这里加一个句号。' },
  'schon': { gloss_zh: '已经；早就；确实', example_de: 'Ich kenne das Wort schon.', example_zh: '这个词我已经认识了。' },
  'schule': { gloss_zh: '学校', example_de: 'Die Schule beginnt um acht Uhr.', example_zh: '学校八点上课。' },
  'sein': { gloss_zh: '是；存在', example_de: 'Ich bin Studentin.', example_zh: '我是大学生。' },
  'sekretärin': { gloss_zh: '女秘书', example_de: 'Die Sekretärin arbeitet im Büro.', example_zh: '女秘书在办公室工作。' },
  'studentin': { gloss_zh: '女大学生', example_de: 'Sie ist Studentin in Beijing.', example_zh: '她是在北京上学的女大学生。' },
  'studieren': { gloss_zh: '上大学；攻读；学习（专业）', example_de: 'Ich studiere Germanistik.', example_zh: '我在大学学习德语语言文学。' },
  'tasche': { gloss_zh: '包；袋子', example_de: 'Das Buch ist in der Tasche.', example_zh: '书在包里。' },
  'techniker': { gloss_zh: '技术员；技师', example_de: 'Mein Bruder ist Techniker.', example_zh: '我哥哥是技术员。' },
  'text': { gloss_zh: '文本；文章', example_de: 'Lesen Sie bitte den Text.', example_zh: '请阅读这篇课文。' },
  'theater': { gloss_zh: '剧院；戏剧', example_de: 'Heute Abend gehen wir ins Theater.', example_zh: '我们今晚去看戏。' },
  'tisch': { gloss_zh: '桌子', example_de: 'Das Wörterbuch liegt auf dem Tisch.', example_zh: '词典放在桌子上。' },
  'tochter': { gloss_zh: '女儿', example_de: 'Ihre Tochter ist zehn Jahre alt.', example_zh: '她的女儿十岁。' },
  'toll': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '很棒的；极好的', example_de: 'Das ist toll!', example_zh: '太棒了！' },
  'tür': { gloss_zh: '门', example_de: 'Bitte schließen Sie die Tür.', example_zh: '请把门关上。' },
  'und': { gloss_zh: '和；并且', example_de: 'Anna und Paul lernen Deutsch.', example_zh: '安娜和保罗学习德语。' },
  'vater': { gloss_zh: '父亲', example_de: 'Mein Vater arbeitet in einer Firma.', example_zh: '我父亲在一家公司工作。' },
  'wie alt': { gloss_zh: '多大；几岁', example_de: 'Wie alt ist deine Tochter?', example_zh: '你女儿多大了？' },
  'wir': { gloss_zh: '我们', example_de: 'Wir lernen zusammen.', example_zh: '我们一起学习。' },
  'zehn': { pos: 'NUM', pos_zh: '数词', gloss_zh: '十', example_de: 'Das Buch kostet zehn Euro.', example_zh: '这本书十欧元。' },
  'zeitung': { gloss_zh: '报纸', example_de: 'Mein Vater liest morgens die Zeitung.', example_zh: '我父亲早上看报纸。' },
  'zimmer': { gloss_zh: '房间', example_de: 'Mein Zimmer ist klein, aber hell.', example_zh: '我的房间很小，但很明亮。' },

  'abkürzen': { gloss_zh: '缩短；缩写' },
  'abschließen': { gloss_zh: '锁上；完成；结束；签订' },
  'abschreiben': { gloss_zh: '抄写；誊写；照抄' },
  'abteilungsleiter': { gloss_zh: '部门负责人；科室主管' },
  'aktiv': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '积极的；活跃的；主动的' },
  'alphabet': { gloss_zh: '字母表' },
  'antworten': { gloss_zh: '回答；答复' },
  'campus': { gloss_zh: '校园；校区' },
  'dank': { gloss_zh: '感谢；谢意' },
  'deutschabteilung': { gloss_zh: '德语系；德语部' },
  'dialog': { gloss_zh: '对话' },
  'doktor': { gloss_zh: '博士；医生（称谓）' },
  'examen': { gloss_zh: '考试；毕业考试' },
  'fahrrad': { gloss_zh: '自行车' },
  'klasse': { gloss_zh: '班级；等级；类别' },
  'mensa': { gloss_zh: '大学食堂；学生食堂' },
  'plural': { gloss_zh: '复数' },
  'schließen': { gloss_zh: '关闭；结束；推断' },
  'sekretär': { gloss_zh: '秘书' },
  'sekretariat': { gloss_zh: '秘书处；办公室' },
  'singular': { gloss_zh: '单数' },
  'sprache': { gloss_zh: '语言；说话方式' },
  'üben': { gloss_zh: '练习；训练' },
  'übung': { gloss_zh: '练习；习题' },
  'uni': { pos: 'NOUN', pos_zh: '名词', article: 'die', gloss_zh: '大学（Universität 的口语缩写）' },
  'unterrichten': { gloss_zh: '授课；教' },
  'wiederholen': { gloss_zh: '重复；复习' },
  'wissenschaft': { gloss_zh: '科学；学术' },
  'wörterbuch': { gloss_zh: '词典；字典' },

  'ausweis': { gloss_zh: '证件；身份证明' },
  'besuch': { gloss_zh: '访问；拜访；来访' },
  'blatt': { gloss_zh: '纸张；页；叶子' },
  'ei': { gloss_zh: '鸡蛋；蛋' },
  'eure': { pos: 'DET', pos_zh: '限定词', gloss_zh: '你们的' },
  'freundin': { gloss_zh: '女性朋友；女朋友' },
  'großmutter': { gloss_zh: '祖母；外祖母' },
  'großvater': { gloss_zh: '祖父；外祖父' },
  'lektion': { gloss_zh: '课；课文；课次' },
  'mitkommen': { gloss_zh: '一起来；跟着来' },
  'pause': { gloss_zh: '休息；课间休息' },
  'rekorder': { gloss_zh: '录音机；记录设备' },
  'salz': { gloss_zh: '盐' },
  'stift': { gloss_zh: '笔；笔状物' },
  'tante': { gloss_zh: '姑妈；姨妈；婶婶；舅妈' },
  'tee': { gloss_zh: '茶' },
  'wohnung': { gloss_zh: '住房；公寓' },

  'advent': { gloss_zh: '降临期；将临期' },
  'adventskerze': { gloss_zh: '降临节蜡烛' },
  'adventssonntag': { gloss_zh: '降临期主日；降临节星期日' },
  'ankommen': { gloss_zh: '到达；抵达；取决于（auf + Akk.）' },
  'apfel': { gloss_zh: '苹果' },
  'apfelkuchen': { gloss_zh: '苹果蛋糕' },
  'apfelsaft': { gloss_zh: '苹果汁' },
  'arzt': { gloss_zh: '医生' },
  'ausflug': { gloss_zh: '郊游；短途旅行' },
  'bad': { gloss_zh: '浴室；洗澡；浴场' },
  'ball': { gloss_zh: '球；舞会' },
  'baum': { gloss_zh: '树' },
  'beijing-ente': { gloss_zh: '北京烤鸭' },
  'bringen': { gloss_zh: '带来；拿来；送到；使达到' },
  'brühe': { gloss_zh: '汤；肉汤' },
  'butter': { gloss_zh: '黄油' },
  'café': { gloss_zh: '咖啡馆' },
  'christ': { gloss_zh: '基督徒' },
  'comic': { gloss_zh: '漫画；漫画书' },
  'computerclub': { gloss_zh: '电脑社团；计算机俱乐部' },
  'deutschlehrer': { gloss_zh: '德语教师' },
  'kopieren': { gloss_zh: '复制；复印' },

  // Additional corrections for obvious homograph / machine-gloss noise found in later lessons.
  'ausbildung': { gloss_zh: '教育；职业培训；培养' },
  'besserung': { gloss_zh: '好转；改善' },
  'blöd': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '愚蠢的；讨厌的' },
  'boom': { gloss_zh: '繁荣；快速增长' },
  'braun': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '棕色的；褐色的' },
  'bündnis': { gloss_zh: '联盟；同盟' },
  'bürgersteig': { gloss_zh: '人行道' },
  'daoismus': { gloss_zh: '道教；道家思想' },
  'dick': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '厚的；胖的' },
  'donner': { gloss_zh: '雷；雷声' },
  'erde': { gloss_zh: '地球；土地；土壤' },
  'erscheinen': { gloss_zh: '出现；出版；显得' },
  'förmlich': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '正式的；拘谨的' },
  'gesellschaft': { gloss_zh: '社会；公司；交往' },
  'identität': { gloss_zh: '身份；同一性' },
  'krankheit': { gloss_zh: '疾病；病' },
  'kurve': { gloss_zh: '曲线；弯道' },
  'lauf': { gloss_zh: '跑；赛跑；进程' },
  'manager': { gloss_zh: '经理；管理者' },
  'märchen': { gloss_zh: '童话；童话故事' },
  'miete': { gloss_zh: '房租；租金' },
  'meldung': { gloss_zh: '消息；报道；通知' },
  'menschlich': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '人的；人性的；人道的' },
  'ökonomisch': { pos: 'ADJ', pos_zh: '形容词', gloss_zh: '经济的；节约的' },
  'programm': { gloss_zh: '节目；程序；计划' },
  'psychologie': { gloss_zh: '心理学' },
  'schnee': { gloss_zh: '雪' },
  'teil': { gloss_zh: '部分；部件' },
  'tierkreiszeichen': { gloss_zh: '星座；黄道十二宫星座' },
  'trainieren': { gloss_zh: '训练；锻炼' },
  'veralten': { gloss_zh: '过时；变旧' },
  'verhältnis': { gloss_zh: '关系；比例；状况' },
  'wind': { gloss_zh: '风' },
  'wirtschaft': { gloss_zh: '经济；经营；经济活动' },
  'gegen': { pos: 'ADP', pos_zh: '介词', gloss_zh: '对着；反对；大约；与……比赛' },
}


const examplesByLemma: Record<string, Pick<TextbookEntry, 'example_de' | 'example_zh'>> = {
  // Book 1 · Lektion 1 · first learning unit
  'aber': { example_de: 'Ich lerne Deutsch, aber mein Bruder lernt Englisch.', example_zh: '我学德语，但我弟弟学英语。' },
  'machen': { example_de: 'Was machst du heute Abend?', example_zh: '你今天晚上做什么？' },
  'kein': { example_de: 'Ich habe heute keine Zeit.', example_zh: '我今天没有时间。' },
  'unser': { example_de: 'Das ist unser Klassenzimmer.', example_zh: '这是我们的教室。' },
  'verstehen': { example_de: 'Ich verstehe die Frage nicht.', example_zh: '我没听懂这个问题。' },
  'neu': { example_de: 'Mein Computer ist neu.', example_zh: '我的电脑是新的。' },
  'klein': { example_de: 'Das Zimmer ist klein.', example_zh: '这个房间很小。' },
  'erzählen': { example_de: 'Er erzählt uns von seiner Familie.', example_zh: '他给我们讲他的家庭。' },
  'ach': { example_de: 'Ach, das habe ich vergessen!', example_zh: '哎呀，我把这件事忘了！' },
  'mädchen': { example_de: 'Das Mädchen heißt Anna.', example_zh: '这个女孩叫安娜。' },
  'schnell': { example_de: 'Bitte sprechen Sie nicht so schnell.', example_zh: '请您不要说得这么快。' },
  'wann': { example_de: 'Wann beginnt der Unterricht?', example_zh: '什么时候开始上课？' },
  'baby': { example_de: 'Das Baby schläft.', example_zh: '宝宝在睡觉。' },
  'dank': { example_de: 'Vielen Dank für deine Hilfe.', example_zh: '非常感谢你的帮助。' },
  'falsch': { example_de: 'Die Antwort ist falsch.', example_zh: '这个答案是错的。' },
  'lesen': { example_de: 'Wir lesen einen kurzen Text.', example_zh: '我们读一篇短文。' },
  'beginnen': { example_de: 'Der Unterricht beginnt um neun Uhr.', example_zh: '课程九点开始。' },
  'öffnen': { example_de: 'Öffnen Sie bitte das Buch.', example_zh: '请打开书。' },

  // Book 1 · Lektion 2 · first learning unit
  'mit': { example_de: 'Ich lerne mit meiner Freundin.', example_zh: '我和我的朋友一起学习。' },
  'von': { example_de: 'Er kommt gerade von der Uni.', example_zh: '他刚从大学回来。' },
  'warum': { example_de: 'Warum lernst du Deutsch?', example_zh: '你为什么学德语？' },
  'finden': { example_de: 'Wie findest du den Kurs?', example_zh: '你觉得这门课怎么样？' },
  'viel': { example_de: 'Ich habe heute viel zu tun.', example_zh: '我今天有很多事要做。' },
  'zeit': { example_de: 'Hast du morgen Zeit?', example_zh: '你明天有时间吗？' },
  'heute': { example_de: 'Heute habe ich keinen Unterricht.', example_zh: '我今天没有课。' },
  'holen': { example_de: 'Ich hole einen Kaffee.', example_zh: '我去拿一杯咖啡。' },
  'beide': { example_de: 'Wir beide studieren Deutsch.', example_zh: '我们两个人都学德语。' },
  'suchen': { example_de: 'Ich suche meinen Ausweis.', example_zh: '我在找我的证件。' },
  'freund': { example_de: 'Mein Freund wohnt in Berlin.', example_zh: '我的朋友住在柏林。' },
  'moment': { example_de: 'Einen Moment, bitte.', example_zh: '请稍等一下。' },
  'schreiben': { example_de: 'Schreib mir bitte eine E-Mail.', example_zh: '请给我写一封电子邮件。' },
  'trinken': { example_de: 'Ich trinke morgens Tee.', example_zh: '我早上喝茶。' },
  'ruhig': { example_de: 'Hier ist es sehr ruhig.', example_zh: '这里很安静。' },
  'oft': { example_de: 'Wir gehen oft in die Mensa.', example_zh: '我们经常去学生食堂。' },
  'wohnung': { example_de: 'Meine Wohnung liegt nahe der Uni.', example_zh: '我的住处离大学很近。' },
  'besuchen': { example_de: 'Am Wochenende besuche ich meine Eltern.', example_zh: '周末我去看望父母。' },

  // Book 1 · Lektion 3 · high-frequency continuation
  'sehen': { example_de: 'Ich sehe meine Freunde heute Abend.', example_zh: '我今天晚上见朋友。' },
  'tun': { example_de: 'Was kann ich für Sie tun?', example_zh: '我能为您做什么？' },
  'dann': { example_de: 'Erst lernen wir, dann machen wir eine Pause.', example_zh: '我们先学习，然后休息。' },
  'um': { example_de: 'Der Kurs beginnt um acht Uhr.', example_zh: '课程八点开始。' },
  'oder': { example_de: 'Möchtest du Tee oder Kaffee?', example_zh: '你想喝茶还是咖啡？' },
  'immer': { example_de: 'Er kommt immer pünktlich.', example_zh: '他总是准时来。' },
  'vor': { example_de: 'Ich warte vor der Bibliothek.', example_zh: '我在图书馆前面等。' },
  'nie': { example_de: 'Ich trinke nie Kaffee.', example_zh: '我从不喝咖啡。' },
  'stehen': { example_de: 'Das Auto steht vor dem Haus.', example_zh: '汽车停在房子前面。' },
  'fahren': { example_de: 'Wir fahren mit dem Bus zur Uni.', example_zh: '我们坐公交车去大学。' },
  'nacht': { example_de: 'In der Nacht ist es ruhig.', example_zh: '夜里很安静。' },
  'lange': { example_de: 'Wie lange lernst du schon Deutsch?', example_zh: '你学德语多久了？' },
  'spielen': { example_de: 'Die Kinder spielen im Garten.', example_zh: '孩子们在花园里玩。' },
  'laufen': { example_de: 'Ich laufe jeden Morgen zehn Minuten.', example_zh: '我每天早上跑十分钟。' },
  'gegen': { example_de: 'Unsere Mannschaft spielt gegen Berlin.', example_zh: '我们队和柏林队比赛。' },
  'woche': { example_de: 'Nächste Woche habe ich eine Prüfung.', example_zh: '我下周有一场考试。' },
  // Book 1 · Lektion 4–7 · second-wave contextual examples
  'arbeit': { example_de: 'Die Arbeit beginnt um acht Uhr.', example_zh: '工作八点开始。' },
  'denken': { example_de: 'Ich denke oft an meine Familie.', example_zh: '我经常想起我的家人。' },
  'enden': { example_de: 'Der Unterricht endet um zwölf Uhr.', example_zh: '课程十二点结束。' },
  'hören': { example_de: 'Ich höre morgens gern Musik.', example_zh: '我早上喜欢听音乐。' },
  'kaufen': { example_de: 'Ich kaufe heute ein neues Wörterbuch.', example_zh: '我今天买一本新词典。' },
  'kennen': { example_de: 'Kennst du diesen Lehrer?', example_zh: '你认识这位老师吗？' },
  'können': { example_de: 'Kannst du mir bitte helfen?', example_zh: '你能帮帮我吗？' },
  'markt': { example_de: 'Auf dem Markt kaufe ich Gemüse.', example_zh: '我在市场上买蔬菜。' },
  'methode': { example_de: 'Diese Lernmethode hilft mir beim Deutschlernen.', example_zh: '这种学习方法对我的德语学习很有帮助。' },
  'müde': { example_de: 'Ich bin heute sehr müde.', example_zh: '我今天很累。' },
  'ohne': { example_de: 'Ich trinke Kaffee ohne Zucker.', example_zh: '我喝咖啡不加糖。' },
  'ordnen': { example_de: 'Bitte ordnen Sie die Wörter nach der Reihenfolge.', example_zh: '请按顺序排列这些词。' },
  'täglich': { example_de: 'Ich lerne täglich neue Wörter.', example_zh: '我每天学习新单词。' },
  'telefonieren': { example_de: 'Ich telefoniere heute Abend mit meiner Mutter.', example_zh: '我今晚和妈妈打电话。' },
  'übersetzung': { example_de: 'Die Übersetzung steht unter dem Text.', example_zh: '翻译写在课文下面。' },
  'vielleicht': { example_de: 'Vielleicht komme ich morgen früher.', example_zh: '也许我明天会早点来。' },
  'wichtig': { example_de: 'Wiederholen ist beim Lernen wichtig.', example_zh: '复习对学习很重要。' },
  'wirklich': { example_de: 'Das ist wirklich eine gute Idee.', example_zh: '这确实是个好主意。' },
  'angebot': { example_de: 'Heute gibt es im Supermarkt ein gutes Angebot.', example_zh: '今天超市有一项很优惠的促销。' },
  'bank': { example_de: 'Ich muss noch zur Bank gehen.', example_zh: '我还得去一趟银行。' },
  'bekommen': { example_de: 'Ich bekomme heute eine E-Mail von der Universität.', example_zh: '我今天收到大学发来的一封电子邮件。' },
  'bezahlen': { example_de: 'Kann ich mit Karte bezahlen?', example_zh: '我可以刷卡付款吗？' },
  'buchhandlung': { example_de: 'In der Buchhandlung finde ich ein deutsches Wörterbuch.', example_zh: '我在书店找到一本德语词典。' },
  'büro': { example_de: 'Mein Büro ist im zweiten Stock.', example_zh: '我的办公室在二楼。' },
  'einkaufen': { example_de: 'Am Samstag gehe ich gern einkaufen.', example_zh: '星期六我喜欢去买东西。' },
  'flasche': { example_de: 'Ich nehme eine Flasche Wasser mit.', example_zh: '我带一瓶水。' },
  'geschäft': { example_de: 'Das Geschäft schließt um sieben Uhr.', example_zh: '这家商店七点关门。' },
  'geschenk': { example_de: 'Das ist ein Geschenk für meine Freundin.', example_zh: '这是送给我朋友的礼物。' },
  'getränk': { example_de: 'Möchten Sie etwas zu trinken?', example_zh: '您想喝点什么吗？' },
  'hose': { example_de: 'Die Hose ist zu lang.', example_zh: '这条裤子太长了。' },
  'kleidung': { example_de: 'Im Winter brauche ich warme Kleidung.', example_zh: '冬天我需要暖和的衣服。' },
  'kosten': { example_de: 'Wie viel kostet das Buch?', example_zh: '这本书多少钱？' },
  'kreditkarte': { example_de: 'Ich bezahle mit Kreditkarte.', example_zh: '我用信用卡付款。' },
  'lebensmittel': { example_de: 'Wir kaufen am Wochenende Lebensmittel ein.', example_zh: '我们周末买食品。' },
  'lieben': { example_de: 'Ich liebe deutsche Literatur.', example_zh: '我喜欢德国文学。' },
  'müssen': { example_de: 'Ich muss heute noch arbeiten.', example_zh: '我今天还得工作。' },
  'obst': { example_de: 'Zum Frühstück esse ich gern Obst.', example_zh: '早餐我喜欢吃水果。' },
  'reis': { example_de: 'Zum Abendessen gibt es Reis und Gemüse.', example_zh: '晚饭有米饭和蔬菜。' },
  'reise': { example_de: 'Für die Reise brauche ich einen kleinen Koffer.', example_zh: '旅行时我需要一个小行李箱。' },
  'schenken': { example_de: 'Ich schenke meiner Mutter zum Geburtstag Blumen.', example_zh: '我送给妈妈鲜花作为生日礼物。' },
  'abendessen': { example_de: 'Wir essen um sieben Uhr zu Abend.', example_zh: '我们七点吃晚饭。' },
  'abfahren': { example_de: 'Der Zug fährt um neun Uhr ab.', example_zh: '火车九点出发。' },
  'abholen': { example_de: 'Ich hole dich um sechs Uhr ab.', example_zh: '我六点来接你。' },
  'appetit': { example_de: 'Guten Appetit!', example_zh: '祝你用餐愉快！' },
  'aufmachen': { example_de: 'Kannst du bitte das Fenster aufmachen?', example_zh: '你能把窗户打开吗？' },
  'bestellen': { example_de: 'Wir möchten zwei Kaffee bestellen.', example_zh: '我们想点两杯咖啡。' },
  'empfehlen': { example_de: 'Welches Gericht können Sie empfehlen?', example_zh: '您可以推荐哪道菜？' },
  'essen': { example_de: 'Was möchtest du heute Abend essen?', example_zh: '你今晚想吃什么？' },
  'frühstücken': { example_de: 'Ich frühstücke meistens um sieben Uhr.', example_zh: '我通常七点吃早饭。' },
  'gesund': { example_de: 'Obst und Gemüse sind gesund.', example_zh: '水果和蔬菜有益健康。' },
  'rechnung': { example_de: 'Die Rechnung, bitte.', example_zh: '请结账。' },
  'restaurant': { example_de: 'Am Abend gehen wir in ein kleines Restaurant.', example_zh: '晚上我们去一家小餐馆。' },
  'speisekarte': { example_de: 'Auf der Speisekarte stehen viele vegetarische Gerichte.', example_zh: '菜单上有很多素食菜肴。' },
  'termin': { example_de: 'Ich habe morgen einen Termin beim Arzt.', example_zh: '我明天和医生有预约。' },
  'trinkgeld': { example_de: 'Wie viel Trinkgeld geben Sie normalerweise?', example_zh: '您通常给多少小费？' },
  'warm': { example_de: 'Die Suppe ist noch warm.', example_zh: '汤还热着。' },
  'anrufen': { example_de: 'Ich rufe dich später an.', example_zh: '我晚点给你打电话。' },
  'aufhören': { example_de: 'Der Kurs hört um fünf Uhr auf.', example_zh: '课程五点结束。' },
  'bleiben': { example_de: 'Heute bleibe ich zu Hause.', example_zh: '今天我待在家里。' },
  'danken': { example_de: 'Ich danke Ihnen für Ihre Hilfe.', example_zh: '谢谢您的帮助。' },
  'erklären': { example_de: 'Die Lehrerin erklärt die Grammatik.', example_zh: '老师讲解语法。' },
  'fehlen': { example_de: 'Heute fehlt ein Student.', example_zh: '今天有一名学生没来。' },
  'freundlich': { example_de: 'Die Mitarbeiter sind sehr freundlich.', example_zh: '工作人员非常友好。' },
  'gefallen': { example_de: 'Das Bild gefällt mir sehr.', example_zh: '我很喜欢这幅画。' },
  'helfen': { example_de: 'Kannst du mir bei der Übung helfen?', example_zh: '你能帮我做这道练习吗？' },
  'hoffentlich': { example_de: 'Hoffentlich ist das Wetter morgen besser.', example_zh: '希望明天天气更好。' },
  'kochen': { example_de: 'Am Sonntag koche ich für meine Familie.', example_zh: '星期天我给家人做饭。' },
  'langweilig': { example_de: 'Der Film war ein bisschen langweilig.', example_zh: '这部电影有点无聊。' },
  'nett': { example_de: 'Unsere neue Nachbarin ist sehr nett.', example_zh: '我们新来的邻居非常友善。' },
  'party': { example_de: 'Am Samstag sind wir auf einer Party.', example_zh: '星期六我们去参加一个聚会。' },
  'schrecklich': { example_de: 'Das Wetter war gestern schrecklich.', example_zh: '昨天的天气糟透了。' },
  'singen': { example_de: 'Wir singen zusammen ein deutsches Lied.', example_zh: '我们一起唱一首德语歌曲。' },
  'tanzen': { example_de: 'Sie tanzt gern mit ihren Freunden.', example_zh: '她喜欢和朋友一起跳舞。' },
  'traurig': { example_de: 'Warum bist du heute traurig?', example_zh: '你今天为什么难过？' },

}

const coreGlossByLemma = new Map(
  coreLexicon.filter(x => Boolean(x.gloss_zh)).map(x => [x.lemma.trim().toLocaleLowerCase('de-DE'), x.gloss_zh.trim()])
)

const byId: Record<string, ContentOverride> = {
  'sd1-l7-begriissen-113': { lemma: 'begrüßen', pos: 'VERB', pos_zh: '动词', gloss_zh: '问候；欢迎' },
}

function key(s: string) {
  return s.trim().toLocaleLowerCase('de-DE')
}

function containsCjk(s: string) { return /[\u3400-\u9fff]/.test(s) }
function shouldFallbackToCoreGloss(gloss: string) {
  const clean = gloss.trim()
  if (!clean) return true
  // Only replace clearly broken / non-Chinese OCR output. A normal textbook gloss may be
  // context-specific, so the generic Top-2000 gloss must never silently override it.
  if (!containsCjk(clean)) return true
  if (/[A-Za-zÄÖÜäöüß]{10,}/.test(clean)) return true
  return false
}

export function enrichTextbookEntry(entry: TextbookEntry): TextbookEntry {
  const baseGloss = coreGlossByLemma.get(key(entry.lemma))
  const manual = { ...(byLemma[key(entry.lemma)] || {}), ...(examplesByLemma[key(entry.lemma)] || {}), ...(byId[entry.id] || {}) }
  const useCoreFallback = Boolean(baseGloss && shouldFallbackToCoreGloss(entry.gloss_zh || '') && !manual.gloss_zh)
  const override = { ...(useCoreFallback && baseGloss ? { gloss_zh: baseGloss, gloss_source: 'Deutsch OS 基础词库（仅作为原释义缺失/异常时的回退）' } : {}), ...manual }
  if (!Object.keys(override).length) return entry
  const hasManualContent = Boolean(Object.keys(manual).length)
  const standardizedGloss = Boolean(useCoreFallback && baseGloss && !manual.gloss_zh)
  const revisionNote = hasManualContent ? 'Deutsch OS 1.7.2 内容校订' : standardizedGloss ? 'Deutsch OS 基础词库回退释义' : ''
  return {
    ...entry,
    ...override,
    quality_note: revisionNote
      ? `${entry.quality_note ? `${entry.quality_note}；` : ''}${revisionNote}`
      : entry.quality_note,
  } as TextbookEntry
}

export function textbookExample(entry: TextbookEntry) {
  const override = { ...(byLemma[key(entry.lemma)] || {}), ...(examplesByLemma[key(entry.lemma)] || {}), ...(byId[entry.id] || {}) }
  return { de: override.example_de || '', zh: override.example_zh || '' }
}

export const contentRevisionStats = {
  correctedGlosses: Object.values(byLemma).filter(x => x.gloss_zh).length + Object.values(byId).filter(x => x.gloss_zh).length,
  curatedExamples: new Set([
    ...Object.entries(byLemma).filter(([,x]) => x.example_de && x.example_zh).map(([k])=>k),
    ...Object.entries(examplesByLemma).filter(([,x]) => x.example_de && x.example_zh).map(([k])=>k),
    ...Object.entries(byId).filter(([,x]) => x.example_de && x.example_zh).map(([k])=>k),
  ]).size,
  standardizedCoreGlosses: coreGlossByLemma.size,
}
