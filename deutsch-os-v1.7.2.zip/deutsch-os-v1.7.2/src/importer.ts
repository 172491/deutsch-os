import type { ImportDraft } from './types'

const germanWord = /[A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß-]*/g
const articleRE = /^(der|die|das)\s+/i
const cjkRE = /[\u3400-\u9fff]/

export function parseBulkInput(input: string, source = '批量导入'): ImportDraft[] {
  const clean = input.trim()
  if (!clean) return []
  const lines = clean.split(/\r?\n/).map(x => x.trim()).filter(Boolean)

  // A pasted paragraph without line-level translations becomes a unique-word collection.
  if (lines.length === 1 && clean.length > 80 && !cjkRE.test(clean)) {
    const seen = new Set<string>()
    return (clean.match(germanWord) || [])
      .filter(token => token.length > 1)
      .filter(token => {
        const k = token.toLocaleLowerCase('de-DE')
        if (seen.has(k)) return false
        seen.add(k)
        return true
      })
      .map(token => draftFromGerman(token, '', source))
  }

  return lines.map(line => parseLine(line, source)).filter((x): x is ImportDraft => Boolean(x))
}

function parseLine(line: string, source: string): ImportDraft | null {
  let german = line
  let translation = ''

  const delimiter = line.match(/\s*(?:\t|\||::|—|–)\s*/)
  if (delimiter?.index != null) {
    const at = delimiter.index
    german = line.slice(0, at).trim()
    translation = line.slice(at + delimiter[0].length).trim()
  } else {
    const zh = line.search(cjkRE)
    if (zh > 0) {
      german = line.slice(0, zh).replace(/[,:;\-\s]+$/, '').trim()
      translation = line.slice(zh).trim()
    }
  }

  if (!german) return null
  return draftFromGerman(german, translation, source)
}

function draftFromGerman(german: string, translation: string, source: string): ImportDraft {
  let article: ImportDraft['article'] = ''
  const articleMatch = german.match(articleRE)
  if (articleMatch) {
    article = articleMatch[1].toLowerCase() as ImportDraft['article']
    german = german.replace(articleRE, '').trim()
  }

  let plural = ''
  const paren = german.match(/^([^(),;]+)\s*\(([^)]+)\)/)
  if (paren) {
    german = paren[1].trim()
    plural = paren[2].replace(/^Pl\.?\s*:?\s*/i, '').trim()
  } else {
    const commaParts = german.split(/\s*[,;]\s*/)
    if (commaParts.length >= 2 && /^[A-Za-zÄÖÜäöüß-]+$/.test(commaParts[1])) {
      german = commaParts[0]
      plural = commaParts[1]
    }
  }

  const lemma = (german.match(germanWord) || [german])[0]
  return {
    lemma,
    article,
    plural,
    translation,
    part_of_speech: article ? '名词' : '',
    source,
  }
}
