import { createEmptyCard, fsrs, Rating, type Card } from 'ts-fsrs'
import type { MemoryCard, ReviewMode, ReviewRating } from './types'

const ratingMap: Record<ReviewRating, Rating> = {
  again: Rating.Again,
  hard: Rating.Hard,
  good: Rating.Good,
  easy: Rating.Easy,
}

export function createScheduler(requestRetention = 0.9) {
  return fsrs({
    request_retention: Math.max(0.7, Math.min(0.97, requestRetention)),
    maximum_interval: 36500,
    enable_fuzz: true,
    enable_short_term: true,
    learning_steps: ['1m', '10m'],
    relearning_steps: ['10m'],
  })
}

function toFsrsCard(card: MemoryCard | undefined, now: Date): Card {
  if (!card) return createEmptyCard(now)
  return {
    due: new Date(card.due_at),
    stability: card.stability,
    difficulty: card.difficulty,
    elapsed_days: card.elapsed_days,
    scheduled_days: card.scheduled_days,
    learning_steps: card.learning_steps,
    reps: card.reps,
    lapses: card.lapses,
    state: card.state as Card['state'],
    last_review: card.last_review ? new Date(card.last_review) : undefined,
  }
}

function fromFsrsCard(card: Card, wordId: string, mode: ReviewMode, existing?: MemoryCard): MemoryCard {
  const stamp = new Date().toISOString()
  return {
    id: existing?.id || crypto.randomUUID(),
    user_id: existing?.user_id,
    word_id: wordId,
    mode,
    due_at: card.due.toISOString(),
    stability: card.stability,
    difficulty: card.difficulty,
    elapsed_days: card.elapsed_days,
    scheduled_days: card.scheduled_days,
    learning_steps: card.learning_steps,
    reps: card.reps,
    lapses: card.lapses,
    state: card.state as Card['state'],
    last_review: card.last_review?.toISOString() || null,
    created_at: existing?.created_at || stamp,
    updated_at: stamp,
  }
}

export function scheduleReview(existing: MemoryCard | undefined, wordId: string, mode: ReviewMode, rating: ReviewRating, requestRetention = 0.9, now = new Date()) {
  const scheduler = createScheduler(requestRetention)
  const base = toFsrsCard(existing, now)
  const result = scheduler.next(base, now, ratingMap[rating])
  return fromFsrsCard(result.card, wordId, mode, existing)
}

export function previewSchedule(existing: MemoryCard | undefined, requestRetention = 0.9, now = new Date()) {
  const scheduler = createScheduler(requestRetention)
  const result = scheduler.repeat(toFsrsCard(existing, now), now)
  return {
    again: result[Rating.Again].card.due,
    hard: result[Rating.Hard].card.due,
    good: result[Rating.Good].card.due,
    easy: result[Rating.Easy].card.due,
  }
}

export function retrievability(card: MemoryCard | undefined, requestRetention = 0.9, now = new Date()) {
  if (!card || card.reps === 0) return 0
  const scheduler = createScheduler(requestRetention)
  const value = scheduler.get_retrievability(toFsrsCard(card, now), now, false)
  return Math.max(0, Math.min(1, Number(value)))
}
