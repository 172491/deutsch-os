import rawTextbook from './data/textbook-v13.json'
import { enrichTextbookEntry, textbookExample } from './content'
import type { Settings, TextbookEntry, Word } from './types'

export const TEXTBOOK_UNIT_SIZE = 18
export const textbookLexicon = (rawTextbook as unknown as TextbookEntry[]).map(enrichTextbookEntry)
const stageByBook: Record<number,string> = {1:'A1–A2',2:'A2–B1',3:'B1–B2',4:'B2'}

function sortedEntries(entries: TextbookEntry[]) {
  return [...entries].sort((a,b)=>a.order-b.order || a.lemma.localeCompare(b.lemma,'de'))
}

function learningEntriesForLesson(book:number, lesson:number, readyOnly=true) {
  // Preserve the pedagogical sequence from the source textbook.
  // Frequency/CEFR remain metadata for later prioritisation, but do not silently
  // rewrite the author's lesson order.
  return entriesForBook(book, lesson)
    .filter(e => !readyOnly || Boolean(e.study_ready))
}


export function entriesForBook(book:number,lesson?:number){
  return sortedEntries(textbookLexicon.filter(e=>e.book===book&&(lesson===undefined||e.lesson===lesson)))
}

export function unitsForLesson(book:number, lesson:number, readyOnly=true) {
  const entries = learningEntriesForLesson(book, lesson, readyOnly)
  const units = [] as { unit:number; entries:TextbookEntry[]; count:number; first:string; last:string; preview:string }[]
  for (let i=0;i<entries.length;i+=TEXTBOOK_UNIT_SIZE) {
    const slice=entries.slice(i,i+TEXTBOOK_UNIT_SIZE)
    units.push({ unit:Math.floor(i/TEXTBOOK_UNIT_SIZE)+1, entries:slice, count:slice.length, first:slice[0]?.lemma||'', last:slice.at(-1)?.lemma||'', preview:slice.slice(0,3).map(e=>e.lemma).join(' · ') })
  }
  return units
}

function unitNumberForEntry(entry:TextbookEntry, readyOnly=true) {
  const entries=learningEntriesForLesson(entry.book,entry.lesson,readyOnly)
  const index=entries.findIndex(e=>e.id===entry.id)
  return index<0 ? 1 : Math.floor(index/TEXTBOOK_UNIT_SIZE)+1
}

export const textbookBooks = [1, 2, 3, 4].map(book => {
  const entries = textbookLexicon.filter(x => x.book === book)
  const lessonMap = new Map<number,string>()
  entries.forEach(x => lessonMap.set(x.lesson, x.lesson_title))
  const lessons = [...lessonMap.entries()].sort((a,b)=>a[0]-b[0]).map(([lesson,title]) => {
    const xs=entries.filter(x=>x.lesson===lesson)
    const ready=xs.filter(x=>x.study_ready).length
    return {lesson,title,count:xs.length,ready,translated:xs.filter(x=>Boolean(x.gloss_zh)).length,units:Math.max(1,Math.ceil(ready/TEXTBOOK_UNIT_SIZE))}
  })
  return {book,title:`《当代大学德语》学生用书 ${book}`,stage:stageByBook[book]||'—',count:entries.length,ready:entries.filter(x=>x.study_ready).length,translated:entries.filter(x=>Boolean(x.gloss_zh)).length,lessons}
})

function norm(s:string){return s.toLocaleLowerCase('de-DE').replace(/[„“”"'’.,;:!?()[\]{}]/g,'').trim()}
export function entryCovered(entry:TextbookEntry, words:Word[]){const lemma=norm(entry.lemma);return words.some(w=>w.textbook_entry_id===entry.id || norm(w.lemma)===lemma)}

/** The chosen lesson/unit is a starting point. After it is exhausted, the plan automatically continues into later units and lessons. */
export function getPlanEntries(settings:Settings){
  if(!settings.textbook_plan_enabled)return []
  const readyOnly=settings.textbook_only_translated
  const candidates = textbookLexicon
    .filter(e=>e.book===settings.active_textbook_book)
    .filter(e=>e.lesson>=settings.active_textbook_lesson)
    .filter(e=>!readyOnly || Boolean(e.study_ready))
    .filter(e=>e.lesson!==settings.active_textbook_lesson || unitNumberForEntry(e,readyOnly)>=(settings.active_textbook_unit||1))
  const indexById = new Map<string,number>()
  for (const lesson of new Set(candidates.map(e=>e.lesson))) {
    learningEntriesForLesson(settings.active_textbook_book, lesson, readyOnly).forEach((entry,index)=>indexById.set(entry.id,index))
  }
  return candidates.sort((a,b)=>a.lesson-b.lesson || (indexById.get(a.id)??999999)-(indexById.get(b.id)??999999))
}
export function getNextTextbookEntries(settings:Settings, words:Word[], limit:number){
  if(limit<=0)return []
  const existingLemmas=new Set(words.map(w=>norm(w.lemma)));const out:TextbookEntry[]=[]
  for(const entry of getPlanEntries(settings)){if(entryCovered(entry,words)||existingLemmas.has(norm(entry.lemma)))continue;out.push(entry);existingLemmas.add(norm(entry.lemma));if(out.length>=limit)break}
  return out
}
export function textbookToWord(entry:TextbookEntry, readyOnly=true):Word{
  const now=new Date().toISOString()
  const example=textbookExample(entry)
  return {id:crypto.randomUUID(),lemma:entry.lemma,article:entry.article,plural:entry.plural,part_of_speech:entry.pos_zh||(entry.pos==='NOUN'?'名词':entry.pos==='VERB'?'动词':entry.pos),translation:entry.gloss_zh,example_de:entry.example_de||example.de,example_zh:entry.example_zh||example.zh,level:entry.level,source:entry.source,source_note:entry.source_note,tags:['当代大学德语',`第${entry.book}册`,entry.lesson===0?'Vorkurs':`Lektion ${entry.lesson}`,`单元 ${unitNumberForEntry(entry,readyOnly)}`,entry.level].filter(Boolean),textbook_entry_id:entry.id,verb_forms:entry.verb_forms,status:'new',due_at:now,interval_days:0,ease:2.5,meaning_score:0,article_score:0,plural_score:0,spelling_score:0,created_at:now,updated_at:now}
}
export function textbookUnitStats(book:number, lesson:number, unit:number, words:Word[]) {
  const entries = unitsForLesson(book, lesson, true).find(u => u.unit === unit)?.entries || []
  const mapped = entries.map(entry => words.find(w => w.textbook_entry_id === entry.id || norm(w.lemma) === norm(entry.lemma)))
  const introduced = mapped.filter(Boolean).length
  const mastered = mapped.filter(w => w?.status === 'mastered').length
  const learning = mapped.filter(w => Boolean(w) && w?.status !== 'mastered' && Array.isArray(words.find(x => x.id === w?.id)?.tags)).length
  const examples = entries.filter(e => Boolean(e.example_de && e.example_zh)).length
  return { count: entries.length, introduced, mastered, learning, examples, exampleCoverage: entries.length ? Math.round(examples / entries.length * 100) : 0 }
}

export function textbookExampleCoverage(book?:number, lesson?:number) {
  const entries = textbookLexicon.filter(e => (book === undefined || e.book === book) && (lesson === undefined || e.lesson === lesson))
  const ready = entries.filter(e => e.study_ready)
  const examples = ready.filter(e => Boolean(e.example_de && e.example_zh))
  return { total: ready.length, examples: examples.length, missing: Math.max(0, ready.length - examples.length), percent: ready.length ? Math.round(examples.length / ready.length * 100) : 0 }
}

export function textbookPlanStats(settings:Settings,words:Word[]){const all=getPlanEntries(settings);const done=all.filter(e=>entryCovered(e,words)).length;const mastered=all.filter(e=>{const w=words.find(x=>x.textbook_entry_id===e.id || norm(x.lemma)===norm(e.lemma));return w?.status==='mastered'}).length;return{total:all.length,done,mastered,remaining:Math.max(0,all.length-done),percent:all.length?Math.round(done/all.length*100):0,masteryPercent:all.length?Math.round(mastered/all.length*100):0}}
export function textbookEntryDisplay(entry:TextbookEntry){return `${entry.article?entry.article+' ':''}${entry.lemma}`}
export function textbookUnitForEntry(entry:TextbookEntry, readyOnly=true){return unitNumberForEntry(entry,readyOnly)}
