-- Deutsch OS V1.7.2 schema + migration (compatible with V1.x).
-- Safe to run on a new project or on top of earlier Deutsch OS V1.x schemas.
create extension if not exists pgcrypto;

create table if not exists public.words (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lemma text not null,
  article text default '',
  plural text default '',
  part_of_speech text default '',
  translation text default '',
  example_de text default '',
  example_zh text default '',
  level text default '未定',
  source text default '我的生词',
  source_note text default '',
  textbook_entry_id text,
  verb_forms jsonb not null default '{}'::jsonb,
  tags text[] default '{}',
  status text not null default 'new',
  due_at timestamptz not null default now(),
  interval_days double precision not null default 0,
  ease double precision not null default 2.5,
  meaning_score integer not null default 0,
  article_score integer not null default 0,
  plural_score integer not null default 0,
  spelling_score integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.words add column if not exists source_note text default '';
alter table public.words add column if not exists textbook_entry_id text;
alter table public.words add column if not exists verb_forms jsonb not null default '{}'::jsonb;
alter table public.words add column if not exists introduced_on date;

create table if not exists public.review_cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  word_id uuid not null references public.words(id) on delete cascade,
  mode text not null check (mode in ('meaning','article','plural','spelling','conjugation')),
  due_at timestamptz not null default now(),
  stability double precision not null default 0,
  difficulty double precision not null default 0,
  elapsed_days integer not null default 0,
  scheduled_days integer not null default 0,
  learning_steps integer not null default 0,
  reps integer not null default 0,
  lapses integer not null default 0,
  state integer not null default 0,
  last_review timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, word_id, mode)
);

create table if not exists public.review_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  word_id uuid not null references public.words(id) on delete cascade,
  mode text not null check (mode in ('meaning','article','plural','spelling','conjugation')),
  rating text not null check (rating in ('again','hard','good','easy')),
  reviewed_at timestamptz not null default now(),
  due_before timestamptz not null,
  due_after timestamptz not null,
  scheduled_days integer not null default 0,
  stability double precision not null default 0,
  difficulty double precision not null default 0
);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  daily_new integer not null default 12,
  daily_personal_new integer not null default 5,
  reminder_time text not null default '21:30',
  reminder_enabled boolean not null default true,
  push_enabled boolean not null default false,
  daily_goal_minutes integer not null default 15,
  timezone text not null default 'Asia/Tokyo',
  request_retention double precision not null default 0.90,
  textbook_plan_enabled boolean not null default true,
  active_textbook_book integer not null default 1,
  active_textbook_lesson integer not null default 0,
  active_textbook_unit integer not null default 1,
  textbook_only_translated boolean not null default true,
  b2_sprint_enabled boolean not null default true,
  b2_target_date date not null default (current_date + 120),
  b2_current_level text not null default 'A1' check (b2_current_level in ('A1','A2','B1','B2-')),
  b2_daily_minutes integer not null default 240,
  last_reminded_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.user_settings add column if not exists daily_personal_new integer not null default 5;
alter table public.user_settings add column if not exists push_enabled boolean not null default false;
alter table public.user_settings add column if not exists timezone text not null default 'Asia/Tokyo';
alter table public.user_settings add column if not exists request_retention double precision not null default 0.90;
alter table public.user_settings add column if not exists textbook_plan_enabled boolean not null default true;
alter table public.user_settings add column if not exists active_textbook_book integer not null default 1;
alter table public.user_settings add column if not exists active_textbook_lesson integer not null default 0;
alter table public.user_settings add column if not exists active_textbook_unit integer not null default 1;
alter table public.user_settings add column if not exists textbook_only_translated boolean not null default true;
alter table public.user_settings add column if not exists last_reminded_at timestamptz;
alter table public.user_settings add column if not exists b2_sprint_enabled boolean not null default true;
alter table public.user_settings add column if not exists b2_target_date date not null default (current_date + 120);
alter table public.user_settings add column if not exists b2_current_level text not null default 'A1';
alter table public.user_settings add column if not exists b2_daily_minutes integer not null default 240;
do $$
begin
  alter table public.user_settings add constraint user_settings_b2_current_level_check check (b2_current_level in ('A1','A2','B1','B2-'));
exception
  when duplicate_object then null;
end $$;

-- Keep the independent FSRS dimension for verb conjugation when upgrading older schemas.
alter table public.review_cards drop constraint if exists review_cards_mode_check;
alter table public.review_cards add constraint review_cards_mode_check check (mode in ('meaning','article','plural','spelling','conjugation'));
alter table public.review_logs drop constraint if exists review_logs_mode_check;
alter table public.review_logs add constraint review_logs_mode_check check (mode in ('meaning','article','plural','spelling','conjugation'));


create table if not exists public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  seconds integer not null check (seconds > 0),
  started_at timestamptz not null,
  ended_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists public.b2_practice_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  area text not null check (area in ('vocabulary','grammar','reading','listening','writing','speaking')),
  kind text not null check (kind in ('drill','timed','mock')),
  minutes integer not null check (minutes > 0 and minutes <= 600),
  score double precision check (score is null or (score >= 0 and score <= 100)),
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null,
  p256dh text not null,
  auth text not null,
  user_agent text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, endpoint)
);

alter table public.words enable row level security;
alter table public.review_cards enable row level security;
alter table public.review_logs enable row level security;
alter table public.user_settings enable row level security;
alter table public.study_sessions enable row level security;
alter table public.b2_practice_sessions enable row level security;
alter table public.push_subscriptions enable row level security;

-- Recreate policies idempotently.
do $$ begin
  drop policy if exists "users read own words" on public.words;
  drop policy if exists "users insert own words" on public.words;
  drop policy if exists "users update own words" on public.words;
  drop policy if exists "users delete own words" on public.words;
  drop policy if exists "users own review cards" on public.review_cards;
  drop policy if exists "users own review logs" on public.review_logs;
  drop policy if exists "users own settings" on public.user_settings;
  drop policy if exists "users read own settings" on public.user_settings;
  drop policy if exists "users insert own settings" on public.user_settings;
  drop policy if exists "users update own settings" on public.user_settings;
  drop policy if exists "users own push subscriptions" on public.push_subscriptions;
  drop policy if exists "users own study sessions" on public.study_sessions;
  drop policy if exists "users own b2 practice sessions" on public.b2_practice_sessions;
end $$;
create policy "users read own words" on public.words for select to authenticated using ((select auth.uid()) = user_id);
create policy "users insert own words" on public.words for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "users update own words" on public.words for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users delete own words" on public.words for delete to authenticated using ((select auth.uid()) = user_id);
create policy "users own review cards" on public.review_cards for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users own review logs" on public.review_logs for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users own settings" on public.user_settings for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users own push subscriptions" on public.push_subscriptions for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users own study sessions" on public.study_sessions for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "users own b2 practice sessions" on public.b2_practice_sessions for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create index if not exists words_user_source_idx on public.words(user_id, source);
create index if not exists words_user_textbook_idx on public.words(user_id, textbook_entry_id);
create index if not exists words_user_introduced_idx on public.words(user_id, introduced_on);
create unique index if not exists review_cards_user_word_mode_uidx on public.review_cards(user_id, word_id, mode);
create index if not exists review_cards_user_due_idx on public.review_cards(user_id, due_at);
create index if not exists review_logs_user_reviewed_idx on public.review_logs(user_id, reviewed_at desc);
create index if not exists study_sessions_user_date_idx on public.study_sessions(user_id, date desc);
create index if not exists b2_practice_user_date_idx on public.b2_practice_sessions(user_id, date desc);
grant select, insert, update, delete on public.study_sessions to authenticated;
grant select, insert, update, delete on public.b2_practice_sessions to authenticated;

-- Used only by the server-side reminder Edge Function (service-role context).
create or replace function public.reminder_candidates(at_time timestamptz default now())
returns table(user_id uuid, due_count bigint)
language sql security definer set search_path = public
as $$
  select s.user_id, count(c.id)::bigint
  from public.user_settings s
  join public.review_cards c on c.user_id = s.user_id and c.due_at <= at_time
  where s.reminder_enabled = true
    and s.push_enabled = true
    and (s.last_reminded_at is null or s.last_reminded_at < at_time - interval '20 hours')
    and ((extract(hour from at_time at time zone s.timezone)::int * 60
          + extract(minute from at_time at time zone s.timezone)::int
          - split_part(s.reminder_time, ':', 1)::int * 60
          - split_part(s.reminder_time, ':', 2)::int
          + 1440) % 1440) between 0 and 4
  group by s.user_id;
$$;
revoke all on function public.reminder_candidates(timestamptz) from public, anon, authenticated;
grant execute on function public.reminder_candidates(timestamptz) to service_role;
