# Deutsch OS 1.7.2

Deutsch OS 1.7.2 是在 1.7.1 的词汇 / FSRS / 教材系统上新增的 **16 周 Goethe-Zertifikat B2 冲刺层**。它保留《当代大学德语》1–4 册教材骨架、个人词库、阅读取词、FSRS、Supabase 同步和可选 Web Push，但不再把“背了多少词”当成 B2 的主要进度指标。

## 1.7.2 的核心变化

- 新增 **B2 冲刺台**：目标日、16 周阶段、每周验收、每日训练预算、四模块成绩趋势。
- 按四个考试模块组织训练：Lesen / Hören / Schreiben / Sprechen；模块时长按当前 Goethe B2 官方说明显示。
- 采用四阶段路线：W1–4 基础修复 → W5–8 B1 桥接 → W9–12 B2 题型化 → W13–16 模考收口。
- 每日训练不只包含词汇：系统按阶段分配词汇、语法、阅读、听力、写作和口语时间，并根据最近成绩偏向最弱模块。
- 新增 `b2_practice_sessions`：手动记录听读写说/语法训练时长、训练类型、可选分数和复盘备注；这些记录可同步 Supabase。
- 四模块以 **60% 官方及格线**和 **70% 站内安全线**同时显示。70% 只是本站训练缓冲目标，不是 Goethe 的官方要求。
- 新增 28 个 B2 高频表达块，要求在当天写作或口语中主动使用，而不是只做识记。
- 原“语法”演示页从 4 张 A1 静态卡扩展为 **A1→B2 的 24 个核心纠错结构**，并删除虚假的静态掌握百分比。
- B2 起点和剩余天数会给出教材新词强度建议；建议不会偷偷修改你的现有设置，可一键应用。
- 首页时间进度统一改用 `b2_daily_minutes` 的德语总训练预算；旧 `daily_goal_minutes` 字段只为 1.x 数据兼容保留，不再在 UI 中制造第二套时间目标。
- 修复 1.7.1 阅读页“加入学习”引用未传入 `settings` 的旧 bug。
- 1.7.1 的新词生命周期、教材/个人配额分离、真实前台词汇学习计时、教材原顺序、释义回退策略均继续保留。

## B2 冲刺的默认参数

新安装默认：

- 目标日：首次使用起约 120 天后，可自行改为实际考试日期；
- 起点：A1，可修改；
- 每日德语总训练：240 分钟，可在 60–360 分钟范围调整；
- 教材新词仍沿用原设置，不会因升级被自动改写；B2 页面会给出建议值并允许一键应用。

系统里的“建议新词/日”是 Deutsch OS 的冲刺启发式，不是 Goethe 官方词汇量门槛。

## 数据规模

原始教材索引保持不变：4563 条；其中 3430 条标记为 `study_ready`。1.7.2 不重写原始教材 JSON，人工释义和双语例句仍位于独立内容校订层。

当前校订层：

- 153 条人工释义修订；
- 176 个逐条校订的双语例句词条键；
- Vorkurs 50/50 可学习词有例句。

## 本地运行

项目固定 Node.js 22.16.0（见 `.node-version`）。

```bash
npm install
npm run dev
```

正式构建：

```bash
npm run check
npm run build
```

输出目录为 `dist/`。

## 从 1.7.1 升级

1. 先从旧站导出完整 JSON 作为保险。
2. 保留原 Supabase 项目和现有表，不要清库。
3. 在 Supabase SQL Editor 执行 `supabase/migrations/20260901_v172_b2_sprint.sql`；或者对个人部署直接运行根目录最新 `supabase.sql`。
4. 用 1.7.2 代码替换 GitHub 仓库内容并提交。
5. Cloudflare Pages 继续使用 `npm run build`，输出目录 `dist`。
6. 登录后先做一次同步，再检查：词汇记录、B2 训练记录、目标日期和设置是否正常。

详见 `UPGRADE_NOTES_1.7.2.md` 与 `DEPLOY_GUIDE.md`。

## 关键文件

- `src/App.tsx`：界面、学习动线、复习队列、B2 训练记录
- `src/b2.ts`：16 周冲刺阶段、每日任务分配、模块统计、表达块
- `src/demo.ts`：A1→B2 语法纠错路线
- `src/textbook.ts`：教材课次与单元
- `src/content.ts`：人工释义与双语例句校订层
- `src/fsrs.ts`：FSRS 调度
- `supabase/migrations/20260901_v172_b2_sprint.sql`：1.7.2 增量迁移
- `supabase.sql`：完整数据库 schema / 兼容迁移

## 校验

```bash
python3 scripts/validate-textbook.py
python3 scripts/validate-v172.py
npm run check
npm run build
```

当前打包环境无法稳定访问 npm registry，因此本次发布包完成了教材/内容校验、B2 行为测试和 TS/TSX 转译语法检查，但没有虚构“已在此环境完成依赖安装后的完整 Vite build”。Cloudflare 首次构建仍应作为最终生产构建验证。
