#!/usr/bin/env python3
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
p = ROOT / 'src' / 'data' / 'textbook-v13.json'
data = json.loads(p.read_text(encoding='utf-8'))

expected_total = 4563
expected_ready = 3430
expected_book = {1:1162, 2:1270, 3:976, 4:1155}
expected_ready_book = {1:917, 2:1032, 3:807, 4:674}

assert len(data) == expected_total, (len(data), expected_total)
assert len({x['id'] for x in data}) == len(data), 'duplicate textbook entry id'
assert Counter(x['book'] for x in data) == Counter(expected_book)
assert Counter(x['book'] for x in data if x.get('study_ready')) == Counter(expected_ready_book)
assert sum(bool(x.get('study_ready')) for x in data) == expected_ready
assert not any('topsage' in x.get('lemma','').lower() for x in data)

ready = [x for x in data if x.get('study_ready')]
assert not [x for x in ready if not x.get('gloss_zh')], 'ready entries without Chinese gloss'
assert not [x for x in ready if x.get('pos') == 'NOUN' and x.get('article') not in {'der','die','das'}], 'ready nouns without gender/article'
verbs = [x for x in ready if x.get('pos') == 'VERB']
assert not [x for x in verbs if len((x.get('verb_forms') or {}).get('present') or []) != 6], 'ready verbs without 6-person present'
assert not [x for x in verbs if not (x.get('verb_forms') or {}).get('partizip_ii')], 'ready verbs without Partizip II'

def first(lemma):
    return next(x for x in data if x['lemma'] == lemma and x.get('study_ready'))

staat = first('Staat')
assert staat['article'] == 'der' and staat['plural'] == 'Staaten'
lesen = first('lesen')['verb_forms']
assert lesen['present'] == ['lese','liest','liest','lesen','lest','lesen']
assert lesen['praeteritum'] == 'las' and lesen['partizip_ii'] == 'gelesen'
abfahren = first('abfahren')['verb_forms']
assert abfahren['present'][3] == 'fahren ab' and abfahren['partizip_ii'] == 'abgefahren'

print('textbook-v13 validation: OK')
print(f'total={len(data)}, ready={len(ready)}')
for b in range(1,5):
    print(f'book{b}: total={expected_book[b]}, ready={expected_ready_book[b]}')
