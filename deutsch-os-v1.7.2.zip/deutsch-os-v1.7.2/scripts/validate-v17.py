#!/usr/bin/env python3
"""Compatibility entry point; current integrity checks live in validate-v172.py."""
from pathlib import Path
exec((Path(__file__).with_name('validate-v172.py')).read_text(encoding='utf-8'))
