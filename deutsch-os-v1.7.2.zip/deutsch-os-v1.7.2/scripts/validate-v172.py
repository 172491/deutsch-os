#!/usr/bin/env python3
"""Static integrity checks for Deutsch OS 1.7.2 without npm dependencies."""
from __future__ import annotations
import json, re
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
textbook=json.loads((ROOT/'src/data/textbook-v13.json').read_text(encoding='utf-8'))
content=(ROOT/'src/content.ts').read_text(encoding='utf-8')
b2=(ROOT/'src/b2.ts').read_text(encoding='utf-8')
app=(ROOT/'src/App.tsx').read_text(encoding='utf-8')
grammar=(ROOT/'src/demo.ts').read_text(encoding='utf-8')
types=(ROOT/'src/types.ts').read_text(encoding='utf-8')
sql=(ROOT/'supabase.sql').read_text(encoding='utf-8')
migration=(ROOT/'supabase/migrations/20260901_v172_b2_sprint.sql').read_text(encoding='utf-8')

assert len(textbook)==4563
assert sum(bool(x.get('study_ready')) for x in textbook)==3430
assert len({x['id'] for x in textbook})==4563

# Content layer counts and Vorkurs coverage.
by_lemma_src=content.split('const examplesByLemma',1)[0]
manual_gloss={}
manual_examples=set()
for m in re.finditer(r"^\s*'([^']+)':\s*\{([^\n]*)\}",by_lemma_src,re.M):
    key,body=m.groups(); gloss=re.search(r"gloss_zh:\s*'([^']*)'",body)
    if gloss: manual_gloss[key.casefold()]=gloss.group(1)
    if 'example_de:' in body and 'example_zh:' in body: manual_examples.add(key.casefold())
examples_src=content.split('const examplesByLemma',1)[1].split('const coreGlossByLemma',1)[0]
extra={m.group(1).casefold() for m in re.finditer(r"^\s*'([^']+)':\s*\{[^\n]*example_de:[^\n]*example_zh:",examples_src,re.M)}
all_examples=manual_examples|extra
assert len(manual_gloss)>=150
assert len(all_examples)>=170
vorkurs=[x for x in textbook if x['book']==1 and x['lesson']==0 and x.get('study_ready')]
assert not [x['lemma'] for x in vorkurs if x['lemma'].casefold() not in all_examples]

# Units preserve source textbook order and never exceed 18 ready words.
for book in range(1,5):
    lessons=sorted({x['lesson'] for x in textbook if x['book']==book})
    for lesson in lessons:
        ready=sorted([x for x in textbook if x['book']==book and x['lesson']==lesson and x.get('study_ready')],key=lambda x:(x['order'],x['lemma']))
        units=[ready[i:i+18] for i in range(0,len(ready),18)]
        assert all(1<=len(u)<=18 for u in units)
        assert [x['id'] for u in units for x in u]==[x['id'] for x in ready]

# B2 layer: 4 official modules, 16 milestones, 4 phases, tracked settings and DB table.
for token in ["area:'reading'", "area:'listening'", "area:'writing'", "area:'speaking'"]:
    assert token in b2, token
assert b2.count("title:'")>=10
assert len(re.findall(r"id:'g\d+'", grammar))>=24
assert len(re.findall(r"^\s*'[^']+',$", b2, re.M))>=16, 'weekly milestone list looks incomplete'
assert 'weeklyMilestones[week-1]' in app
for field in ['b2_sprint_enabled','b2_target_date','b2_current_level','b2_daily_minutes']:
    assert field in types and field in sql and field in app
assert 'b2_practice_sessions' in sql and 'b2_practice_sessions' in migration and 'b2_practice_sessions' in app
assert "minutes:65" in b2 and "minutes:40" in b2 and "minutes:75" in b2 and "minutes:15" in b2
assert '120/16' in b2 and 'localDateInTimeZone(settings.timezone)' in b2
assert '应用到教材新词额度' in app and 'sprint-apply-vocab' in app
assert '<strong>每日目标</strong>' not in app, 'obsolete 1.x daily_goal_minutes UI is still visible'
assert 'dueCount + plannedPersonalBacklog + plannedTextbookNew' in app, 'Today queue omits not-yet-introduced daily intake'
assert 'new Date(c.updated_at).getTime() > new Date(local.updated_at).getTime()' in app, 'cloud-newer FSRS cards are not winning merge'
assert '1.7.2' in app
assert "const word={...lexiconToWord(builtIn.entry),introduced_on:dateKeyInTimezone(settings.timezone)}" in app
assert "const today = dateKeyInTimezone(settings.timezone)" in app

print('Deutsch OS 1.7.2 validation: OK')
print(f'raw textbook={len(textbook)}, study_ready={sum(bool(x.get("study_ready")) for x in textbook)}')
print(f'manual gloss overrides={len(manual_gloss)}, curated example lemmas={len(all_examples)}')
print('Vorkurs example coverage=50/50; textbook unit order=source order')
print('B2 sprint=4 modules / 4 phases / 16-week milestone layer')
