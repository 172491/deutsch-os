#!/usr/bin/env python3
import csv, json, math, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data'/'wordhoard-de-top2000.csv'
GLOSSES=ROOT/'data'/'core-glosses.tsv'
OUT=ROOT/'src'/'data'/'de-core.json'

POS_ALLOWED={'NOUN','VERB','AUX','ADJ','ADV','PRON','DET','ADP','CCONJ','SCONJ','PART','INTJ'}
BLACKLIST={'IM','Dad','REST','Miss','Sir','deinen','bisschen','jungs','ganzen','mussen','eu','misen','new','leuten','schönen','sekunden','nen','fürcht','leiben','toten'}

def forms_parse(s):
    out={}
    if not s: return out
    for piece in s.split(';'):
        if ':' not in piece: continue
        form,feature=piece.rsplit(':',1)
        form=form.strip(); feature=feature.strip()
        if form and feature: out.setdefault(feature,[]).append(form)
    return out

def good(row, forms):
    pos=row['pos']
    if pos not in POS_ALLOWED or pos=='PROPN': return False
    if pos=='NOUN': return bool(forms.get('nom.sg') or forms.get('nom.pl'))
    if pos in {'VERB','AUX'}:
        lemma=row['lemma']
        return bool(forms.get('pres.3sg') or forms.get('part.perf') or lemma.endswith(('en','eln','ern')) or lemma in {'sein','haben','werden','können','müssen','dürfen','sollen','wollen','mögen'})
    return True

def first(forms,key):
    xs=forms.get(key) or []
    return xs[0] if xs else ''

def zh_pos(pos):
    return {'NOUN':'名词','VERB':'动词','AUX':'助动词','ADJ':'形容词','ADV':'副词','PRON':'代词','DET':'限定词','ADP':'介词','CCONJ':'并列连词','SCONJ':'从属连词','PART':'小品词','INTJ':'感叹词'}.get(pos,pos)

gloss={}
with GLOSSES.open(encoding='utf-8') as f:
    for line in f:
        if not line.strip(): continue
        k,v=line.rstrip('\n').split('\t',1)
        gloss[k.replace(' ','').casefold()]=v.strip()

rows=[]; seen=set()
with SOURCE.open(encoding='utf-8-sig', newline='') as f:
    for row in csv.DictReader(f):
        forms=forms_parse(row.get('forms',''))
        if not good(row,forms): continue
        pos=row['pos']
        lemma=row['lemma'].strip()
        if pos=='NOUN':
            # WordHoard lowercases corpus lemmas. Restore standard German noun casing
            # from the canonical lemma rather than accidentally using a plural form.
            lemma=(lemma[:1].upper()+lemma[1:]) if lemma else lemma
        else:
            lemma=lemma.lower()
        if lemma in BLACKLIST: continue
        key=lemma.casefold()
        if key in seen: continue
        seen.add(key)
        rank=int(row['frequency_rank'])
        article=row.get('gender','') if row.get('gender','') in {'der','die','das'} else ''
        plural=first(forms,'nom.pl') or first(forms,'pl')
        # Keep useful analysed forms plus observed surfaces for reader matching.
        compact={k:v[:8] for k,v in forms.items() if k in {'surface','nom.sg','nom.pl','gen.sg','dat.pl','pres.3sg','pres.1sg','pres.2sg','pres.1pl','pres.2pl','part.perf','imp.sg'} and v}
        rows.append({
            'id':f'wh-de-{rank}',
            'lemma':lemma,
            'pos':pos,
            'pos_zh':zh_pos(pos),
            'article':article,
            'plural':plural,
            'level':row.get('cefr_estimate','') or '',
            'frequency_rank':rank,
            'frequency_count':int(row['frequency_count']) if row.get('frequency_count','').isdigit() else 0,
            'gloss_zh':gloss.get(key,''),
            'forms':compact,
            'source':'WordHoard Top 2000',
            'license':'CC BY-SA 4.0',
        })
rows.sort(key=lambda x:x['frequency_rank'])
OUT.write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print(f'wrote {len(rows)} entries; {sum(bool(x["gloss_zh"]) for x in rows)} with Chinese quick glosses -> {OUT}')
