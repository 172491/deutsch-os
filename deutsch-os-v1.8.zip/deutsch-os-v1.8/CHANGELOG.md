# Changelog

## 1.8

- Added Goethe calibration layer based on the supplied A1 official Wortliste; 515 textbook entries receive an explicit Goethe-A1 Wortliste match badge.
- Separated official matches from textbook-stage CEFR estimates; no claim of full A2/B1/B2 official vocabulary coverage.
- Added level-aware A1/A2/B1/B2 Redemittel bank and daily callable expression.
- Rebalanced Phase-1 A1 sprint toward vocabulary + grammar + listening while keeping low-dose writing/speaking.
- Added material-use map with explicit warnings for older B1/B2 prep-book formats.
- Fixed high-confidence textbook OCR/parsing issues in the overlay layer, including `abraten` / `braten`.
- Package/service-worker version updated to 1.8; no Supabase schema migration required beyond 1.7.2.


## 1.7.2

- 新增 16 周 Goethe B2 冲刺台与目标日倒推。
- 将每日训练扩展为词汇、语法、阅读、听力、写作、口语六类，并随阶段和薄弱模块动态分配。
- 新增四模块成绩仪表盘：60% 官方及格线，70% 站内训练安全线。
- 新增 `b2_practice_sessions` 与 Supabase 同步，记录训练分钟、类型、可选成绩和复盘。
- 新增 28 个 B2 表达块和 16 个周验收目标。
- 语法页由 4 张 A1 演示卡升级为 A1→B2 的 24 个核心纠错结构，删除虚假静态进度。
- B2 新词强度建议可一键应用，但升级不自动覆写用户已有教材新词额度。
- 删除旧 UI 中已经失效的 `daily_goal_minutes` 目标，字段仅为历史兼容保留。
- 修复 Reader 未接收 `settings` 导致“阅读取词加入学习”存在运行/类型错误的问题。
- B2 日任务的日期与星期判断改用用户设置时区。
- Service Worker 缓存版本升级到 1.7.2。
- 修复云端 FSRS 卡比本地更新时仍错误保留本地旧卡的跨设备合并 bug。

## 1.7.1
- 分离教材新词额度与个人批量导入额度；SRS 到期复习与词形维度扩展不占新词额度。
- 手动加入 / 阅读主动收词立即进入学习；批量导入继续进入个人待引入队列。
- 教材单元恢复教材原始词序，不再用 CEFR / 频率静默重排课内顺序。
- 学习时长改为按页面可见的有效学习秒数计时，并支持本地与 Supabase `study_sessions` 同步。
- 保留旧 `minutes` 存储并自动迁移，避免升级后历史时长消失。


## 1.7 — 2026-08-31

- 修正每日新词配额：历史上尚未开始的词不再让首页误以为今日额度已耗尽；启动学习时会优先引入旧待学词，再补当前教材计划。
- 新增 `introduced_on`，把“进入今日学习池”和“存在于词库”分开。
- 分阶段维度只有在词义卡实际复习过至少一次后才会加入，减少新词刚出现就展开多维卡片。
- 教材计划进度新增“已掌握”口径，单元显示“已引入 / 已掌握 / 例句覆盖”。
- 词书页新增“只看缺例句”和例句覆盖统计，便于继续逐课补齐高质量双语例句。
- 修正教材释义策略：开放基础词库不再无条件覆盖教材语境，只在原释义缺失或明显异常时作为回退。
- “学习分钟”改为按实际学习时长累计到每日，而不是按完成卡片数量估算。
- Supabase 新增 `words.introduced_on` 及索引。


## 1.6 — 2026-08-23

- 从 1.3 代码继续升级，统一版本号到 1.6。
- 新增“册 → 课 → 单元”学习起点，每课约 18 个可学习词。
- 单元顺序改为课内常用度 / CEFR 优先，避免按字母表机械学习。
- 修正每日新词的任务膨胀：新词首次只引入一个整合卡片，独立形态维度分阶段加入 FSRS。
- 首页计划数现在包含即将从教材计划引入的新词。
- 新增独立 `src/content.ts` 内容校订层；基础词库释义优先于未经校订的机器释义，人工覆盖拥有最高优先级。
- 修正一批明显错误或不适合学习的中文释义。
- 为第一册 Vorkurs 50 个可学习词补齐双语例句，并继续覆盖 Lektion 1–3 高频起始词；当前共 102 个逐条编写的双语例句。
- 教材词书可按单元浏览例句、形态和校订状态。
- Supabase `user_settings` 新增 `active_textbook_unit`。
- 支持 `VITE_SUPABASE_PUBLISHABLE_KEY`，保留旧 anon key 兼容。
- Cloudflare Pages 增加 `_headers`，Service Worker cache key 升级。
- Edge Function 支持 Supabase 新 secret key 环境变量，保留 legacy service-role fallback。
