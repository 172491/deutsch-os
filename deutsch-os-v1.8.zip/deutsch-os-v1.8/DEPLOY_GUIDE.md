# Deutsch OS 1.8 部署指南（Supabase + Cloudflare Pages）

> 适合不写代码的操作路径。这里把你说的 “flarecloud” 按 **Cloudflare Pages** 处理。
>
> 推荐顺序：**先配置 Supabase → 再上传 GitHub → Cloudflare Pages 部署 → 回 Supabase 填正式网址 → 最后测试登录与同步**。

## 你手里需要什么

- 解压后的 `deutsch-os-v1.8` 文件夹
- 一个 Supabase 账号
- 一个 GitHub 账号
- 一个 Cloudflare 账号

第一轮部署先不要配置后台 Web Push。网站、教材学习、FSRS、账号和跨设备同步都可以先跑起来；后台定时推送放到最后做。

---

# 第一部分：Supabase

## 1. 创建或继续使用 Supabase 项目

### 如果你以前从未部署过 1.3

1. 登录 Supabase Dashboard。
2. New project。
3. 选组织、项目名、数据库密码和区域。
4. 等项目创建完成。

### 如果你已经有 1.3 的 Supabase 项目

继续用原项目。不要删表，也不要新建第二套数据库。

## 2. 确认 1.7.2 数据库迁移已运行（1.8 无新增表）

1. 在 Supabase 左侧打开 **SQL Editor**。
2. New query。
3. 在电脑上打开本项目根目录的 `supabase.sql`。
4. 全选复制，粘贴到 SQL Editor。
5. 点击 **Run**。

1.8 没有新增数据库字段。若你是从 1.7.2 直接升级，无需再运行新 migration；若更早版本升级，请先确保 1.7.2 的 migration 已执行。现有结构继续保留 `active_textbook_unit`、`words.introduced_on`、`daily_personal_new` 和 `study_sessions`，并新增 B2 冲刺参数与 `b2_practice_sessions`；原有教材词条、FSRS 卡片、复习日志、用户设置和 RLS 权限策略保持兼容。

运行成功后，在 Table Editor 中应能看到至少这些表：

- `words`
- `review_cards`
- `review_logs`
- `user_settings`
- `push_subscriptions`

## 3. 获取前端可以使用的 Supabase 信息

在 Supabase 项目中打开 **Connect**，或 **Settings → API Keys**。

你需要两项：

```text
VITE_SUPABASE_URL=https://你的项目编号.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_……
```

重要：浏览器前端只能放 **Publishable key**。不要把 `sb_secret_...`、Secret key 或旧的 `service_role` 放进任何 `VITE_...` 环境变量。

如果你的旧 1.3 项目只有 legacy `anon` key，这版仍兼容：

```text
VITE_SUPABASE_ANON_KEY=旧的 anon key
```

新部署推荐直接用 Publishable key。

## 4. 检查邮箱登录

打开 Supabase：

**Authentication → Sign In / Providers → Email**

确保 Email 登录开启。建议第一轮保留邮箱确认。

此时先不用填写正式 Site URL，因为 Cloudflare 网址还没生成；完成 Cloudflare 首次部署后回来补。

---

# 第二部分：把代码放到 GitHub

Cloudflare Pages 最省事的长期方式是连接 GitHub。以后有新版，只要更新 GitHub，Cloudflare 会自动重新构建。

## 1. 创建 GitHub 仓库

1. 登录 GitHub。
2. 创建一个新 repository，例如：`deutsch-os`。
3. Public / Private 都可以。代码仓库是否公开不影响最终网页是否可访问。
4. 不需要勾选生成 README，因为项目已经自带 README。

## 2. 上传文件

进入刚建好的 repository：

1. 选择 **Add file → Upload files**。
2. 把解压后的 `deutsch-os-v1.8` 文件夹里的内容上传。
3. 上传完成后确认 GitHub 仓库首页直接能看到：
   - `package.json`
   - `src/`
   - `public/`
   - `supabase.sql`
   - `vite.config.ts`
4. 提交（Commit changes）。

注意：不要上传你自己本机的 `.env` 或 `.env.local`。本包只带 `.env.example`，它不含真实密钥，可以上传。

如果你看到 GitHub 最外层只有一个 `deutsch-os-v1.8/` 文件夹，而 `package.json` 藏在它里面，Cloudflare 的 Root directory 需要额外设置。最简单的做法是让 `package.json` 就在仓库根目录。

---

# 第三部分：Cloudflare Pages

## 1. 连接 GitHub

1. 登录 Cloudflare Dashboard。
2. 打开 **Workers & Pages**。
3. **Create application → Pages → Import an existing Git repository**。
4. 授权 GitHub，选择刚才的 `deutsch-os` 仓库。

## 2. 构建设置

填写：

```text
Production branch: main
Build command: npm run build
Build output directory: dist
```

如果 `package.json` 在 GitHub 仓库根目录，Root directory 留空即可。

## 3. 添加环境变量

在创建页面或部署后的：

**Pages project → Settings → Environment variables**

加入：

```text
VITE_SUPABASE_URL = 你的 Supabase Project URL
VITE_SUPABASE_PUBLISHABLE_KEY = 你的 sb_publishable_... key
```

如果你暂时仍使用旧 anon key，则第二行改用：

```text
VITE_SUPABASE_ANON_KEY = 你的旧 anon key
```

建议 Production 和 Preview 都配置相同的 Supabase 前端变量，这样预览部署也能正常登录测试。

## 4. 第一次部署

点 **Save and Deploy**。

成功后你会得到类似：

```text
https://deutsch-os-xxxx.pages.dev
```

打开后应能看到 Deutsch OS 1.8。

如果 Cloudflare 构建失败，先看 Build logs 最后 20–30 行。这个项目要求 Node 20+；`package.json` 已声明 `node >=20`。

---

# 第四部分：回 Supabase 填正式网址

Cloudflare 正式网址生成后，回 Supabase：

**Authentication → URL Configuration**

把：

```text
Site URL
```

设为你的正式 Cloudflare Pages 地址，例如：

```text
https://deutsch-os-xxxx.pages.dev
```

如果以后绑定自己的域名，例如 `https://deutsch.example.com`，再把 Site URL 改成正式自定义域名。

可以在 Additional Redirect URLs 加：

```text
http://localhost:5173/**
```

用于本地开发。

如果你确实需要用 Cloudflare 的预览部署测试邮箱确认，可以再按实际 `<preview>.<project>.pages.dev` 形式添加对应的通配规则；正式生产地址尽量使用精确 URL。

---

# 第五部分：第一次上线测试

按这个顺序测：

1. 打开正式 `pages.dev` 地址。
2. 左侧 / 底部进入 **设置**。
3. “跨设备同步”区域不应再显示“当前是本地模式”；应显示登录 / 注册框。
4. 注册一个测试邮箱。
5. 如果开启了 Email confirmation，去邮箱点确认链接。
6. 登录。
7. 在 **词库 → 教材词书** 选择：第 1 册 → Vorkurs → 单元 1。
8. 回首页，确认“今日计划”显示待引入的新词。
9. 开始学习，第一批词应先出现高频基础词，例如 `sein / du / und / wir ...`，而且 Vorkurs 词有双语例句。
10. 做几张卡后刷新网页，进度应保留。
11. 换一个浏览器登录同一账号，确认学习词和卡片能从 Supabase 同步回来。

如果第 3 步仍显示“本地模式”，最常见原因是 Cloudflare 没有正确设置 `VITE_SUPABASE_URL` / `VITE_SUPABASE_PUBLISHABLE_KEY`，或者设置后没有重新部署。

---

# 第六部分：以后怎么更新网站

如果以后我再给你 1.8：

1. 先看新版是否带新的 `supabase.sql` 迁移。
2. 如果有，先在原 Supabase 项目运行它。
3. 再把新版代码更新到同一个 GitHub repository。
4. Cloudflare Pages 会自动构建并发布。
5. 不需要重新建 Supabase 项目，也不需要重新注册用户。

当前项目的主要 Local Storage key 保持兼容；同一域名覆盖部署时，本地未登录数据也不会因为版本号变化自动消失。

---

# 可选：后台 Web Push 提醒

这一部分只在你希望“网页关掉以后，到提醒时间仍能收到学习通知”时做。普通网页打开状态下的本地通知不需要这一部分。

## 1. 生成 VAPID 密钥

电脑安装了 Node.js 后，在终端运行：

```bash
npx web-push generate-vapid-keys
```

会得到 Public Key 和 Private Key。

## 2. Cloudflare 增加公开 VAPID key

Pages project → Settings → Environment variables：

```text
VITE_VAPID_PUBLIC_KEY = 你的 VAPID Public Key
```

保存后重新部署一次。这里只放 Public Key。

## 3. Supabase 部署 Edge Function

Supabase Dashboard → **Edge Functions → Deploy a new function → Via Editor**。

函数名：

```text
send-reminders
```

把本项目：

```text
supabase/functions/send-reminders/index.ts
```

完整复制到编辑器并 Deploy。

Supabase 托管的 Edge Function 已自带 `SUPABASE_URL` 和项目 API key 环境变量；本版本代码优先读取新的 `SUPABASE_SECRET_KEYS`，并兼容旧 `SUPABASE_SERVICE_ROLE_KEY`。

## 4. 给 Edge Function 添加 VAPID secrets

在 Edge Functions 的 Secrets / 环境变量位置添加：

```text
VAPID_PUBLIC_KEY = 刚才的 Public Key
VAPID_PRIVATE_KEY = 刚才的 Private Key
VAPID_SUBJECT = mailto:你的邮箱
```

Private Key 只放 Supabase Edge Function secrets，不要放 Cloudflare 的 `VITE_...` 变量。

## 5. 建立 Cron

Supabase Dashboard 的 **Jobs / Cron**：

1. Create job。
2. 名字例如 `deutsch-reminders`。
3. Schedule：

```text
*/5 * * * *
```

4. Job 类型选择 **Supabase Edge Function**。
5. 选择 `send-reminders`。
6. 保存并启用。

数据库里的 `reminder_candidates()` 会按每个用户自己的时区和提醒时间筛选，并避免一天内反复提醒。

## 6. 在网站里启用

1. 登录 Deutsch OS。
2. 设置 → 学习提醒。
3. 设置时区和提醒时间。
4. 点击“启用本设备后台 Web Push”。
5. 浏览器弹出通知权限时允许。
6. 用“发送测试通知”确认系统通知可见。

如果你暂时不需要后台提醒，完全可以跳过第六部分；它不影响主学习功能。

---

# 三个最重要的安全规则

1. Cloudflare 的 `VITE_SUPABASE_...` 只能用 Publishable / legacy anon key。
2. `sb_secret_...`、legacy `service_role`、VAPID Private Key 永远不要放在前端代码、GitHub 公共文件或 `VITE_...` 变量中。
3. Supabase 的 RLS 不要关闭；本项目的 `supabase.sql` 已为每张个人数据表配置“用户只能访问自己的数据”的策略。

## 1.7.2 数据库变更的更稳妥做法（有 Supabase CLI 时）

本项目另外提供了：

```text
supabase/migrations/20260831_v171_learning_quota_and_study_time.sql
supabase/migrations/20260901_v172_b2_sprint.sql
```

1.7.2 新增的迁移是 `supabase/migrations/20260901_v172_b2_sprint.sql`：它增加 B2 冲刺设置和 `b2_practice_sessions`。1.7.1 的 `words.introduced_on`、个人新词额度与 `study_sessions` 迁移仍保留在 migrations 目录，供更老版本逐步升级。正式团队开发时，建议把这个 migration 纳入版本控制并按 Supabase migration 流程执行；如果你只是自己部署一次，直接在 SQL Editor 运行根目录的 `supabase.sql` 也可以。Supabase 官方当前仍建议用 migrations 管理数据库结构变更。 
