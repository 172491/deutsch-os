import a1CalibrationRaw from './data/goethe-a1-calibration.json'
import type { Settings, TextbookEntry } from './types'

export type GoetheReferenceLevel = 'A1'|'A2'|'B1'|'B2'
export type TrainingSkill = 'vocabulary'|'grammar'|'reading'|'listening'|'writing'|'speaking'

export type Redemittel = {
  id:string
  level:GoetheReferenceLevel
  skill:TrainingSkill|'general'
  purpose:string
  de:string
  zh:string
  task:string
}

const a1MatchedIds = new Set((a1CalibrationRaw as {matched_textbook_entry_ids:string[]}).matched_textbook_entry_ids)

export const goetheReferenceStats = {
  a1TextbookMatches: a1MatchedIds.size,
  a1UniqueLemmas: (a1CalibrationRaw as {matched_unique_lemmas:string[]}).matched_unique_lemmas.length,
}

export function goetheCalibration(entry:TextbookEntry){
  if(a1MatchedIds.has(entry.id)) return {kind:'official-a1' as const,label:'Goethe A1 官方词表匹配',level:'A1' as const,confidence:'official'}
  if(entry.level_is_estimate) return {kind:'estimated' as const,label:`教材进度估计 ${entry.level}`,level:entry.level,confidence:'estimate'}
  return {kind:'reference' as const,label:entry.level||'等级待核对',level:entry.level,confidence:'reference'}
}

export const sourceMaterials = [
  {level:'A1' as const,title:'Fit fürs Goethe-Zertifikat A1 / Start Deutsch 1',use:'阅读、听力、写作、口语模块训练；配套词汇练习。',authority:'训练参考',note:'较早版本；题型细节以当前 Goethe 官方材料为准。'},
  {level:'A2' as const,title:'Fit fürs Goethe-Zertifikat A2 · 新题型版',use:'Lesen / Hören / Schreiben / Sprechen，含 Wortliste、Redemittel 与 Simulation。',authority:'训练参考',note:'适合提炼任务语言和表达块；当前考试规则仍以 Goethe 官网为准。'},
  {level:'B1' as const,title:'Fit fürs Zertifikat Deutsch B1 + B1 Testbuch',use:'技能训练、题型意识、模拟训练与复盘。',authority:'语言训练',note:'版本较早，不作为 2026/27 当前题型权威。'},
  {level:'B2' as const,title:'Fit fürs Goethe-Zertifikat B2',use:'B2 主题语言、表达方式与技能训练。',authority:'语言训练',note:'书中说明对应 2007/2008 版 B2；不能覆盖当前 Goethe B2 题型结构。'},
]

// These are short, original learning prompts built around the functions highlighted by the
// uploaded A1–B2 preparation materials. They are not a reproduction of book exercises.
export const redemittel:Redemittel[] = [
  {id:'a1-intro-1',level:'A1',skill:'speaking',purpose:'自我介绍',de:'Ich heiße … und ich komme aus …',zh:'我叫……，来自……',task:'替换姓名和城市，连续说两遍。'},
  {id:'a1-intro-2',level:'A1',skill:'speaking',purpose:'学习情况',de:'Ich lerne seit … Deutsch.',zh:'我学德语已经……',task:'补上真实时间，再加一句原因。'},
  {id:'a1-question-1',level:'A1',skill:'speaking',purpose:'询问信息',de:'Können Sie mir bitte sagen, …?',zh:'您能告诉我……吗？',task:'今天至少造两个真实问题。'},
  {id:'a1-request-1',level:'A1',skill:'speaking',purpose:'礼貌请求',de:'Könnten Sie bitte etwas langsamer sprechen?',zh:'您能说慢一点吗？',task:'朗读三遍，注意 könnten / langsamer。'},
  {id:'a1-time-1',level:'A1',skill:'general',purpose:'时间安排',de:'Um … Uhr habe ich …',zh:'……点我有……',task:'用今天的日程造三句。'},
  {id:'a1-like-1',level:'A1',skill:'writing',purpose:'喜好',de:'Ich mag …, aber … mag ich nicht so gern.',zh:'我喜欢……，但不太喜欢……',task:'写两组真实喜好。'},
  {id:'a1-reason-1',level:'A1',skill:'writing',purpose:'简单原因',de:'Ich lerne Deutsch, weil …',zh:'我学德语，因为……',task:'补完一句，并检查从句动词位置。'},
  {id:'a1-plan-1',level:'A1',skill:'speaking',purpose:'计划',de:'Morgen möchte ich …',zh:'明天我想……',task:'说出明天三个计划。'},
  {id:'a1-help-1',level:'A1',skill:'speaking',purpose:'求助',de:'Entschuldigung, können Sie mir helfen?',zh:'不好意思，您能帮我吗？',task:'接着说清楚需要什么帮助。'},
  {id:'a1-opinion-1',level:'A1',skill:'writing',purpose:'简单评价',de:'Ich finde das gut / schwierig / wichtig.',zh:'我觉得这很好 / 很难 / 很重要。',task:'选一个今天学到的内容评价。'},
  {id:'a2-opinion-1',level:'A2',skill:'writing',purpose:'表达观点',de:'Ich glaube, dass …',zh:'我认为……',task:'写一句观点，再补一句理由。'},
  {id:'a2-reason-1',level:'A2',skill:'writing',purpose:'给理由',de:'Der Grund dafür ist, dass …',zh:'原因是……',task:'围绕学习/生活主题补完整。'},
  {id:'a2-contrast-1',level:'A2',skill:'writing',purpose:'转折',de:'Einerseits …, andererseits …',zh:'一方面……，另一方面……',task:'写一个真实的两面性判断。'},
  {id:'a2-plan-1',level:'A2',skill:'speaking',purpose:'共同计划',de:'Wie wäre es, wenn wir …?',zh:'我们……怎么样？',task:'提出一个计划，再给一个替代方案。'},
  {id:'a2-agree-1',level:'A2',skill:'speaking',purpose:'同意',de:'Das finde ich auch.',zh:'我也这么认为。',task:'再补一句原因，不只停在同意。'},
  {id:'a2-disagree-1',level:'A2',skill:'speaking',purpose:'不同意见',de:'Ich sehe das ein bisschen anders.',zh:'我的看法有一点不同。',task:'后接 weil，完整说出理由。'},
  {id:'a2-email-1',level:'A2',skill:'writing',purpose:'邮件开头',de:'Vielen Dank für deine / Ihre Nachricht.',zh:'谢谢你的 / 您的消息。',task:'接一句回应对方内容。'},
  {id:'a2-email-2',level:'A2',skill:'writing',purpose:'邮件请求',de:'Ich möchte dich / Sie bitten, …',zh:'我想请你 / 您……',task:'写一个真实请求。'},
  {id:'a2-sequence-1',level:'A2',skill:'speaking',purpose:'叙述顺序',de:'Zuerst …, dann … und zum Schluss …',zh:'首先……，然后……，最后……',task:'用三步复述今天做过的一件事。'},
  {id:'a2-experience-1',level:'A2',skill:'speaking',purpose:'经验',de:'Ich habe die Erfahrung gemacht, dass …',zh:'我的经验是……',task:'用学习经历完成一句。'},
  {id:'b1-opinion-1',level:'B1',skill:'writing',purpose:'观点',de:'Meiner Meinung nach …',zh:'在我看来……',task:'用一个完整句表达观点并给理由。'},
  {id:'b1-example-1',level:'B1',skill:'writing',purpose:'举例',de:'Ein Beispiel dafür ist …',zh:'一个例子是……',task:'给上一条观点补具体例子。'},
  {id:'b1-concession-1',level:'B1',skill:'writing',purpose:'让步',de:'Zwar …, aber …',zh:'虽然……，但是……',task:'用同一主题写一个让步句。'},
  {id:'b1-consequence-1',level:'B1',skill:'writing',purpose:'结果',de:'Deshalb / Aus diesem Grund …',zh:'因此 / 出于这个原因……',task:'检查连接副词后的 V2 语序。'},
  {id:'b1-presentation-1',level:'B1',skill:'speaking',purpose:'短讲开头',de:'Heute möchte ich über … sprechen.',zh:'今天我想谈谈……',task:'选一个主题说 60 秒。'},
  {id:'b1-presentation-2',level:'B1',skill:'speaking',purpose:'组织短讲',de:'Zuerst …, danach …, schließlich …',zh:'首先……，之后……，最后……',task:'按三点结构说 90 秒。'},
  {id:'b1-react-1',level:'B1',skill:'speaking',purpose:'回应观点',de:'Da stimme ich dir / Ihnen zu, weil …',zh:'我同意你的 / 您的观点，因为……',task:'理由至少包含一个具体例子。'},
  {id:'b1-react-2',level:'B1',skill:'speaking',purpose:'部分同意',de:'Da stimme ich nur teilweise zu.',zh:'这一点我只部分同意。',task:'说明同意什么、不同意什么。'},
  {id:'b1-formal-1',level:'B1',skill:'writing',purpose:'正式询问',de:'Ich möchte mich erkundigen, ob …',zh:'我想询问是否……',task:'写一个与课程/考试有关的正式问题。'},
  {id:'b1-summary-1',level:'B1',skill:'writing',purpose:'总结',de:'Zusammenfassend kann man sagen, dass …',zh:'总的来说，可以说……',task:'用一句话总结今天的一段阅读。'},
  {id:'b2-opinion-1',level:'B2',skill:'writing',purpose:'观点',de:'Meines Erachtens …',zh:'在我看来……',task:'写观点 + 两个理由。'},
  {id:'b2-opinion-2',level:'B2',skill:'writing',purpose:'观点',de:'Ich bin der Auffassung, dass …',zh:'我认为……',task:'避免和前一句重复，用同义改写。'},
  {id:'b2-structure-1',level:'B2',skill:'writing',purpose:'结构',de:'Einerseits …, andererseits …',zh:'一方面……，另一方面……',task:'用同一议题展开正反两面。'},
  {id:'b2-add-1',level:'B2',skill:'writing',purpose:'补充',de:'Hinzu kommt, dass …',zh:'此外……',task:'补一个不同维度的理由。'},
  {id:'b2-reason-1',level:'B2',skill:'writing',purpose:'论证',de:'Ein wesentlicher Grund dafür ist, dass …',zh:'一个重要原因是……',task:'后接完整从句。'},
  {id:'b2-pro-1',level:'B2',skill:'writing',purpose:'支持',de:'Dafür spricht vor allem, dass …',zh:'支持这一点的主要理由是……',task:'给出论据，不只重复观点。'},
  {id:'b2-contra-1',level:'B2',skill:'writing',purpose:'反方',de:'Dagegen lässt sich einwenden, dass …',zh:'反过来可以指出……',task:'主动构造一个反方论点。'},
  {id:'b2-example-1',level:'B2',skill:'writing',purpose:'举例',de:'Ein gutes Beispiel dafür ist …',zh:'一个很好的例子是……',task:'例子必须具体。'},
  {id:'b2-concession-1',level:'B2',skill:'writing',purpose:'让步',de:'Zwar …, jedoch …',zh:'虽然……，但是……',task:'检查两边的逻辑是否真正构成让步。'},
  {id:'b2-summary-1',level:'B2',skill:'writing',purpose:'结论',de:'Zusammenfassend lässt sich sagen, dass …',zh:'总的来说，可以说……',task:'用一句不重复原文的结论。'},
  {id:'b2-discuss-1',level:'B2',skill:'speaking',purpose:'部分同意',de:'Da stimme ich dir / Ihnen nur teilweise zu.',zh:'这一点我只部分同意。',task:'立刻补充原因。'},
  {id:'b2-discuss-2',level:'B2',skill:'speaking',purpose:'不同观点',de:'Ich sehe das etwas anders, weil …',zh:'我的看法略有不同，因为……',task:'说出一个完整反例。'},
  {id:'b2-discuss-3',level:'B2',skill:'speaking',purpose:'提出方案',de:'Was hältst du / halten Sie davon, wenn …?',zh:'如果……你 / 您觉得如何？',task:'给出可执行建议。'},
  {id:'b2-talk-1',level:'B2',skill:'speaking',purpose:'短讲开头',de:'Zunächst möchte ich kurz auf … eingehen.',zh:'首先我想简要谈谈……',task:'后接第一个论点。'},
  {id:'b2-talk-2',level:'B2',skill:'speaking',purpose:'推进短讲',de:'Ein weiterer wichtiger Punkt ist …',zh:'另一个重要方面是……',task:'换一个角度继续。'},
  {id:'b2-talk-3',level:'B2',skill:'speaking',purpose:'收尾过渡',de:'Damit komme ich zum letzten Punkt.',zh:'这样我进入最后一点。',task:'接最后一个观点和总结。'},
  {id:'b2-formal-1',level:'B2',skill:'writing',purpose:'正式写作',de:'Ich wende mich an Sie, weil …',zh:'我写信给您是因为……',task:'用职业/学校场景补全。'},
  {id:'b2-formal-2',level:'B2',skill:'writing',purpose:'正式请求',de:'Ich wäre Ihnen dankbar, wenn Sie …',zh:'如果您能……我将非常感谢。',task:'补一个明确请求。'},
  {id:'b2-formal-3',level:'B2',skill:'writing',purpose:'正式询问',de:'Könnten Sie mir bitte mitteilen, ob …?',zh:'能否请您告知是否……？',task:'写成完整邮件中的一句。'},
  {id:'b2-link-1',level:'B2',skill:'writing',purpose:'连接',de:'Darüber hinaus …',zh:'除此之外……',task:'补充不同类型的信息。'},
  {id:'b2-compare-1',level:'B2',skill:'writing',purpose:'比较',de:'Im Vergleich zu …',zh:'与……相比……',task:'造一个有比较基准的句子。'},
  {id:'b2-impact-1',level:'B2',skill:'writing',purpose:'结果',de:'Das hat zur Folge, dass …',zh:'这会导致……',task:'区分原因与结果。'},
  {id:'b2-eval-1',level:'B2',skill:'writing',purpose:'评价',de:'Problematisch daran ist, dass …',zh:'其中的问题在于……',task:'指出具体问题而不是泛泛评价。'},
]

export function activeReferenceLevel(settings:Settings):GoetheReferenceLevel{
  const phaseDays = (()=>{
    const todayKey=new Intl.DateTimeFormat('en-CA',{timeZone:settings.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())
    const dayNumber=(key:string)=>{const [y,m,d]=key.split('-').map(Number);return Math.floor(Date.UTC(y,m-1,d)/86400000)}
    return Math.max(0,dayNumber(settings.b2_target_date)-dayNumber(todayKey))
  })()
  if(phaseDays>90) return settings.b2_current_level==='A1'?'A1':settings.b2_current_level==='A2'?'A2':'B1'
  if(phaseDays>60) return settings.b2_current_level==='A1'?'A2':'B1'
  if(phaseDays>30) return 'B1'
  return 'B2'
}

export function redemittelFor(level:GoetheReferenceLevel,skill?:TrainingSkill|'general'){
  return redemittel.filter(x=>x.level===level && (!skill || x.skill===skill || x.skill==='general'))
}

export function dailyRedemittel(settings:Settings,offset=0){
  const level=activeReferenceLevel(settings)
  const pool=redemittelFor(level)
  const todayKey=new Intl.DateTimeFormat('en-CA',{timeZone:settings.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())
  const key=Number(todayKey.replaceAll('-',''))+offset
  return pool[Math.abs(key)%Math.max(1,pool.length)] || redemittel[0]
}
