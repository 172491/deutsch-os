import { FormEvent, useEffect, useMemo, useRef, useState } from 'react'
import { cloudConfigured, supabase } from './supabase'
import { grammarItems } from './demo'
import { parseBulkInput } from './importer'
import { previewSchedule, retrievability, scheduleReview } from './fsrs'
import { resolveToken, sentenceAround } from './morphology'
import { coreLexicon, isInPersonalLexicon, lexiconDisplay, lexiconStats, lexiconToWord, lookupLexiconToken } from './lexicon'
import { disableWebPush, enableWebPush, notificationSupport, showTestNotification } from './notifications'
import { entriesForBook, entryCovered, getNextTextbookEntries, textbookBooks, textbookEntryDisplay, textbookLexicon, textbookPlanStats, textbookToWord, textbookUnitForEntry, textbookUnitStats, textbookExampleCoverage, unitsForLesson } from './textbook'
import { contentRevisionStats } from './content'
import { buildSprintTasks, defaultB2TargetDate, examModules, GOETHE_B2_URL, moduleStats, recommendedDailyNew, sprintDaysRemaining, sprintPhase, sprintPhases, sprintWeek, weeklyMilestones } from './b2'
import { activeReferenceLevel, dailyRedemittel, goetheCalibration, goetheReferenceStats, redemittelFor, sourceMaterials } from './goethe'
import type { B2PracticeKind, B2PracticeSession, B2TrainingArea, ImportDraft, LexiconEntry, MemoryCard, ReviewEvent, ReviewMode, ReviewRating, Settings, StudySession, TextbookEntry, Word } from './types'

type View = 'today' | 'sprint' | 'review' | 'words' | 'reader' | 'grammar' | 'settings'
type SessionUser = { id: string; email?: string } | null
type ReviewTask = { key: string; word: Word; mode: ReviewMode; card?: MemoryCard }

const STORAGE_WORDS = 'deutsch-os.words.v1'
const STORAGE_SETTINGS = 'deutsch-os.settings.v1'
const STORAGE_MINUTES = 'deutsch-os.minutes.v2'
const STORAGE_STUDY_SESSIONS = 'deutsch-os.study-sessions.v1'
const STORAGE_B2_PRACTICE = 'deutsch-os.b2-practice.v1'
const STORAGE_CARDS = 'deutsch-os.cards.v1.1'
const STORAGE_LOGS = 'deutsch-os.logs.v1.1'
const STORAGE_LAST_REMINDER = 'deutsch-os.last-reminder.v1.1'

const defaultSettings: Settings = {
  daily_new: 12,
  daily_personal_new: 5,
  reminder_time: '21:30',
  reminder_enabled: true,
  push_enabled: false,
  daily_goal_minutes: 15,
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Tokyo',
  request_retention: 0.9,
  textbook_plan_enabled: true,
  active_textbook_book: 1,
  active_textbook_lesson: 0,
  active_textbook_unit: 1,
  textbook_only_translated: true,
  b2_sprint_enabled: true,
  b2_target_date: defaultB2TargetDate(120),
  b2_current_level: 'A1',
  b2_daily_minutes: 240,
}

function readJson<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback } catch { return fallback }
}
function readLocalWords() {
  const words = readJson<Word[]>(STORAGE_WORDS, [])
  return words.filter(w => !isLegacyDemo(w))
}
function readLocalSettings() { return { ...defaultSettings, ...readJson<Partial<Settings>>(STORAGE_SETTINGS, {}) } }
function isLegacyDemo(w: Word) { return ['w1','w2','w3','w4','w5','w6'].includes(w.id) }

export default function App() {
  const [view, setView] = useState<View>('today')
  const [words, setWords] = useState<Word[]>(readLocalWords)
  const [cards, setCards] = useState<MemoryCard[]>(() => readJson(STORAGE_CARDS, []))
  const [logs, setLogs] = useState<ReviewEvent[]>(() => readJson(STORAGE_LOGS, []))
  const [settings, setSettings] = useState<Settings>(readLocalSettings)
  const [studySessions, setStudySessions] = useState<StudySession[]>(() => readJson(STORAGE_STUDY_SESSIONS, migrateLegacyStudySessions()))
  const [practiceSessions, setPracticeSessions] = useState<B2PracticeSession[]>(() => readJson(STORAGE_B2_PRACTICE, []))
  const [user, setUser] = useState<SessionUser>(null)
  const [syncState, setSyncState] = useState<'local'|'syncing'|'synced'|'error'>(cloudConfigured ? 'syncing' : 'local')
  const [toast, setToast] = useState('')

  useEffect(() => { localStorage.setItem(STORAGE_WORDS, JSON.stringify(words)) }, [words])
  useEffect(() => { localStorage.setItem(STORAGE_CARDS, JSON.stringify(cards)) }, [cards])
  useEffect(() => { localStorage.setItem(STORAGE_LOGS, JSON.stringify(logs.slice(-3000))) }, [logs])
  useEffect(() => { localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings)) }, [settings])
  useEffect(() => { localStorage.setItem(STORAGE_B2_PRACTICE, JSON.stringify(practiceSessions.slice(-1000))) }, [practiceSessions])
  useEffect(() => {
    localStorage.setItem(STORAGE_STUDY_SESSIONS, JSON.stringify(studySessions.slice(-300)))
    // Keep the old daily-minute store as a backward-compatible summary for older exports.
    const byDate: Record<string, number> = {}
    for (const session of studySessions) byDate[session.date] = (byDate[session.date] || 0) + session.seconds / 60
    const trimmed = Object.fromEntries(Object.entries(byDate).sort(([a],[b])=>a.localeCompare(b)).slice(-90))
    localStorage.setItem(STORAGE_MINUTES, JSON.stringify(trimmed))
  }, [studySessions])

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user
      setUser(u ? { id: u.id, email: u.email } : null)
      setSyncState(u ? 'syncing' : 'local')
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user
      setUser(u ? { id: u.id, email: u.email } : null)
      if (!u) setSyncState('local')
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!supabase || !user) return
    let cancelled = false
    ;(async () => {
      setSyncState('syncing')
      const [wordRes, cardRes, logRes, settingRes, studyRes, practiceRes] = await Promise.all([
        supabase.from('words').select('*').order('created_at', { ascending: true }),
        supabase.from('review_cards').select('*'),
        supabase.from('review_logs').select('*').order('reviewed_at', { ascending: true }).limit(3000),
        supabase.from('user_settings').select('*').maybeSingle(),
        supabase.from('study_sessions').select('*').order('started_at', { ascending: true }).limit(3000),
        supabase.from('b2_practice_sessions').select('*').order('created_at', { ascending: true }).limit(3000),
      ])
      if (cancelled) return
      if (wordRes.error || cardRes.error || logRes.error || studyRes.error || practiceRes.error) { setSyncState('error'); return }

      const cloudWords = (wordRes.data || []) as Word[]
      const localWords = words.filter(w => !isLegacyDemo(w))
      const wordMap = new Map<string, Word>()
      cloudWords.forEach(w=>wordMap.set(w.id,w))
      const localNewer: Word[] = []
      localWords.forEach(local=>{
        const cloud = wordMap.get(local.id)
        if (!cloud || new Date(local.updated_at).getTime() > new Date(cloud.updated_at).getTime()) { wordMap.set(local.id,local); localNewer.push(local) }
      })
      const mergedWords = [...wordMap.values()]
      setWords(mergedWords)
      if (localNewer.length) {
        const { error } = await supabase.from('words').upsert(localNewer.map(w => ({ ...w, user_id: user.id })))
        if (error) { setSyncState('error'); return }
      }

      const cloudCards = (cardRes.data || []) as MemoryCard[]
      const localCardMap = new Map<string,MemoryCard>()
      cards.forEach(c=>localCardMap.set(`${c.word_id}:${c.mode}`,c))
      cloudCards.forEach(c=>{
        const key=`${c.word_id}:${c.mode}`; const local=localCardMap.get(key)
        if (!local || new Date(c.updated_at).getTime() > new Date(local.updated_at).getTime()) localCardMap.set(key,c)
      })
      const mergedCards=[...localCardMap.values()]
      setCards(mergedCards)
      const cloudCardByKey=new Map(cloudCards.map(c=>[`${c.word_id}:${c.mode}`,c]))
      const localNewerCards=cards.filter(c=>{const cloud=cloudCardByKey.get(`${c.word_id}:${c.mode}`);return !cloud || new Date(c.updated_at).getTime()>new Date(cloud.updated_at).getTime()})
      if(localNewerCards.length){const {error}=await supabase.from('review_cards').upsert(localNewerCards.map(c=>({...c,user_id:user.id})),{onConflict:'user_id,word_id,mode'});if(error){setSyncState('error');return}}

      const cloudLogs = (logRes.data || []) as ReviewEvent[]
      const logMap=new Map<string,ReviewEvent>(cloudLogs.map(l=>[l.id,l]))
      const localNewLogs=logs.filter(l=>!logMap.has(l.id))
      logs.forEach(l=>logMap.set(l.id,logMap.get(l.id)||l))
      const mergedLogs=[...logMap.values()].sort((a,b)=>new Date(a.reviewed_at).getTime()-new Date(b.reviewed_at).getTime()).slice(-3000)
      setLogs(mergedLogs)
      if(localNewLogs.length){const {error}=await supabase.from('review_logs').upsert(localNewLogs.map(l=>({...l,user_id:user.id})),{onConflict:'id'});if(error){setSyncState('error');return}}

      const cloudStudy = (studyRes.data || []) as StudySession[]
      const localStudy = studySessions
      const studyMap = new Map<string,StudySession>()
      cloudStudy.forEach(x=>studyMap.set(x.id,x))
      localStudy.forEach(x=>studyMap.set(x.id,studyMap.get(x.id)||x))
      const mergedStudy = [...studyMap.values()].sort((a,b)=>new Date(a.started_at).getTime()-new Date(b.started_at).getTime()).slice(-300)
      setStudySessions(mergedStudy)
      const cloudStudyIds = new Set(cloudStudy.map(x=>x.id))
      const newStudy = localStudy.filter(x=>!cloudStudyIds.has(x.id))
      if(newStudy.length){const {error}=await supabase.from('study_sessions').upsert(newStudy.map(x=>({...x,user_id:user.id})),{onConflict:'id'});if(error){setSyncState('error');return}}

      const cloudPractice=(practiceRes.data||[]) as B2PracticeSession[]
      const practiceMap=new Map<string,B2PracticeSession>(cloudPractice.map(x=>[x.id,x]))
      const localNewPractice=practiceSessions.filter(x=>!practiceMap.has(x.id))
      practiceSessions.forEach(x=>practiceMap.set(x.id,practiceMap.get(x.id)||x))
      const mergedPractice=[...practiceMap.values()].sort((a,b)=>new Date(a.created_at).getTime()-new Date(b.created_at).getTime()).slice(-1000)
      setPracticeSessions(mergedPractice)
      if(localNewPractice.length){const {error}=await supabase.from('b2_practice_sessions').upsert(localNewPractice.map(x=>({...x,user_id:user.id})),{onConflict:'id'});if(error){setSyncState('error');return}}

      if (settingRes.data) setSettings({ ...defaultSettings, ...settingRes.data })
      else await supabase.from('user_settings').upsert({ user_id: user.id, ...settings })
      setSyncState('synced')
    })()
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const newWords = useMemo(() => words.filter(w => w.status !== 'mastered' && Boolean(w.introduced_on) && !cards.some(c => c.word_id === w.id)), [words, cards])
  const dueCount = useMemo(() => buildReviewQueue(words, cards, settings.daily_new, settings.daily_personal_new).length, [words, cards, settings.daily_new, settings.daily_personal_new])

  useEffect(() => {
    if (!settings.reminder_enabled || !notificationSupport()) return
    const tick = async () => {
      const local = new Intl.DateTimeFormat('en-GB', { timeZone: settings.timezone, hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date())
      if (local !== settings.reminder_time || dueCount <= 0 || Notification.permission !== 'granted') return
      const today = new Intl.DateTimeFormat('en-CA', { timeZone: settings.timezone, year:'numeric', month:'2-digit', day:'2-digit' }).format(new Date())
      if (localStorage.getItem(STORAGE_LAST_REMINDER) === today) return
      localStorage.setItem(STORAGE_LAST_REMINDER, today)
      await showTestNotification(dueCount)
    }
    tick()
    const timer = window.setInterval(tick, 30000)
    return () => window.clearInterval(timer)
  }, [settings.reminder_enabled, settings.reminder_time, settings.timezone, dueCount])

  function flash(message: string) { setToast(message); window.setTimeout(() => setToast(''), 2600) }

  async function persistWord(word: Word) {
    setWords(prev => prev.some(w => w.id === word.id) ? prev.map(w => w.id === word.id ? word : w) : [word, ...prev])
    if (supabase && user) {
      setSyncState('syncing')
      const { error } = await supabase.from('words').upsert({ ...word, user_id: user.id })
      setSyncState(error ? 'error' : 'synced')
    }
  }
  async function persistWords(batch: Word[]) {
    if (!batch.length) return
    setWords(prev => {
      const byId = new Map(prev.map(w => [w.id, w])); batch.forEach(w => byId.set(w.id, w)); return [...byId.values()]
    })
    if (supabase && user) {
      setSyncState('syncing')
      const { error } = await supabase.from('words').upsert(batch.map(w => ({ ...w, user_id: user.id })))
      setSyncState(error ? 'error' : 'synced')
    }
  }
  async function removeWord(id: string) {
    setWords(prev => prev.filter(w => w.id !== id)); setCards(prev => prev.filter(c => c.word_id !== id)); setLogs(prev => prev.filter(l => l.word_id !== id))
    if (supabase && user) {
      setSyncState('syncing'); const { error } = await supabase.from('words').delete().eq('id', id); setSyncState(error ? 'error' : 'synced')
    }
  }
  async function persistCard(card: MemoryCard) {
    setCards(prev => prev.some(c => c.id === card.id) ? prev.map(c => c.id === card.id ? card : c) : [...prev, card])
    if (supabase && user) {
      const payload = { ...card, user_id: user.id }; const { error } = await supabase.from('review_cards').upsert(payload, { onConflict: 'user_id,word_id,mode' }); if (error) setSyncState('error')
    }
  }
  async function persistLog(log: ReviewEvent) {
    setLogs(prev => [...prev, log])
    if (supabase && user) {
      const { error } = await supabase.from('review_logs').insert({ ...log, user_id: user.id }); if (error) setSyncState('error')
    }
  }
  async function persistStudySession(session: StudySession) {
    if (session.seconds <= 0) return
    setStudySessions(prev => [...prev, session].slice(-300))
    if (supabase && user) {
      setSyncState('syncing')
      const { error } = await supabase.from('study_sessions').upsert({ ...session, user_id: user.id }, { onConflict: 'id' })
      setSyncState(error ? 'error' : 'synced')
    }
  }

  async function persistPracticeSession(session: B2PracticeSession) {
    setPracticeSessions(prev => [...prev.filter(x=>x.id!==session.id), session].sort((a,b)=>new Date(a.created_at).getTime()-new Date(b.created_at).getTime()).slice(-1000))
    if (supabase && user) {
      setSyncState('syncing')
      const { error } = await supabase.from('b2_practice_sessions').upsert({ ...session, user_id: user.id }, { onConflict: 'id' })
      setSyncState(error ? 'error' : 'synced')
    }
  }
  async function removePracticeSession(id:string) {
    setPracticeSessions(prev=>prev.filter(x=>x.id!==id))
    if(supabase&&user){const {error}=await supabase.from('b2_practice_sessions').delete().eq('id',id);if(error)setSyncState('error')}
  }

  async function persistSettings(next: Settings) {
    setSettings(next)
    if (supabase && user) {
      setSyncState('syncing'); const { error } = await supabase.from('user_settings').upsert({ user_id: user.id, ...next }); setSyncState(error ? 'error' : 'synced')
    }
  }

  async function startLearning() {
    const today = dateKeyInTimezone(settings.timezone)
    let working = words

    // Personal intake is independent from the textbook quota. Explicitly added single
    // words are introduced immediately; only imported/unintroduced backlog uses this quota.
    const personalIntroducedToday = words.filter(w => !w.textbook_entry_id && w.introduced_on===today).length
    let personalSlots = Math.max(0, settings.daily_personal_new - personalIntroducedToday)
    if (personalSlots > 0) {
      const backlog = words
        .filter(w => !w.textbook_entry_id && w.status!=='mastered' && !cards.some(c=>c.word_id===w.id) && !w.introduced_on)
        .sort((a,b)=>new Date(a.created_at).getTime()-new Date(b.created_at).getTime())
        .slice(0, personalSlots)
        .map(w=>({...w, introduced_on: today, updated_at: new Date().toISOString()}))
      if (backlog.length) {
        await persistWords(backlog)
        working = words.map(w=>backlog.find(x=>x.id===w.id)||w)
      }
    }

    // Textbook intake has its own quota and advances only through the selected lesson/unit.
    const textbookIntroducedToday = working.filter(w => Boolean(w.textbook_entry_id) && w.introduced_on===today).length
    const textbookSlots = Math.max(0, settings.daily_new - textbookIntroducedToday)
    if (settings.textbook_plan_enabled && textbookSlots > 0) {
      const batch = getNextTextbookEntries(settings, working, textbookSlots).map(e=>({...textbookToWord(e,settings.textbook_only_translated), introduced_on: today}))
      if (batch.length) await persistWords(batch)
    }
    setView('review')
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand" onClick={() => setView('today')}><span className="brand-mark">D</span><span>Deutsch</span><sup>1.8</sup></div>
      <nav>
        <NavButton active={view === 'today'} onClick={() => setView('today')} label="今日" icon="⌂" />
        <NavButton active={view === 'sprint'} onClick={() => setView('sprint')} label="B2 冲刺" icon="16" />
        <NavButton active={view === 'review'} onClick={() => setView('review')} label="学习" icon="◫" />
        <NavButton active={view === 'words'} onClick={() => setView('words')} label="词库" icon="Aa" />
        <NavButton active={view === 'reader'} onClick={() => setView('reader')} label="阅读" icon="¶" />
        <NavButton active={view === 'grammar'} onClick={() => setView('grammar')} label="语法" icon="∴" />
      </nav>
      <div className="sidebar-bottom">
        <button className="nav-button" onClick={() => setView('settings')}><span>⚙</span><span>设置</span></button>
        <div className="sync-pill"><span className={`sync-dot ${syncState}`} />{syncState === 'synced' ? '已同步' : syncState === 'syncing' ? '同步中' : syncState === 'error' ? '同步异常' : '本地模式'}</div>
      </div>
    </aside>

    <main className="main">
      <header className="mobile-header"><div className="brand"><span className="brand-mark">D</span><span>Deutsch</span><sup>1.8</sup></div><button className="icon-btn" onClick={() => setView('settings')}>⚙</button></header>
      {view === 'today' && <Today words={words} cards={cards} logs={logs} dueCount={dueCount} newCount={newWords.length} studySeconds={todayStudySeconds(studySessions, settings.timezone)} practiceSessions={practiceSessions} settings={settings} onStart={startLearning} onGoWords={() => setView('words')} onGoSprint={() => setView('sprint')} />}
      {view === 'sprint' && <B2Sprint settings={settings} practiceSessions={practiceSessions} studySessions={studySessions} onSaveSettings={persistSettings} onLog={persistPracticeSession} onRemoveLog={removePracticeSession} flash={flash} />}
      {view === 'review' && <Review words={words} cards={cards} settings={settings} onPersistCard={persistCard} onPersistLog={persistLog} onPersistWord={persistWord} onDone={(count,session) => { if(session) void persistStudySession(session); setView('today'); flash(`完成 ${count} 个复习项目 · ${formatStudyDuration(session?.seconds||0)}`) }} />}
      {view === 'words' && <Words words={words} cards={cards} settings={settings} onSaveSettings={persistSettings} onStart={startLearning} onPersist={persistWord} onBulkPersist={persistWords} onRemove={removeWord} flash={flash} />}
      {view === 'reader' && <Reader words={words} settings={settings} onPersist={persistWord} flash={flash} />}
      {view === 'grammar' && <Grammar />}
      {view === 'settings' && <SettingsPanel settings={settings} onSave={persistSettings} user={user} setUser={setUser} flash={flash} dueCount={dueCount} />}
    </main>

    <nav className="mobile-nav">
      <MobileNav active={view === 'today'} label="今日" icon="⌂" onClick={() => setView('today')} />
      <MobileNav active={view === 'sprint'} label="B2" icon="16" onClick={() => setView('sprint')} />
      <MobileNav active={view === 'review'} label="学习" icon="◫" onClick={() => setView('review')} />
      <MobileNav active={view === 'words'} label="词库" icon="Aa" onClick={() => setView('words')} />
      <MobileNav active={view === 'reader'} label="阅读" icon="¶" onClick={() => setView('reader')} />
      <MobileNav active={view === 'grammar'} label="语法" icon="∴" onClick={() => setView('grammar')} />
    </nav>
    {toast && <div className="toast">{toast}</div>}
  </div>
}

function NavButton({active, onClick, label, icon}:{active:boolean;onClick:()=>void;label:string;icon:string}) { return <button className={`nav-button ${active?'active':''}`} onClick={onClick}><span className="nav-icon">{icon}</span><span>{label}</span></button> }
function MobileNav({active, onClick, label, icon}:{active:boolean;onClick:()=>void;label:string;icon:string}) { return <button className={active?'active':''} onClick={onClick}><span>{icon}</span><small>{label}</small></button> }

function Today({words,cards,logs,dueCount,newCount,studySeconds,practiceSessions,settings,onStart,onGoWords,onGoSprint}:{words:Word[];cards:MemoryCard[];logs:ReviewEvent[];dueCount:number;newCount:number;studySeconds:number;practiceSessions:B2PracticeSession[];settings:Settings;onStart:()=>void;onGoWords:()=>void;onGoSprint:()=>void}) {
  const todayKey=dateKeyInTimezone(settings.timezone)
  const practiceMinutes=practiceSessions.filter(x=>x.date===todayKey).reduce((sum,x)=>sum+x.minutes,0)
  const totalSprintMinutes=Math.round(studySeconds/60)+practiceMinutes
  const progress = Math.min(100, Math.round(totalSprintMinutes / Math.max(1,settings.b2_daily_minutes) * 100))
  const diagnostics = buildDiagnostics(logs, words)
  const activeCards = cards.filter(c => c.reps > 0)
  const retention = activeCards.length ? Math.round(avg(activeCards.map(c => retrievability(c, settings.request_retention))) * 100) : 0
  const plan = textbookPlanStats(settings,words)
  const book = textbookBooks.find(b=>b.book===settings.active_textbook_book)
  const today = todayKey
  const textbookIntroducedToday = words.filter(w=>Boolean(w.textbook_entry_id) && w.introduced_on===today).length
  const personalIntroducedToday = words.filter(w=>!w.textbook_entry_id && w.introduced_on===today).length
  const textbookSlots = Math.max(0, settings.daily_new - textbookIntroducedToday)
  const unintroducedBacklog = words.filter(w=>!w.textbook_entry_id && w.status!=='mastered' && !cards.some(c=>c.word_id===w.id) && !w.introduced_on).length
  const personalBacklogSlots = Math.max(0, settings.daily_personal_new - personalIntroducedToday)
  const plannedPersonalBacklog = Math.min(unintroducedBacklog, personalBacklogSlots)
  const plannedTextbookNew = settings.textbook_plan_enabled ? getNextTextbookEntries(settings,words,textbookSlots).length : 0
  const nextEntry=settings.textbook_plan_enabled?getNextTextbookEntries(settings,words,1)[0]:undefined
  const activeLesson=nextEntry?.lesson ?? settings.active_textbook_lesson
  const activeUnit=nextEntry?textbookUnitForEntry(nextEntry,settings.textbook_only_translated):(settings.active_textbook_unit||1)
  const activeLessonInfo=book?.lessons.find(l=>l.lesson===activeLesson)
  const plannedCount=dueCount + plannedPersonalBacklog + plannedTextbookNew
  return <section className="page today-page">
    <div className="eyebrow">HEUTE</div><h1>{greeting()}</h1><p className="lead">词汇 FSRS 只是冲 B2 的一个部件。今天同时推进听、读、写/说；到后半程逐步切到真实题型和限时模考。</p>
    <div className="hero-grid">
      <button className="review-hero" onClick={onStart}><span className="hero-kicker">词汇学习队列</span><strong>{plannedCount}</strong><span className="hero-action">开始今天的词汇学习 <b>→</b></span></button>
      <div className="today-side"><div className="metric-card"><span>今日教材新词额度</span><strong>{Math.max(0,textbookSlots)}</strong><small>教材 {textbookIntroducedToday}/{settings.daily_new} · 个人已引入 {personalIntroducedToday}/{settings.daily_personal_new} · 批量待引入 {unintroducedBacklog}</small></div><div className="metric-card"><span>当前记忆保持</span><strong>{retention}<em>%</em></strong><small>FSRS 估计</small></div></div>
    </div>
    {settings.b2_sprint_enabled && <div className="panel sprint-mini"><div className="panel-head"><div><span className="course-kicker">16 周 B2 SPRINT</span><h2>第 {sprintWeek(settings.b2_target_date,settings.timezone)} 周 · {sprintPhase(sprintWeek(settings.b2_target_date,settings.timezone)).title}</h2></div><button className="text-button" onClick={onGoSprint}>打开冲刺台 →</button></div><div className="sprint-mini-grid"><div><strong>{sprintDaysRemaining(settings.b2_target_date,settings.timezone)}</strong><span>距目标日</span></div><div><strong>{totalSprintMinutes}</strong><span>今日总训练分钟</span></div><div><strong>{recommendedDailyNew(settings.b2_current_level,sprintDaysRemaining(settings.b2_target_date,settings.timezone))}</strong><span>系统建议新词/日</span></div></div><div className="sprint-task-preview">{buildSprintTasks(settings,practiceSessions).slice(1,4).map(t=><span key={t.id}><b>{trainingAreaName(t.area)}</b>{t.title} · {t.minutes} min</span>)}</div></div>}
    {settings.textbook_plan_enabled && book ? <div className="panel course-now"><div className="panel-head"><div><span className="course-kicker">当前学习位置</span><h2>《当代大学德语》学生用书 {book.book}</h2></div><button className="text-button" onClick={onGoWords}>切换起点 →</button></div><div className="course-now-body"><div><strong>{activeLesson===0?'Vorkurs':`Lektion ${activeLesson}`} · 单元 {activeUnit}</strong><span>{activeLessonInfo?.title || '按课次继续学习'}</span></div><div className="course-progress-meta"><b>{plan.done} / {plan.total}</b><span>已引入 · 已掌握 {plan.mastered}</span></div></div><div className="progress"><i style={{width:`${plan.percent}%`}} /></div><small className="course-note">每课按教材原始顺序拆成约 18 个可学习词的单元；一个单元结束后会继续下一个单元，再进入下一课。</small></div> : <div className="panel course-now"><div className="panel-head"><div><span className="course-kicker">教材词书</span><h2>尚未启用</h2></div><button className="primary-button compact" onClick={onGoWords}>选择词书</button></div><p className="muted">选择一次之后，每天不需要再逐个点击“＋”。</p></div>}
    <div className="section-grid">
      <div className="panel"><div className="panel-head"><h2>今日进度</h2><span>{progress}%</span></div><div className="progress"><i style={{width:`${progress}%`}} /></div><div className="split-stats"><div><strong>{dueCount}</strong><span>已排入复习 / 学习</span></div><div><strong>{newCount}</strong><span>今日已引入未开始</span></div><div><strong>{totalSprintMinutes} min</strong><span>今日总训练（含词汇）</span></div></div></div>
      <div className="panel"><div className="panel-head"><h2>30 天诊断</h2><span>{diagnostics.total} 次复习</span></div>{diagnostics.total ? <div className="weak-list">{diagnostics.modes.slice(0,5).map(x => <div className="weak-row" key={x.mode}><span>{modeName(x.mode)}</span><div className="mini-progress"><i style={{width:`${Math.min(100,x.weight*10)}%`}} /></div><b>{x.again} 错</b></div>)}</div> : <p className="muted diagnostic-empty">完成几轮复习后，这里会按词义、性别/冠词、复数、拼写和动词变位显示薄弱点。</p>}</div>
    </div>
    {diagnostics.topWords.length > 0 && <div className="panel diagnosis-panel"><div className="panel-head"><h2>最近反复出错</h2><span>Again + Hard</span></div><div className="source-list">{diagnostics.topWords.map(x => <div className="source-row" key={x.word.id}><div><span className="source-dot"/><strong>{displayLemma(x.word)}</strong></div><span>{x.count} 次</span></div>)}</div></div>}
    <div className="panel sources-panel"><div className="panel-head"><h2>我的学习词库</h2><button className="text-button" onClick={onGoWords}>查看教材词书与个人词库 →</button></div><div className="source-list">{groupSources(words).slice(0,5).map(([source,count]) => <div className="source-row" key={source}><div><span className="source-dot"/><strong>{source}</strong></div><span>{count} 词</span></div>)}</div></div>
  </section>
}

function Review({words,cards,settings,onPersistCard,onPersistLog,onPersistWord,onDone}:{words:Word[];cards:MemoryCard[];settings:Settings;onPersistCard:(c:MemoryCard)=>Promise<void>;onPersistLog:(l:ReviewEvent)=>Promise<void>;onPersistWord:(w:Word)=>Promise<void>;onDone:(count:number,session?:StudySession)=>void}) {
  const [queue] = useState<ReviewTask[]>(() => buildReviewQueue(words, cards, settings.daily_new, settings.daily_personal_new))
  const [index,setIndex] = useState(0)
  const [revealed,setRevealed] = useState(false)
  const [typed,setTyped] = useState('')
  const sessionStartedAt = useRef(Date.now())
  const activeSecondsRef = useRef(0)
  const lastTickRef = useRef(Date.now())
  const finishedRef = useRef(false)
  useEffect(() => {
    const tick = () => {
      const now = Date.now()
      if (document.visibilityState === 'visible' && !finishedRef.current) activeSecondsRef.current += Math.max(0, Math.min(2, (now-lastTickRef.current)/1000))
      lastTickRef.current = now
    }
    const timer=window.setInterval(tick,1000)
    const onVisibility=()=>{lastTickRef.current=Date.now()}
    document.addEventListener('visibilitychange',onVisibility)
    return ()=>{window.clearInterval(timer);document.removeEventListener('visibilitychange',onVisibility)}
  },[])
  const current = queue[index]
  if (!current) return <section className="page empty"><h1>今天已经清空。</h1><p>当前没有到期复习，也没有可引入的新词。</p></section>

  const { word, mode, card } = current
  const prompt = mode === 'meaning' ? displayLemma(word) : mode === 'article' ? word.lemma : mode === 'plural' ? displayLemma(word) : mode === 'conjugation' ? word.lemma : `请拼写：${word.translation}`
  const answer = mode === 'meaning' ? word.translation : mode === 'article' ? `${word.article || '—'} ${word.lemma} · ${genderLabel(word.article)}` : mode === 'plural' ? pluralDisplay(word) : mode === 'conjugation' ? '核心变位' : displayLemma(word)
  const preview = previewSchedule(card, settings.request_retention)
  const typedCorrect = mode === 'spelling' && typed.trim() ? normalizeAnswer(typed) === normalizeAnswer(displayLemma(word)) || normalizeAnswer(typed) === normalizeAnswer(word.lemma) : undefined
  const firstEncounter = !cards.some(c=>c.word_id===word.id)

  function finishSession():StudySession|undefined {
    if (finishedRef.current) return undefined
    const now=new Date()
    if (document.visibilityState === 'visible') activeSecondsRef.current += Math.max(0, Math.min(2, (Date.now()-lastTickRef.current)/1000))
    finishedRef.current=true
    const session:StudySession={id:crypto.randomUUID(),date:dateKeyInTimezone(settings.timezone),seconds:Math.round(activeSecondsRef.current),started_at:new Date(sessionStartedAt.current).toISOString(),ended_at:now.toISOString()}
    return session.seconds>0?session:undefined
  }
  function advance(){setRevealed(false);setTyped('');if(index+1>=queue.length)onDone(queue.length,finishSession());else setIndex(i=>i+1)}
  async function rate(rating:ReviewRating) {
    const now = new Date()
    const next = scheduleReview(card, word.id, mode, rating, settings.request_retention, now)
    const log: ReviewEvent = { id: crypto.randomUUID(), word_id: word.id, mode, rating, reviewed_at: now.toISOString(), due_before: card?.due_at || now.toISOString(), due_after: next.due_at, scheduled_days: next.scheduled_days, stability: next.stability, difficulty: next.difficulty }
    await Promise.all([onPersistCard(next), onPersistLog(log)])
    if (word.status === 'new') await onPersistWord({ ...word, status: 'learning', updated_at: now.toISOString() })
    advance()
  }
  async function markKnown(){
    const now=new Date()
    for(const m of availableModes(word)){
      const old=cards.find(c=>c.word_id===word.id&&c.mode===m)
      const next=scheduleReview(old,word.id,m,'easy',settings.request_retention,now)
      await onPersistCard(next)
      await onPersistLog({id:crypto.randomUUID(),word_id:word.id,mode:m,rating:'easy',reviewed_at:now.toISOString(),due_before:old?.due_at||now.toISOString(),due_after:next.due_at,scheduled_days:next.scheduled_days,stability:next.stability,difficulty:next.difficulty})
    }
    await onPersistWord({...word,status:'mastered',updated_at:now.toISOString()})
    advance()
  }

  const hint=mode==='article'?'回忆冠词，并明确判断阳性 / 阴性 / 中性。':mode==='plural'?'回忆完整复数形式。':mode==='conjugation'?'回忆六个人称现在时、过去时和第二分词。':mode==='spelling'?'输入完整拼写；名词可带冠词。':'先回忆含义，再显示完整词形。'
  return <section className="review-page">
    <div className="review-top"><button className="ghost-button" onClick={() => onDone(index,finishSession())}>×</button><div className="review-progress"><i style={{width:`${((index+1)/queue.length)*100}%`}} /></div><span>{index+1} / {queue.length}</span></div>
    <div className="mode-chip">{firstEncounter?'新词 · ':''}{modeName(mode)}</div>
    <div className="flashcard">
      <div className="flash-main"><h1>{prompt}</h1>{mode !== 'spelling' && <button className="audio-button" onClick={() => speak(word.lemma)}>🔊 <span>发音</span></button>}<p className="flash-hint">{hint}</p>{mode === 'spelling' && !revealed && <input autoFocus className="spelling-input" value={typed} onChange={e=>setTyped(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')setRevealed(true)}} placeholder="输入德语…" />}</div>
      {!revealed ? <div className="reveal-actions"><button className="primary-button reveal" onClick={() => setRevealed(true)}>显示答案</button>{firstEncounter&&<button className="text-button known-button" onClick={markKnown}>这个词我已经会了</button>}</div> : <div className="answer-zone"><div className="answer">{typedCorrect !== undefined && <span className={`answer-check ${typedCorrect?'correct':'wrong'}`}>{typedCorrect?'拼写一致':'拼写不同，请对照'}</span>}<strong>{answer || '—'}</strong>{word.example_de && <p>{word.example_de}</p>}{word.example_zh && <small>{word.example_zh}</small>}<WordFacts word={word}/><div className="meta-line"><span>{word.part_of_speech||'词性待核对'}</span><span>{word.level}</span><span>{word.source}</span></div></div><div className="rating-row"><button onClick={()=>rate('again')}><b>重来</b><small>{relativeDue(preview.again)}</small></button><button onClick={()=>rate('hard')}><b>困难</b><small>{relativeDue(preview.hard)}</small></button><button onClick={()=>rate('good')}><b>记得</b><small>{relativeDue(preview.good)}</small></button><button onClick={()=>rate('easy')}><b>很熟</b><small>{relativeDue(preview.easy)}</small></button></div></div>}
    </div>
  </section>
}

function WordFacts({word}:{word:Word}){
  const isNoun=Boolean(word.article)||(word.part_of_speech||'').includes('名词')
  const isVerb=(word.part_of_speech||'').includes('动词') || Boolean(word.verb_forms && (word.verb_forms.present?.length || word.verb_forms.praeteritum || word.verb_forms.partizip_ii))
  if(isNoun){
    return <div className="word-facts noun-facts"><div className="facts-title">名词信息</div><div className="facts-grid"><div><small>性别</small><strong>{genderLabel(word.article)}</strong></div><div><small>单数</small><strong>{word.article?`${word.article} ${word.lemma}`:word.lemma}</strong></div><div><small>复数</small><strong>{pluralDisplay(word)}</strong></div></div></div>
  }
  if(isVerb){
    const p=word.verb_forms?.present || []
    return <div className="word-facts verb-facts"><div className="facts-title">动词变位</div><div className="conjugation-table"><span>ich <b>{p[0]||'—'}</b></span><span>du <b>{p[1]||'—'}</b></span><span>er/sie/es <b>{p[2]||'—'}</b></span><span>wir <b>{p[3]||'—'}</b></span><span>ihr <b>{p[4]||'—'}</b></span><span>sie/Sie <b>{p[5]||'—'}</b></span></div><div className="verb-principal"><div><small>Präteritum</small><strong>{word.verb_forms?.praeteritum||'—'}</strong></div><div><small>Partizip II</small><strong>{word.verb_forms?.partizip_ii||'—'}</strong></div><div><small>Perfekt</small><strong>{perfektForm(word.verb_forms)}</strong></div></div>{word.verb_forms?.separable_prefix&&<small className="fact-note">可分前缀：{word.verb_forms.separable_prefix}-</small>}</div>
  }
  return null
}

function Words({words,cards,settings,onSaveSettings,onStart,onPersist,onBulkPersist,onRemove,flash}:{words:Word[];cards:MemoryCard[];settings:Settings;onSaveSettings:(s:Settings)=>Promise<void>;onStart:()=>void;onPersist:(w:Word)=>Promise<void>;onBulkPersist:(w:Word[])=>Promise<void>;onRemove:(id:string)=>void;flash:(s:string)=>void}) {
  const [tab,setTab] = useState<'textbook'|'base'|'mine'>('textbook')
  const [query,setQuery] = useState('')
  const [editing,setEditing] = useState<Word|null>(null)
  const [bulk,setBulk] = useState(false)
  const [level,setLevel] = useState<'all'|'A1'|'A2'|'B1'>('all')
  const [pos,setPos] = useState<'all'|'NOUN'|'VERB'|'ADJADV'|'FUNCTION'>('all')
  const [translatedOnly,setTranslatedOnly] = useState(true)
  const [missingExamplesOnly,setMissingExamplesOnly] = useState(false)
  const [estimatedOnly,setEstimatedOnly] = useState(false)
  const [selectedLex,setSelectedLex] = useState<LexiconEntry|null>(null)
  const [selectedBook,setSelectedBook]=useState(settings.active_textbook_book)
  const selectedBookInfo=textbookBooks.find(b=>b.book===selectedBook) || textbookBooks[0]
  const defaultLesson=selectedBookInfo.lessons.some(l=>l.lesson===settings.active_textbook_lesson)?settings.active_textbook_lesson:(selectedBookInfo.lessons[0]?.lesson??1)
  const [selectedLesson,setSelectedLesson]=useState(defaultLesson)
  const [selectedUnit,setSelectedUnit]=useState(settings.active_textbook_book===selectedBook&&settings.active_textbook_lesson===defaultLesson?(settings.active_textbook_unit||1):1)

  const filteredMine = words.filter(w => `${w.lemma} ${w.translation} ${w.source}`.toLowerCase().includes(query.toLowerCase()))
  const filteredBase = coreLexicon.filter(entry => {
    const q=query.trim().toLocaleLowerCase('de-DE')
    const matchesQuery=!q || `${entry.lemma} ${entry.gloss_zh} ${entry.article} ${entry.plural}`.toLocaleLowerCase('de-DE').includes(q) || Object.values(entry.forms||{}).flat().some(x=>x.toLocaleLowerCase('de-DE').includes(q))
    const matchesLevel=level==='all' || entry.level===level
    const matchesPos=pos==='all' || entry.pos===pos || (pos==='ADJADV' && (entry.pos==='ADJ'||entry.pos==='ADV')) || (pos==='FUNCTION' && ['PRON','DET','ADP','CCONJ','SCONJ','PART','INTJ','AUX'].includes(entry.pos))
    return matchesQuery && matchesLevel && matchesPos && (!translatedOnly || Boolean(entry.gloss_zh))
  })
  const visibleBase=filteredBase.slice(0,140)
  const lessonEntries=entriesForBook(selectedBook,selectedLesson)
  const lessonUnits=unitsForLesson(selectedBook,selectedLesson,true)
  const selectedUnitInfo=lessonUnits.find(u=>u.unit===selectedUnit)||lessonUnits[0]
  const unitStats=selectedUnitInfo ? textbookUnitStats(selectedBook,selectedLesson,selectedUnitInfo.unit,words) : null
  const visibleLesson=(selectedUnitInfo?.entries||[]).filter(e=>(!missingExamplesOnly || !(e.example_de&&e.example_zh)) && (!estimatedOnly || goetheCalibration(e).kind!=='official-a1'))

  async function addEntry(entry:LexiconEntry) {
    if(isInPersonalLexicon(entry,words)){flash(`${entry.lemma} 已在我的词库`);return}
    const word={...lexiconToWord(entry),introduced_on:dateKeyInTimezone(settings.timezone)}
    if(!entry.gloss_zh){setEditing({...word,id:`temp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`});return}
    await onPersist(word);flash(`已将 ${entry.lemma} 加入学习`)
  }
  async function addFiltered() {
    const batch=filteredBase.filter(x=>x.gloss_zh&&!isInPersonalLexicon(x,words)).map(lexiconToWord)
    if(!batch.length){flash('当前筛选没有可新增的已释义词');return}
    await onBulkPersist(batch);flash(`已加入 ${batch.length} 个词；每日按新词上限逐步引入`)
  }
  async function activateCourse(){
    const next={...settings,textbook_plan_enabled:true,active_textbook_book:selectedBook,active_textbook_lesson:selectedLesson,active_textbook_unit:selectedUnit,textbook_only_translated:true}
    await onSaveSettings(next)
    flash(`当前词书：第 ${selectedBook} 册 · ${selectedLesson===0?'Vorkurs':`Lektion ${selectedLesson}`} · 单元 ${selectedUnit}`)
  }

  return <section className="page">
    <div className="page-head"><div><div className="eyebrow">WORTSCHATZ</div><h1>词库</h1><p>教材词书负责每天自动推进；开放基础词库和个人词库负责补充。</p></div>{tab==='mine'&&<div className="head-actions"><button className="secondary-button compact" onClick={()=>setBulk(true)}>批量导入</button><button className="primary-button compact" onClick={() => setEditing(blankWord())}>＋ 添加单词</button></div>}</div>
    <div className="library-tabs"><button className={tab==='textbook'?'active':''} onClick={()=>{setTab('textbook');setQuery('')}}>教材词书 <span>{textbookLexicon.length}</span></button><button className={tab==='base'?'active':''} onClick={()=>{setTab('base');setQuery('')}}>开放基础 <span>{lexiconStats.total}</span></button><button className={tab==='mine'?'active':''} onClick={()=>{setTab('mine');setQuery('')}}>我的词库 <span>{words.length}</span></button></div>

    {tab==='textbook' ? <>
      <div className="source-disclosure textbook-disclosure"><strong>《当代大学德语》1–4 册教材词书</strong><span>按“册 → 课 → 单元”组织。每个单元约 18 个可学习词；选一次起点后会自动连续推进。</span><em>例句覆盖：{textbookExampleCoverage().examples}/{textbookExampleCoverage().total} 个可学习词</em></div>
      <div className="book-grid">{textbookBooks.map(book=>{const learned=entriesForBook(book.book).filter(e=>entryCovered(e,words)).length;const active=settings.textbook_plan_enabled&&settings.active_textbook_book===book.book;return <button key={book.book} className={`book-card ${selectedBook===book.book?'selected':''}`} onClick={()=>{setSelectedBook(book.book);setSelectedLesson(book.lessons[0]?.lesson??1);setSelectedUnit(1)}}><div><span>第 {book.book} 册</span>{active&&<b className="active-course-badge">当前</b>}</div><h3>{book.stage}</h3><p>{book.count} 个教材词条 · {book.ready} 个可直接学习</p><div className="book-mini-progress"><i style={{width:`${book.ready?Math.min(100,learned/book.ready*100):0}%`}}/></div><small>已进入学习 {learned}</small></button>})}</div>
      <div className="panel textbook-panel"><div className="panel-head"><div><span className="course-kicker">{selectedBookInfo.title}</span><h2>选择学习起点</h2></div><span>{selectedBookInfo.lessons.length} 个课次</span></div><div className="lesson-grid">{selectedBookInfo.lessons.map(l=>{const learned=entriesForBook(selectedBook,l.lesson).filter(e=>entryCovered(e,words)).length;const active=settings.textbook_plan_enabled&&settings.active_textbook_book===selectedBook&&settings.active_textbook_lesson===l.lesson;return <button key={l.lesson} className={`${selectedLesson===l.lesson?'selected':''} ${active?'active':''}`} onClick={()=>{setSelectedLesson(l.lesson);setSelectedUnit(active?(settings.active_textbook_unit||1):1)}}><span>{l.lesson===0?'V':`L${l.lesson}`}</span><strong>{l.title}</strong><small>{learned}/{l.ready} 已进入 · {l.units} 单元</small></button>})}</div>
      <div className="unit-picker"><div className="unit-picker-head"><strong>{selectedLesson===0?'Vorkurs':`Lektion ${selectedLesson}`} 的学习单元</strong><span>约 18 词 · 当前单元例句 {unitStats?.examples||0}/{unitStats?.count||0}</span><div className="unit-checks"><label className="mini-check"><input type="checkbox" checked={missingExamplesOnly} onChange={e=>setMissingExamplesOnly(e.target.checked)}/>只看缺例句</label><label className="mini-check"><input type="checkbox" checked={estimatedOnly} onChange={e=>setEstimatedOnly(e.target.checked)}/>只看未获 A1 官方匹配</label></div></div><div className="unit-strip">{lessonUnits.map(u=>{const learned=u.entries.filter(e=>entryCovered(e,words)).length;const active=settings.textbook_plan_enabled&&settings.active_textbook_book===selectedBook&&settings.active_textbook_lesson===selectedLesson&&(settings.active_textbook_unit||1)===u.unit;return <button key={u.unit} className={`${selectedUnit===u.unit?'selected':''} ${active?'active':''}`} onClick={()=>setSelectedUnit(u.unit)}><b>单元 {u.unit}</b><small>{learned}/{u.count} 已引入 · {textbookUnitStats(selectedBook,selectedLesson,u.unit,words).mastered} 已掌握 · 例句 {textbookUnitStats(selectedBook,selectedLesson,u.unit,words).examples}/{u.count}</small></button>})}</div></div>
      <div className="course-action-row"><div><strong>{selectedLesson===0?'Vorkurs':`Lektion ${selectedLesson}`} · 单元 {selectedUnit}</strong><span>{selectedBookInfo.lessons.find(l=>l.lesson===selectedLesson)?.title}</span></div><button className="primary-button compact" onClick={activateCourse}>{settings.textbook_plan_enabled&&settings.active_textbook_book===selectedBook&&settings.active_textbook_lesson===selectedLesson&&(settings.active_textbook_unit||1)===selectedUnit?'当前起点':'从这个单元开始'}</button></div><small className="course-note">完成本单元后会自动进入下一单元；本课完成后继续下一课。你以后也可以随时重新指定起点。</small></div>
      <div className="textbook-word-head"><div><h2>{selectedLesson===0?'Vorkurs':`Lektion ${selectedLesson}`} · 单元 {selectedUnit}</h2><span>{visibleLesson.length} 条可学习词 · 本课共 {lessonEntries.length} 条索引词</span></div><button className="text-button" onClick={onStart}>开始今天的学习 →</button></div>
      <div className="goethe-audit-grid"><div><strong>{goetheReferenceStats.a1TextbookMatches}</strong><span>教材条目命中 Goethe A1 官方词表</span></div><div><strong>{contentRevisionStats.correctedGlosses}</strong><span>人工 / 定点释义修复</span></div><div><strong>{contentRevisionStats.curatedExamples}</strong><span>人工双语例句</span></div><div><strong>{textbookLexicon.length}</strong><span>教材原始索引保持不变</span></div></div>
      <details className="content-revision-note"><summary><strong>1.8 内容校准说明</strong><span>展开</span></summary><p>教材册次仍决定学习顺序，但不再把“第几册”冒充 Goethe 官方 CEFR。已用你提供的 Goethe A1 官方词表做第一层真实匹配；A2/B1/B2 暂保留“教材进度估计”，等待官方词表/当前考试材料进一步核对。1.8 还修复了一批高置信 OCR / 词形错误（例如 abraten 被误解析为 braten）。</p></details>
      <div className="lexicon-table textbook-table"><div className="lexicon-row textbook-row lexicon-head"><span>词条</span><span>中文</span><span>核心词形 / 例句</span><span>状态</span></div>{visibleLesson.map(e=>{const learned=entryCovered(e,words);return <div className={`lexicon-row textbook-row ${!e.study_ready?'pending-entry':''}`} key={e.id}><span className="word-name"><strong>{textbookEntryDisplay(e)}</strong><small>{e.pos_zh||e.pos||'词性待核对'}{learned?' · 已进入学习':''}</small></span><span>{e.gloss_zh||'中文释义待核对'}</span><span className="muted lex-form">{e.example_de?<><b className="example-inline">{e.example_de}</b><small>{e.example_zh}</small></>:<><b className="example-missing">暂无双语例句</b><small>{textbookMorphSummary(e)}</small></>}</span><span className="lex-rank calibration-cell"><b className={goetheCalibration(e).kind==='official-a1'?'official-match':'estimate-match'}>{goetheCalibration(e).kind==='official-a1'?'A1 官方':e.level}</b><small>{goetheCalibration(e).kind==='official-a1'?'Goethe Wortliste 匹配':e.level_is_estimate?'教材进度估计':'参考等级'} · {e.study_ready?'可学习':'待核对'}</small></span></div>})}</div>
    </> : tab==='base' ? <>
      <div className="lexicon-overview"><div><strong>{lexiconStats.total}</strong><span>过滤后的基础词条</span></div><div><strong>{lexiconStats.translated}</strong><span>中文快速释义</span></div><div><strong>{lexiconStats.a1}</strong><span>A1 估计</span></div><div><strong>{lexiconStats.a2+lexiconStats.b1}</strong><span>A2–B1 估计</span></div></div>
      <div className="source-disclosure lexicon-disclosure"><strong>开放基础词库</strong><span>保留 V1.2 的 1,668 条高频基础层，用于教材外查词和补充，不会自动取代当前教材词书。</span></div>
      <div className="lexicon-toolbar"><div className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="查原形、词形或中文释义" /></div><select value={level} onChange={e=>setLevel(e.target.value as any)}><option value="all">全部等级</option><option>A1</option><option>A2</option><option>B1</option></select><select value={pos} onChange={e=>setPos(e.target.value as any)}><option value="all">全部词性</option><option value="NOUN">名词</option><option value="VERB">动词</option><option value="ADJADV">形容词 / 副词</option><option value="FUNCTION">功能词</option></select><label className="inline-check"><input type="checkbox" checked={translatedOnly} onChange={e=>setTranslatedOnly(e.target.checked)}/> 有中文释义</label></div>
      <div className="lexicon-result-head"><span>{filteredBase.length} 个结果{filteredBase.length>visibleBase.length?` · 先显示 ${visibleBase.length} 个`:''}</span><button className="text-button" onClick={addFiltered}>＋ 将当前筛选加入学习</button></div>
      <div className="lexicon-table"><div className="lexicon-row lexicon-head"><span>词条</span><span>中文</span><span>词形</span><span>等级 / 频率</span><span></span></div>{visibleBase.map(entry=>{const added=isInPersonalLexicon(entry,words);return <div className="lexicon-row" key={entry.id}><button className="word-name" onClick={()=>setSelectedLex(entry)}><strong>{lexiconDisplay(entry)}</strong><small>{entry.pos_zh}</small></button><span className={entry.gloss_zh?'':'pending-gloss'}>{entry.gloss_zh||'释义待补'}</span><span className="muted lex-form">{lexiconFormSummary(entry)}</span><span className="lex-rank"><b>{entry.level}</b><small>#{entry.frequency_rank}</small></span><button className={`lex-add ${added?'added':''}`} disabled={added} onClick={()=>addEntry(entry)}>{added?'已加入':'＋'}</button></div>})}</div>
      {filteredBase.length>visibleBase.length&&<p className="table-footnote">一次最多显示前 140 条；缩小筛选可定位后面的词。</p>}
    </> : <>
      <div className="source-disclosure"><strong>个人词库</strong><span>已经开始学习的教材词、开放基础词、手动添加、批量导入和阅读收集都会出现在这里，并参与云同步和 FSRS。</span></div>
      <div className="toolbar"><div className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="搜索德语、释义或来源" /></div><span className="count-label">{filteredMine.length} 个结果</span></div>
      <div className="word-table"><div className="word-tr table-head"><span>单词</span><span>释义</span><span>来源</span><span>记忆度</span><span></span></div>{filteredMine.map(w => <div className="word-tr" key={w.id}><button className="word-name" onClick={()=>setEditing(w)}><strong>{displayLemma(w)}</strong><small>{w.article?`${genderLabel(w.article)} · `:''}{w.plural?pluralDisplay(w):w.part_of_speech}</small></button><span>{w.translation || '—'}</span><span className="muted">{w.source}</span><span><Mastery value={wordMastery(w,cards,settings.request_retention)} /></span><button className="more" onClick={()=>setEditing(w)}>···</button></div>)}</div>
    </>}
    {selectedLex&&<LexiconModal entry={selectedLex} added={isInPersonalLexicon(selectedLex,words)} onClose={()=>setSelectedLex(null)} onAdd={async()=>{await addEntry(selectedLex);setSelectedLex(null)}} />}
    {editing && <WordModal word={editing} onClose={()=>setEditing(null)} onSave={async w=>{await onPersist(finalizeWord(w));setEditing(null)}} onDelete={editing.id.startsWith('temp')?undefined:()=>{onRemove(editing.id);setEditing(null)}} />}
    {bulk && <BulkImportModal existing={words} onClose={()=>setBulk(false)} onImport={async drafts=>{const batch=drafts.map(wordFromDraft);await onBulkPersist(batch);flash(`已导入 ${batch.length} 个词`);setBulk(false)}} />}
  </section>
}

function LexiconModal({entry,added,onClose,onAdd}:{entry:LexiconEntry;added:boolean;onClose:()=>void;onAdd:()=>void}) {
  const present=entry.forms['pres.3sg']?.[0]
  const perfect=entry.forms['part.perf']?.[0]
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal lexicon-modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">BASISWORTSCHATZ · #{entry.frequency_rank}</div><h2>{lexiconDisplay(entry)}</h2></div><button className="ghost-button" onClick={onClose}>×</button></div><div className="lexicon-detail"><p className="big-gloss">{entry.gloss_zh||'暂无中文快速释义'}</p><div className="detail-grid"><div><small>词性</small><strong>{entry.pos_zh}</strong></div><div><small>等级估计</small><strong>{entry.level}</strong></div>{entry.plural&&<div><small>复数</small><strong>{entry.plural}</strong></div>}{present&&<div><small>第三人称单数</small><strong>{present}</strong></div>}{perfect&&<div><small>第二分词</small><strong>{perfect}</strong></div>}<div><small>语料频率</small><strong>#{entry.frequency_rank}</strong></div></div><div className="data-provenance"><strong>数据来源</strong><p>WordHoard Top 2000 · {entry.license}。CEFR 是学习排序参考，不等同于某一教材的官方等级。</p></div></div><div className="modal-actions"><span/><span/><button className="secondary-button" onClick={onClose}>关闭</button><button className="primary-button compact" disabled={added} onClick={onAdd}>{added?'已在我的词库':'加入学习'}</button></div></div></div>
}

function WordModal({word,onClose,onSave,onDelete}:{word:Word;onClose:()=>void;onSave:(w:Word)=>void;onDelete?:()=>void}) {
  const [draft,setDraft] = useState(word)
  const field = (k:keyof Word,v:any) => setDraft(d=>({...d,[k]:v}))
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">WORT</div><h2>{word.id.startsWith('temp')?'添加单词':'编辑单词'}</h2></div><button className="ghost-button" onClick={onClose}>×</button></div><div className="form-grid"><label><span>原形</span><input value={draft.lemma} onChange={e=>field('lemma',e.target.value)} /></label><label><span>冠词</span><select value={draft.article||''} onChange={e=>field('article',e.target.value)}><option value="">—</option><option>der</option><option>die</option><option>das</option></select></label><label><span>复数</span><input value={draft.plural||''} onChange={e=>field('plural',e.target.value)} /></label><label><span>词性</span><input value={draft.part_of_speech} onChange={e=>field('part_of_speech',e.target.value)} /></label><label className="full"><span>中文释义</span><input value={draft.translation} onChange={e=>field('translation',e.target.value)} /></label><label className="full"><span>德语例句</span><textarea value={draft.example_de||''} onChange={e=>field('example_de',e.target.value)} /></label><label><span>等级</span><select value={draft.level||'A1'} onChange={e=>field('level',e.target.value)}>{['A1','A2','B1','B2','C1','学术','未定'].map(x=><option key={x}>{x}</option>)}</select></label><label><span>来源</span><input value={draft.source||''} onChange={e=>field('source',e.target.value)} /></label><label className="full"><span>来源备注</span><input value={draft.source_note||''} onChange={e=>field('source_note',e.target.value)} placeholder="例如：Lektion 3 / 第 12 页 / 某篇论文" /></label></div><div className="modal-actions">{onDelete && <button className="danger-button" onClick={onDelete}>删除</button>}<span/><button className="secondary-button" onClick={onClose}>取消</button><button className="primary-button compact" disabled={!draft.lemma.trim()} onClick={()=>onSave({...draft,id:draft.id.startsWith('temp')?crypto.randomUUID():draft.id,updated_at:new Date().toISOString()})}>保存</button></div></div></div>
}

function BulkImportModal({existing,onClose,onImport}:{existing:Word[];onClose:()=>void;onImport:(d:ImportDraft[])=>void}) {
  const [text,setText]=useState('die Gemeinschaft, Gemeinschaften | 共同体\nlesen | 阅读')
  const [source,setSource]=useState('我的导入')
  const drafts=useMemo(()=>parseBulkInput(text,source),[text,source])
  const existingLemmas=new Set(existing.map(w=>w.lemma.toLocaleLowerCase('de-DE')))
  const unique=drafts.filter((d,i,arr)=>!existingLemmas.has(d.lemma.toLocaleLowerCase('de-DE')) && arr.findIndex(x=>x.lemma.toLocaleLowerCase('de-DE')===d.lemma.toLocaleLowerCase('de-DE'))===i)
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal wide-modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">IMPORT</div><h2>批量导入</h2></div><button className="ghost-button" onClick={onClose}>×</button></div><label className="stack-label"><span>统一来源</span><input value={source} onChange={e=>setSource(e.target.value)} /></label><label className="stack-label"><span>粘贴词表或德语文本</span><textarea className="bulk-input" value={text} onChange={e=>setText(e.target.value)} /></label><p className="import-help">支持 <code>die Gemeinschaft | 共同体</code>、<code>der Staat, Staaten — 国家</code>、Tab 分隔等。若粘贴的是没有翻译的整段德语，会提取去重词形，释义留空等待补充。</p><div className="import-preview"><div><strong>识别 {drafts.length}</strong><span>可新增 {unique.length} · 重复 {drafts.length-unique.length}</span></div>{unique.slice(0,8).map((d,i)=><div className="preview-row" key={`${d.lemma}-${i}`}><span>{d.article} {d.lemma}</span><span>{d.plural}</span><span>{d.translation||'释义待补'}</span></div>)}</div><div className="modal-actions"><span/><button className="secondary-button" onClick={onClose}>取消</button><button className="primary-button compact" disabled={!unique.length} onClick={()=>onImport(unique)}>导入 {unique.length} 个</button></div></div></div>
}


function B2Sprint({settings,practiceSessions,studySessions,onSaveSettings,onLog,onRemoveLog,flash}:{settings:Settings;practiceSessions:B2PracticeSession[];studySessions:StudySession[];onSaveSettings:(s:Settings)=>Promise<void>;onLog:(s:B2PracticeSession)=>Promise<void>;onRemoveLog:(id:string)=>Promise<void>;flash:(s:string)=>void}) {
  const week=sprintWeek(settings.b2_target_date,settings.timezone)
  const phase=sprintPhase(week)
  const days=sprintDaysRemaining(settings.b2_target_date,settings.timezone)
  const tasks=buildSprintTasks(settings,practiceSessions)
  const today=dateKeyInTimezone(settings.timezone)
  const todayPractice=practiceSessions.filter(x=>x.date===today).reduce((sum,x)=>sum+x.minutes,0)
  const todayVocab=Math.round(todayStudySeconds(studySessions,settings.timezone)/60)
  const todayTotal=todayPractice+todayVocab
  const progress=Math.min(100,Math.round(todayTotal/Math.max(1,settings.b2_daily_minutes)*100))
  const chunk=dailyRedemittel(settings)
  const activeLevel=activeReferenceLevel(settings)
  const activeChunks=redemittelFor(activeLevel)
  const [area,setArea]=useState<B2TrainingArea>('listening')
  const [kind,setKind]=useState<B2PracticeKind>('drill')
  const [minutes,setMinutes]=useState(30)
  const [score,setScore]=useState('')
  const [note,setNote]=useState('')
  const recent=[...practiceSessions].sort((a,b)=>new Date(b.created_at).getTime()-new Date(a.created_at).getTime()).slice(0,10)
  const recommendation=recommendedDailyNew(settings.b2_current_level,days)

  async function savePractice(e:FormEvent){
    e.preventDefault()
    const numericScore=score.trim()===''?undefined:Math.max(0,Math.min(100,Number(score)))
    const session:B2PracticeSession={id:crypto.randomUUID(),date:today,area,kind,minutes:Math.max(1,minutes),score:Number.isFinite(numericScore)?numericScore:undefined,note:note.trim()||undefined,created_at:new Date().toISOString()}
    await onLog(session);setScore('');setNote('');flash(`已记录 ${trainingAreaName(area)} ${session.minutes} 分钟`)
  }

  return <section className="page sprint-page">
    <div className="page-head sprint-head"><div><div className="eyebrow">GOETHE B2 · 16 WOCHEN</div><h1>B2 冲刺台</h1><p>目标不是“学完教材”，而是在目标日前把四个考试模块都训练到可稳定通过。</p></div><a className="secondary-button official-link" href={GOETHE_B2_URL} target="_blank" rel="noreferrer">Goethe 官方模拟题 ↗</a></div>

    <div className="sprint-hero-grid">
      <div className="sprint-countdown"><span>距离目标日</span><strong>{days}</strong><b>天</b><small>{settings.b2_target_date} · 第 {week}/16 周</small></div>
      <div className="panel sprint-stage"><div className="stage-index">PHASE {phase.id}</div><h2>{phase.title}</h2><p>{phase.subtitle}</p><div className="stage-focus">{phase.focus.map(x=><span key={x}>{x}</span>)}</div><div className="milestone"><small>本周验收</small><strong>{weeklyMilestones[week-1]}</strong></div></div>
      <div className="panel sprint-today-meter"><div className="panel-head"><h2>今日总训练</h2><span>{todayTotal}/{settings.b2_daily_minutes} min</span></div><div className="big-progress"><i style={{width:`${progress}%`}} /></div><div className="sprint-minute-split"><span>词汇 FSRS <b>{todayVocab}</b></span><span>四技能/语法 <b>{todayPractice}</b></span></div><small>只有词汇复习会自动计时；听读写说和语法在下面手动记录，避免网站把挂机时间当学习。</small></div>
    </div>

    <div className="panel exam-rule"><div><strong>考试底线</strong><span>四模块分别计分，每个模块至少 60% 才通过。</span></div><div><strong>本站安全线</strong><span>模拟训练以 70% 为目标，给正式考试波动留余量。</span></div><div><strong>当前词汇强度</strong><span>起点 {settings.b2_current_level} · 系统建议约 {recommendation} 个新词/日（非官方词汇量标准）。</span></div></div>

    <div className="section-title"><div><div className="eyebrow">HEUTE</div><h2>今天必须完成什么</h2></div><span>总预算 {settings.b2_daily_minutes} min</span></div>
    <div className="sprint-task-grid">{tasks.map(task=><div className={`sprint-task ${task.area==='mock'?'mock':''}`} key={task.id}><div className="task-top"><span>{trainingAreaName(task.area)}</span><b>{task.minutes} min</b></div><h3>{task.title}</h3><p>{task.detail}</p>{task.area!=='mock'?<button className="text-button" onClick={()=>{setArea(task.area as B2TrainingArea);setMinutes(task.minutes);document.getElementById('b2-log-form')?.scrollIntoView({behavior:'smooth',block:'center'})}}>按这个任务记录 →</button>:<small>模考后请分别记录 Lesen / Hören / Schreiben / Sprechen 分数。</small>}</div>)}</div>

    <div className="section-title"><div><div className="eyebrow">PRÜFUNG</div><h2>四模块仪表盘</h2></div><span>60 及格 · 70 安全线</span></div>
    <div className="module-grid">{examModules.map(m=>{const st=moduleStats(practiceSessions,m.area);const score=st.avg;return <div className="module-card" key={m.area}><div className="module-card-top"><span>{m.de}</span><b>{m.minutes} min</b></div><h3>{m.zh}</h3><p>{m.description}</p><div className="score-line"><strong>{score===undefined?'—':score}</strong><span>{score===undefined?'尚无近三次成绩':score>=70?'安全线以上':score>=60?'已过线，但不稳定':'当前未过线'}</span></div><div className="score-track"><i className="pass-mark"/><i className="safe-mark"/><b style={{width:`${Math.min(100,score||0)}%`}}/></div><small>最近一次 {st.last===undefined?'—':`${st.last}%`} · 近三次均值 {score===undefined?'—':`${score}%`}</small></div>})}</div>

    <div className="section-grid sprint-work-grid">
      <div className="panel"><div className="panel-head"><h2>今日可调用表达</h2><span>{chunk.level} · {chunk.purpose}</span></div><div className="chunk-de">{chunk.de}</div><div className="chunk-zh">{chunk.zh}</div><p className="muted">{chunk.task} 当前表达层按你的冲刺阶段显示 {activeLevel}，不会在 A1 起点时每天硬塞 B2 套话。</p></div>
      <div className="panel"><div className="panel-head"><h2>阶段路线</h2><span>当前 Phase {phase.id}</span></div><div className="phase-strip">{sprintPhases.map(p=><div className={p.id===phase.id?'active':''} key={p.id}><b>{p.weeks}</b><span>{p.title}</span></div>)}</div></div>
    </div>

    <div className="section-grid calibration-work-grid">
      <div className="panel"><div className="panel-head"><h2>{activeLevel} 表达库</h2><span>{activeChunks.length} 条功能表达</span></div><div className="chunk-bank">{activeChunks.slice(0,8).map(x=><div key={x.id}><span>{x.purpose}</span><strong>{x.de}</strong><small>{x.zh}</small></div>)}</div><p className="muted">这里只放短小、可主动调用的表达，不把备考书全文搬进网站。</p></div>
      <details className="panel material-map"><summary><div><h2>材料来源与版本说明</h2><span>需要时展开；不占日常训练动线</span></div><b>＋</b></summary><div className="material-map-body">{sourceMaterials.map(x=><div className="material-row" key={x.level}><b>{x.level}</b><div><strong>{x.title}</strong><span>{x.use}</span><small>{x.authority} · {x.note}</small></div></div>)}</div></details>
    </div>

    <div className="section-grid sprint-log-grid">
      <form id="b2-log-form" className="panel practice-form" onSubmit={savePractice}><div className="panel-head"><h2>记录一次训练</h2><span>听读写说必须留下证据</span></div><div className="practice-fields"><label>训练项<select value={area} onChange={e=>setArea(e.target.value as B2TrainingArea)}>{(['listening','reading','writing','speaking','grammar'] as B2TrainingArea[]).map(x=><option value={x} key={x}>{trainingAreaName(x)}</option>)}</select></label><label>方式<select value={kind} onChange={e=>setKind(e.target.value as B2PracticeKind)}><option value="drill">普通训练</option><option value="timed">限时训练</option><option value="mock">模拟考试</option></select></label><label>分钟<input type="number" min="1" max="240" value={minutes} onChange={e=>setMinutes(+e.target.value)}/></label><label>得分 %<input type="number" min="0" max="100" value={score} onChange={e=>setScore(e.target.value)} placeholder="无客观分数可留空"/></label><label className="full">复盘<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="例如：听到了词但没跟上转折；写作论据重复；口语停顿太多……"/></label></div><button className="primary-button" type="submit">保存训练记录</button></form>
      <div className="panel recent-practice"><div className="panel-head"><h2>最近训练</h2><span>{practiceSessions.length} 条</span></div>{recent.length?<div className="practice-list">{recent.map(x=><div className="practice-row" key={x.id}><div><strong>{trainingAreaName(x.area)}</strong><span>{x.date} · {practiceKindName(x.kind)} · {x.minutes} min{x.score!==undefined?` · ${x.score}%`:''}</span>{x.note&&<small>{x.note}</small>}</div><button className="more" onClick={()=>onRemoveLog(x.id)}>×</button></div>)}</div>:<p className="muted">还没有记录。第一条建议直接做一次听力或阅读诊断。</p>}</div>
    </div>

    <div className="panel sprint-config"><div><h2>冲刺参数</h2><p>目标日期、起点和每天可投入时间会直接改变计划强度。</p></div><label>目标日<input type="date" value={settings.b2_target_date} onChange={e=>void onSaveSettings({...settings,b2_target_date:e.target.value})}/></label><label>起点<select value={settings.b2_current_level} onChange={e=>void onSaveSettings({...settings,b2_current_level:e.target.value as Settings['b2_current_level']})}><option>A1</option><option>A2</option><option>B1</option><option value="B2-">B2-</option></select></label><label>每天<input type="number" min="60" max="360" step="15" value={settings.b2_daily_minutes} onChange={e=>void onSaveSettings({...settings,b2_daily_minutes:+e.target.value})}/><span>min</span></label><button className="secondary-button sprint-apply-vocab" onClick={()=>void onSaveSettings({...settings,daily_new:recommendation}).then(()=>flash(`教材新词已设为 ${recommendation} / 日`))}>应用 {recommendation} 个教材新词 / 日</button></div>
  </section>
}

function Reader({words,settings,onPersist,flash}:{words:Word[];settings:Settings;onPersist:(w:Word)=>Promise<void>;flash:(s:string)=>void}) {
  const [text,setText] = useState('Der Staat ist eine Gemeinschaft. Freiheit entsteht nicht durch Zwang, sondern in lebendigen Verhältnissen zwischen Menschen.')
  const [selected,setSelected] = useState('')
  const [editing,setEditing] = useState<Word|null>(null)
  const personal = selected ? resolveToken(selected,words) : null
  const builtIn = selected && !personal?.word ? lookupLexiconToken(selected) : null
  const resolvedLemma = personal?.word ? personal.lemma : builtIn?.entry.lemma || personal?.lemma || selected
  const reason = personal?.word ? personal.reason : builtIn?.reason || personal?.reason || ''
  const confidence = personal?.word ? personal.confidence : builtIn?.confidence ?? personal?.confidence ?? 0
  const tokens = tokenize(text)

  async function prepareAdd() {
    if (!selected) return
    if (builtIn) {
      const word={...lexiconToWord(builtIn.entry),introduced_on:dateKeyInTimezone(settings.timezone)}
      word.example_de=sentenceAround(text,selected)
      if(word.translation){await onPersist(word);flash(`已将 ${word.lemma} 从基础词库加入学习`);return}
      setEditing({...word,id:`temp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`});return
    }
    const w=blankWord(resolvedLemma); w.source='阅读摘录'; w.example_de=sentenceAround(text,selected); setEditing(w)
  }
  function tokenState(token:string){
    const mine=resolveToken(token,words).word
    if(mine)return 'known'
    if(lookupLexiconToken(token))return 'dictionary-known'
    return ''
  }
  return <section className="page reader-page"><div className="page-head"><div><div className="eyebrow">LESEN</div><h1>阅读工作台</h1><p>现在会先查“我的词库”，再查 1.2 基础词库的原形与已知屈折形式。</p></div></div><div className="reader-grid"><div className="reader-left"><textarea className="reader-input" value={text} onChange={e=>setText(e.target.value)} placeholder="在这里粘贴德语文本……"/><div className="reading-paper">{tokens.map((t,i)=>isGermanToken(t)?<button key={i} className={`token ${selected===t?'selected':''} ${tokenState(t)}`} onClick={()=>setSelected(t)}>{t}</button>:<span key={i}>{t}</span>)}</div></div><aside className="lookup-panel">{selected ? <><div className="lookup-word"><span>选中词形</span><h2>{selected}</h2><button className="audio-button" onClick={()=>speak(selected)}>🔊 发音</button></div><div className="lemma-guess"><small>原形判断</small><strong>{resolvedLemma}</strong><span>{reason} · {Math.round(confidence*100)}%</span></div>{personal?.word ? <div className="lookup-known"><span className="status-tag">已在我的词库</span><h3>{displayLemma(personal.word)}</h3><p>{personal.word.translation}</p>{personal.word.plural && <small>复数：{personal.word.plural}</small>}<div className="meta-line"><span>{personal.word.level}</span><span>{personal.word.source}</span></div></div> : builtIn ? <div className="lookup-known base-hit"><span className="status-tag">基础词库</span><h3>{lexiconDisplay(builtIn.entry)}</h3><p>{builtIn.entry.gloss_zh||'暂无中文快速释义'}</p>{builtIn.entry.plural&&<small>复数：{builtIn.entry.plural}</small>}<div className="meta-line"><span>{builtIn.entry.pos_zh}</span><span>{builtIn.entry.level}</span><span>频率 #{builtIn.entry.frequency_rank}</span></div><button className="primary-button reader-add" disabled={isInPersonalLexicon(builtIn.entry,words)} onClick={prepareAdd}>{isInPersonalLexicon(builtIn.entry,words)?'已加入我的词库':'＋ 加入学习'}</button></div> : <div className="lookup-unknown"><p>基础词库也没有可靠命中。下面仅是规则推测，加入前需要手动确认原形和释义。</p><button className="primary-button" onClick={prepareAdd}>＋ 检查后加入</button></div>}</> : <div className="lookup-empty"><div>↖</div><p>点击左侧任意德语词。</p></div>}</aside></div>{editing && <WordModal word={editing} onClose={()=>setEditing(null)} onSave={async w=>{const saved=finalizeWord(w);await onPersist(saved);setEditing(null);flash(`已将 ${saved.lemma} 加入词库`)}} />}</section>
}

function Grammar() {
  const [open,setOpen]=useState(grammarItems[0].id)
  return <section className="page"><div className="page-head"><div><div className="eyebrow">GRAMMATIK · A1 → B2</div><h1>语法纠错路线</h1><p>这里不再显示假的“掌握百分比”。按 A1→B2 补会影响听读理解和写说输出的结构；每学一条，都回到真实句子里练。</p></div></div><div className="grammar-roadmap">{(['A1','A2','B1','B2'] as const).map(level=><div className="grammar-level-block" key={level}><div className="grammar-level-head"><strong>{level}</strong><span>{grammarItems.filter(g=>g.level===level).length} 个核心结构</span></div><div className="grammar-grid">{grammarItems.filter(g=>g.level===level).map((g,i)=><button className={`grammar-card ${open===g.id?'open':''}`} key={g.id} onClick={()=>setOpen(g.id)}><div className="grammar-card-top"><span className="level-tag">{g.level}</span><span>{String(i+1).padStart(2,'0')}</span></div><h3>{g.title}</h3><p>{g.subtitle}</p>{open===g.id && <div className="grammar-example"><small>例句</small><strong>{g.example}</strong><span>训练法：自己再造 3 句，其中至少 1 句与今天的阅读、写作或口语主题有关；出错就把错误记到 B2 冲刺训练复盘。</span></div>}</button>)}</div></div>)}</div></section>
}

function SettingsPanel({settings,onSave,user,setUser,flash,dueCount}:{settings:Settings;onSave:(s:Settings)=>Promise<void>;user:SessionUser;setUser:(u:SessionUser)=>void;flash:(s:string)=>void;dueCount:number}) {
  const [draft,setDraft]=useState(settings)
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [authMode,setAuthMode]=useState<'login'|'signup'>('login'); const [pushBusy,setPushBusy]=useState(false)
  useEffect(()=>setDraft(settings),[settings])
  async function auth(e:FormEvent) { e.preventDefault(); if (!supabase) return flash('请先配置 Supabase 环境变量'); const result = authMode==='login' ? await supabase.auth.signInWithPassword({email,password}) : await supabase.auth.signUp({email,password}); if(result.error)flash(result.error.message);else{const u=result.data.user;setUser(u?{id:u.id,email:u.email}:null);flash(authMode==='login'?'已登录':'账户已创建，请完成邮箱确认后登录')}}
  async function logout(){if(supabase)await supabase.auth.signOut();setUser(null);flash('已退出登录')}
  async function testNotice(){try{const r=await showTestNotification(dueCount);flash(r==='shown'?'测试通知已发送':r==='denied'?'通知权限被拒绝':'当前浏览器不支持通知')}catch(e){flash((e as Error).message)}}
  async function togglePush(enable:boolean){if(!user)return flash('请先登录云端账户');setPushBusy(true);try{if(enable)await enableWebPush(user.id);else await disableWebPush(user.id);const next={...draft,push_enabled:enable};setDraft(next);await onSave(next);flash(enable?'后台 Web Push 已订阅':'已关闭本设备 Web Push')}catch(e){flash((e as Error).message)}finally{setPushBusy(false)}}
  const currentBook=textbookBooks.find(b=>b.book===draft.active_textbook_book) || textbookBooks[0]
  const currentUnits=unitsForLesson(draft.active_textbook_book,draft.active_textbook_lesson,draft.textbook_only_translated)
  return <section className="page settings-page"><div className="page-head"><div><div className="eyebrow">EINSTELLUNGEN</div><h1>设置</h1><p>B2 冲刺、教材计划、FSRS、同步与提醒。</p></div></div><div className="settings-grid">
    <div className="panel settings-card"><h2>学习计划</h2><label className="setting-row"><span><strong>每日教材新词</strong><small>只控制教材自动引入；到期复习、个人生词不占用这项额度</small></span><input type="number" min="0" max="100" value={draft.daily_new} onChange={e=>setDraft({...draft,daily_new:+e.target.value})}/></label><label className="setting-row"><span><strong>每日个人新词</strong><small>批量导入的个人生词按这个数量逐日进入学习；手动单个加入会立即进入</small></span><input type="number" min="0" max="50" value={draft.daily_personal_new} onChange={e=>setDraft({...draft,daily_personal_new:+e.target.value})}/></label><label className="setting-row"><span><strong>当前教材</strong><small>{draft.textbook_plan_enabled?`《当代大学德语》第 ${draft.active_textbook_book} 册`:'未启用教材词书'}</small></span><select value={draft.active_textbook_book} onChange={e=>{const b=+e.target.value;const book=textbookBooks.find(x=>x.book===b);setDraft({...draft,textbook_plan_enabled:true,active_textbook_book:b,active_textbook_lesson:book?.lessons[0]?.lesson??1,active_textbook_unit:1})}}>{textbookBooks.map(b=><option value={b.book} key={b.book}>第 {b.book} 册 · {b.ready} 可学习</option>)}</select></label><label className="setting-row"><span><strong>从哪一课开始</strong><small>学完该课会自动继续后面的 Lektion</small></span><select value={draft.active_textbook_lesson} onChange={e=>setDraft({...draft,textbook_plan_enabled:true,active_textbook_lesson:+e.target.value,active_textbook_unit:1})}>{currentBook.lessons.map(l=><option value={l.lesson} key={l.lesson}>{l.lesson===0?'Vorkurs':`Lektion ${l.lesson}`} · {l.title}</option>)}</select></label><label className="setting-row"><span><strong>从哪个单元开始</strong><small>保持教材顺序，每约 18 个可学习词为一个单元</small></span><select value={draft.active_textbook_unit||1} onChange={e=>setDraft({...draft,textbook_plan_enabled:true,active_textbook_unit:+e.target.value})}>{currentUnits.map(u=><option value={u.unit} key={u.unit}>单元 {u.unit} · {u.count} 词</option>)}</select></label><label className="setting-row"><span><strong>自动学习只取已校验词条</strong><small>建议保持开启：需要有中文释义；名词/动词还需有可用核心词形</small></span><input className="toggle" type="checkbox" checked={draft.textbook_only_translated} onChange={e=>setDraft({...draft,textbook_only_translated:e.target.checked})}/></label><label className="setting-row"><span><strong>FSRS 目标保持率</strong><small>越高复习越频繁；默认 90%</small></span><div className="suffix-input"><input type="number" step="0.01" min="0.7" max="0.97" value={draft.request_retention} onChange={e=>setDraft({...draft,request_retention:+e.target.value})}/><i>0–1</i></div></label><button className="primary-button compact save-settings" onClick={()=>{onSave(draft);flash('设置已保存')}}>保存设置</button><small className="settings-footnote">第 {currentBook.book} 册共有 {currentBook.count} 个教材课次词条，其中 {currentBook.ready} 条当前可直接进入自动学习。</small></div>
    <div className="panel settings-card"><h2>B2 四个月冲刺</h2><label className="setting-row"><span><strong>启用 B2 Sprint</strong><small>首页与 B2 冲刺页按 16 周路线组织训练</small></span><input className="toggle" type="checkbox" checked={draft.b2_sprint_enabled} onChange={e=>setDraft({...draft,b2_sprint_enabled:e.target.checked})}/></label><label className="setting-row"><span><strong>目标考试日期</strong><small>用于倒推 16 周阶段；可随报名日期修改</small></span><input type="date" value={draft.b2_target_date} onChange={e=>setDraft({...draft,b2_target_date:e.target.value})}/></label><label className="setting-row"><span><strong>当前起点</strong><small>影响系统建议的新词强度，不会自动改你的已有词卡</small></span><select value={draft.b2_current_level} onChange={e=>setDraft({...draft,b2_current_level:e.target.value as Settings['b2_current_level']})}><option>A1</option><option>A2</option><option>B1</option><option value="B2-">B2-</option></select></label><label className="setting-row"><span><strong>每日德语总训练</strong><small>包含词汇复习、听读、语法和输出；四个月冲刺建议按实际可持续时间设置</small></span><div className="suffix-input"><input type="number" min="60" max="360" step="15" value={draft.b2_daily_minutes} onChange={e=>setDraft({...draft,b2_daily_minutes:+e.target.value})}/><i>min</i></div></label><div className="b2-setting-hint">当前系统建议：教材新词约 <b>{recommendedDailyNew(draft.b2_current_level,sprintDaysRemaining(draft.b2_target_date,draft.timezone))}</b> / 日。它是冲刺强度建议，不是 Goethe 官方词汇量要求。<button type="button" className="text-button" onClick={()=>setDraft({...draft,daily_new:recommendedDailyNew(draft.b2_current_level,sprintDaysRemaining(draft.b2_target_date,draft.timezone))})}>应用到教材新词额度</button></div></div>
    <div className="panel settings-card"><h2>学习提醒</h2><div className="setting-row"><span><strong>提醒时间</strong><small>按下方时区解释</small></span><input type="time" value={draft.reminder_time} onChange={e=>setDraft({...draft,reminder_time:e.target.value})}/></div><label className="setting-row"><span><strong>启用提醒</strong><small>网页打开时可本地触发；后台提醒需 Web Push</small></span><input className="toggle" type="checkbox" checked={draft.reminder_enabled} onChange={e=>setDraft({...draft,reminder_enabled:e.target.checked})}/></label><label className="setting-row"><span><strong>时区</strong><small>IANA 时区，例如 Asia/Shanghai</small></span><input value={draft.timezone} onChange={e=>setDraft({...draft,timezone:e.target.value})}/></label><div className="button-stack"><button className="secondary-button" onClick={testNotice}>发送测试通知</button>{user && <button className="secondary-button" disabled={pushBusy} onClick={()=>togglePush(!draft.push_enabled)}>{draft.push_enabled?'关闭本设备后台提醒':'启用本设备后台 Web Push'}</button>}</div></div>
    <div className="panel settings-card"><h2>跨设备同步</h2>{!cloudConfigured ? <div className="cloud-explain"><span className="big-status">○</span><h3>当前是本地模式</h3><p>配置 Supabase 后可同步教材学习进度、个人词库、FSRS 记忆卡和复习日志。</p></div> : user ? <div className="cloud-explain"><span className="big-status online">✓</span><h3>云同步已启用</h3><p>{user.email}</p><button className="secondary-button" onClick={logout}>退出登录</button></div> : <form className="auth-form" onSubmit={auth}><div className="tab-row"><button type="button" className={authMode==='login'?'active':''} onClick={()=>setAuthMode('login')}>登录</button><button type="button" className={authMode==='signup'?'active':''} onClick={()=>setAuthMode('signup')}>注册</button></div><label>邮箱<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>密码<input type="password" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required /></label><button className="primary-button" type="submit">{authMode==='login'?'登录并同步':'创建账户'}</button></form>}</div>
  </div><div className="panel export-card"><div><h2>数据与词库来源</h2><p>V1.8 的教材词书以你提供的《当代大学德语》1–4 册学生用书的课次和词汇索引为骨架；开放词形数据用于核对名词性别/复数和动词变位。PDF 本身不会打包进网站。</p></div><button className="secondary-button" onClick={()=>downloadJson({version:'1.8',textbook:{entries:textbookLexicon.length,books:textbookBooks.map(b=>({book:b.book,count:b.count,ready:b.ready}))},words:readJson(STORAGE_WORDS,[]),cards:readJson(STORAGE_CARDS,[]),logs:readJson(STORAGE_LOGS,[]),studySessions:readJson(STORAGE_STUDY_SESSIONS,[]),b2Practice:readJson(STORAGE_B2_PRACTICE,[]),settings:readLocalSettings()},'deutsch-os-v1.8-backup.json')}>导出完整 JSON</button></div>
  </section>
}

function buildReviewQueue(words:Word[], cards:MemoryCard[], dailyTextbookNew:number, dailyPersonalNew:number): ReviewTask[] {
  const now=Date.now(); const map=new Map(words.map(w=>[w.id,w])); const tasks:ReviewTask[]=[]; const keys=new Set<string>()

  // 1. Due FSRS reviews are never constrained by either new-word quota.
  cards
    .filter(c=>{const w=map.get(c.word_id);return w?.status!=='mastered'&&new Date(c.due_at).getTime()<=now})
    .sort((a,b)=>new Date(a.due_at).getTime()-new Date(b.due_at).getTime())
    .forEach(card=>{
      const word=map.get(card.word_id);
      if(!word||!availableModes(word).includes(card.mode))return;
      const key=`${word.id}:${card.mode}`;
      if(keys.has(key))return;
      keys.add(key);tasks.push({key,word,mode:card.mode,card})
    })

  // 2. Existing words may acquire at most one new dimension per session. This is a
  // separate review workload, not a new-word quota.
  const partialWords=words
    .filter(w=>w.status!=='mastered'&&cards.some(c=>c.word_id===w.id))
    .filter(w=>{
      const modes=availableModes(w);
      const missing=modes.some(mode=>!cards.some(c=>c.word_id===w.id&&c.mode===mode));
      const meaning=cards.find(c=>c.word_id===w.id&&c.mode==='meaning');
      return missing && Boolean(meaning?.reps && meaning.reps>0)
    })
    .sort((a,b)=>new Date(a.updated_at).getTime()-new Date(b.updated_at).getTime())
  for(const word of partialWords.slice(0,8)){
    const mode=availableModes(word).find(m=>!cards.some(c=>c.word_id===word.id&&c.mode===m))
    if(!mode)continue
    const key=`${word.id}:${mode}`
    if(!keys.has(key)){keys.add(key);tasks.push({key,word,mode})}
  }

  // 3. Unstarted textbook words are limited by the textbook quota.
  const textbookNew=words
    .filter(w=>w.status!=='mastered'&&Boolean(w.textbook_entry_id)&&Boolean(w.introduced_on)&&!cards.some(c=>c.word_id===w.id)&&availableModes(w).length>0)
    .sort((a,b)=>{
      const da=(a.introduced_on||'').localeCompare(b.introduced_on||'')
      return da || new Date(a.created_at).getTime()-new Date(b.created_at).getTime()
    })
    .slice(0,Math.max(0,dailyTextbookNew))
  for(const word of textbookNew){
    const mode=availableModes(word).find(m=>m==='meaning')||availableModes(word)[0]; if(!mode)continue
    const key=`${word.id}:${mode}`; if(!keys.has(key)){keys.add(key);tasks.push({key,word,mode})}
  }

  // 4. Personal/manual words have their own intake quota. Words explicitly added by the
  // learner are introduced immediately, so they do not consume the textbook quota.
  const personalWords=words
    .filter(w=>w.status!=='mastered'&&!w.textbook_entry_id&&Boolean(w.introduced_on)&&!cards.some(c=>c.word_id===w.id)&&availableModes(w).length>0)
    .sort((a,b)=>{
      const da=(a.introduced_on||'').localeCompare(b.introduced_on||'')
      return da || new Date(a.created_at).getTime()-new Date(b.created_at).getTime()
    })
  const explicitPersonal=personalWords.filter(w=>w.source!=='批量导入')
  const importedPersonal=personalWords.filter(w=>w.source==='批量导入').slice(0,Math.max(0,dailyPersonalNew))
  for(const word of [...explicitPersonal,...importedPersonal]){
    const mode=availableModes(word).find(m=>m==='meaning')||availableModes(word)[0]; if(!mode)continue
    const key=`${word.id}:${mode}`; if(!keys.has(key)){keys.add(key);tasks.push({key,word,mode})}
  }
  return tasks
}

function availableModes(w:Word):ReviewMode[]{const modes:ReviewMode[]=[];if(w.translation)modes.push('meaning');if(w.article)modes.push('article');if(w.plural)modes.push('plural');if(w.translation)modes.push('spelling');if(w.verb_forms&&((w.verb_forms.present?.length||0)>0||w.verb_forms.praeteritum||w.verb_forms.partizip_ii))modes.push('conjugation');return modes}
function buildDiagnostics(logs:ReviewEvent[],words:Word[]){const since=Date.now()-30*86400000;const recent=logs.filter(l=>new Date(l.reviewed_at).getTime()>=since);const modes=(['meaning','article','plural','spelling','conjugation'] as ReviewMode[]).map(mode=>{const xs=recent.filter(l=>l.mode===mode);return{mode,again:xs.filter(x=>x.rating==='again').length,hard:xs.filter(x=>x.rating==='hard').length,weight:xs.filter(x=>x.rating==='again').length*2+xs.filter(x=>x.rating==='hard').length}}).sort((a,b)=>b.weight-a.weight);const counts=new Map<string,number>();recent.filter(l=>l.rating==='again'||l.rating==='hard').forEach(l=>counts.set(l.word_id,(counts.get(l.word_id)||0)+1));const byId=new Map(words.map(w=>[w.id,w]));const topWords=[...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5).map(([id,count])=>({word:byId.get(id),count})).filter((x):x is {word:Word;count:number}=>Boolean(x.word));return{total:recent.length,modes,topWords}}
function wordMastery(w:Word,cards:MemoryCard[],retention:number){const modes=availableModes(w);if(!modes.length)return 0;return Math.round(avg(modes.map(mode=>retrievability(cards.find(c=>c.word_id===w.id&&c.mode===mode),retention)))*100)}
function wordFromDraft(d:ImportDraft):Word{const now=new Date().toISOString();return{id:crypto.randomUUID(),lemma:d.lemma,article:d.article,plural:d.plural,part_of_speech:d.part_of_speech,translation:d.translation,example_de:'',example_zh:'',level:'未定',source:d.source,source_note:'批量导入',tags:[],status:'new',introduced_on:undefined,due_at:now,interval_days:0,ease:2.5,meaning_score:0,article_score:0,plural_score:0,spelling_score:0,created_at:now,updated_at:now}}
function blankWord(lemma=''):Word{const now=new Date().toISOString();return{id:`temp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,lemma,article:'',plural:'',part_of_speech:'',translation:'',example_de:'',example_zh:'',level:'未定',source:'我的生词',source_note:'',tags:[],status:'new',due_at:now,interval_days:0,ease:2.5,meaning_score:0,article_score:0,plural_score:0,spelling_score:0,created_at:now,updated_at:now}}
function finalizeWord(w:Word):Word{return w.id.startsWith('temp-')?{...w,id:crypto.randomUUID(),introduced_on:w.introduced_on||dateKeyInTimezone(Intl.DateTimeFormat().resolvedOptions().timeZone||'Asia/Tokyo'),updated_at:new Date().toISOString()}:w}
function dateKeyInTimezone(timeZone:string){return new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}
function migrateLegacyStudySessions():StudySession[]{
  try {
    const existing=localStorage.getItem(STORAGE_STUDY_SESSIONS)
    if(existing) return JSON.parse(existing) as StudySession[]
    const raw=JSON.parse(localStorage.getItem(STORAGE_MINUTES)||'{}') as Record<string,number>|number
    const stamp=new Date().toISOString()
    if(typeof raw==='number' && raw>0) return [{id:'legacy-'+Date.now(),date:dateKeyInTimezone(defaultSettings.timezone),seconds:Math.round(raw*60),started_at:stamp,ended_at:stamp}]
    return Object.entries(raw).filter(([,m])=>Number(m)>0).map(([date,m],i)=>({id:`legacy-${date}-${i}`,date,seconds:Math.round(Number(m)*60),started_at:stamp,ended_at:stamp}))
  } catch { return [] }
}
function todayStudySeconds(sessions:StudySession[], timeZone:string){const today=dateKeyInTimezone(timeZone);return sessions.filter(s=>s.date===today).reduce((sum,s)=>sum+s.seconds,0)}
function formatStudyDuration(seconds:number){const s=Math.max(0,Math.round(seconds));if(s<60)return `${s} 秒`;const min=Math.floor(s/60);const sec=s%60;return sec?`${min} 分 ${sec} 秒`:`${min} 分钟`}

function trainingAreaName(area:B2TrainingArea|'mock'){return area==='vocabulary'?'词汇':area==='grammar'?'语法':area==='reading'?'阅读':area==='listening'?'听力':area==='writing'?'写作':area==='speaking'?'口语':'模考'}
function practiceKindName(kind:B2PracticeKind){return kind==='timed'?'限时':kind==='mock'?'模考':'训练'}
function greeting(){const h=new Date().getHours();return h<11?'Guten Morgen.':h<18?'Guten Tag.':'Guten Abend.'}
function modeName(m:ReviewMode){return m==='meaning'?'词义':m==='article'?'性别 / 冠词':m==='plural'?'复数':m==='conjugation'?'动词变位':'拼写'}
function genderLabel(article?:string){return article==='der'?'阳性 · maskulin':article==='die'?'阴性 · feminin':article==='das'?'中性 · neutrum':'未确认'}
function pluralDisplay(w:Word){return w.plural?`die ${w.plural}`:'未标（可能无常用复数）'}
function perfektForm(vf?:Word['verb_forms']){if(!vf?.partizip_ii)return '—';const aux=(vf.auxiliary||'haben').toLowerCase();if(aux.includes('sein')&&aux.includes('haben'))return `hat/ist ${vf.partizip_ii}`;return `${aux.includes('sein')?'ist':'hat'} ${vf.partizip_ii}`}
function textbookMorphSummary(e:TextbookEntry){if(e.article)return `${genderLabel(e.article)} · Sg. ${e.article} ${e.lemma}${e.plural?` · Pl. die ${e.plural}`:''}`;if(e.verb_forms?.present?.length||e.verb_forms?.praeteritum||e.verb_forms?.partizip_ii){const p3=e.verb_forms.present?.[2];return [p3&&`3sg ${p3}`,e.verb_forms.praeteritum&&`Prät. ${e.verb_forms.praeteritum}`,e.verb_forms.partizip_ii&&`Part. II ${e.verb_forms.partizip_ii}`].filter(Boolean).join(' · ')}return e.pos_zh||e.pos}
function relativeDue(d:Date){const ms=d.getTime()-Date.now();const min=Math.max(1,Math.round(ms/60000));if(min<60)return`${min} min`;const h=Math.round(min/60);if(h<24)return`${h} h`;const day=Math.round(h/24);return`${day} d`}
function normalizeAnswer(s:string){return s.trim().toLocaleLowerCase('de-DE').replace(/^(der|die|das)\s+/,'').replace(/\s+/g,' ')}
function Mastery({value}:{value:number}){return <div className="mastery"><div><i style={{width:`${value}%`}} /></div><b>{value}%</b></div>}
function avg(a:number[]){return a.length?a.reduce((x,y)=>x+y,0)/a.length:0}
function groupSources(words:Word[]){const m=new Map<string,number>();words.forEach(w=>m.set(w.source||'未分类',(m.get(w.source||'未分类')||0)+1));return[...m.entries()].sort((a,b)=>b[1]-a[1])}
function lexiconFormSummary(entry:LexiconEntry){
  if(entry.pos==='NOUN')return entry.plural?`Pl. ${entry.plural}`:'—'
  if(entry.pos==='VERB'||entry.pos==='AUX'){const parts:string[]=[];const p3=entry.forms['pres.3sg']?.[0];const pp=entry.forms['part.perf']?.[0];if(p3)parts.push(`3sg ${p3}`);if(pp)parts.push(`Part. II ${pp}`);return parts.join(' · ')||'—'}
  return Object.values(entry.forms||{}).flat().filter(x=>x.toLocaleLowerCase('de-DE')!==entry.lemma.toLocaleLowerCase('de-DE')).slice(0,3).join(', ')||'—'
}
function displayLemma(w:Word){return`${w.article?w.article+' ':''}${w.lemma}`}
function tokenize(text:string){return text.split(/([A-Za-zÄÖÜäöüß]+|\s+|[^A-Za-zÄÖÜäöüß\s]+)/g).filter(Boolean)}
function isGermanToken(t:string){return/^[A-Za-zÄÖÜäöüß]+$/.test(t)}
function speak(text:string){if('speechSynthesis'in window){window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='de-DE';u.rate=.82;window.speechSynthesis.speak(u)}}
function downloadJson(obj:any,name:string){const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}
