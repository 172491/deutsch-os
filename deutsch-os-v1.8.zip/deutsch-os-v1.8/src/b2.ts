import type { B2PracticeSession, B2TrainingArea, Settings } from './types'

export type SprintPhase = {
  id: 1|2|3|4
  weeks: string
  title: string
  subtitle: string
  focus: string[]
}

export type SprintTask = {
  id: string
  area: B2TrainingArea | 'mock'
  title: string
  detail: string
  minutes: number
  scoreRelevant?: boolean
}

export const GOETHE_B2_URL = 'https://www.goethe.de/en/spr/prf/ueb/pb2.html'

export const examModules = [
  { area:'reading' as const, de:'LESEN', zh:'阅读', minutes:65, description:'论坛、新闻/杂志、评论与规定；抓主旨、细节、立场和规则。' },
  { area:'listening' as const, de:'HÖREN', zh:'听力', minutes:40, description:'访谈、讲座、对话和广播观点；抓关键信息与重要细节。' },
  { area:'writing' as const, de:'SCHREIBEN', zh:'写作', minutes:75, description:'社会议题论坛帖：表态并论证；另写一则职业场景正式信息。' },
  { area:'speaking' as const, de:'SPRECHEN', zh:'口语', minutes:15, description:'约 15 分钟口试（通常另有准备时间）：就给定主题短讲，并与搭档讨论、交换论点。' },
]

export const sprintPhases: SprintPhase[] = [
  { id:1, weeks:'W1–4', title:'词汇底盘 + 基础修复', subtitle:'A1/A2 → 可用基础', focus:['FSRS + 教材高频词','核心语法纠错','慢速精听 + 跟读','低负担短输出'] },
  { id:2, weeks:'W5–8', title:'B1 桥接', subtitle:'把“认识”变成连续理解与表达', focus:['段落阅读','日常/广播听力','100–150 词写作','1–2 分钟口头表达'] },
  { id:3, weeks:'W9–12', title:'B2 题型化', subtitle:'四模块进入考试格式', focus:['限时阅读/听力','论坛帖 + 正式信息','短讲 + 讨论','错题归因'] },
  { id:4, weeks:'W13–16', title:'模考收口', subtitle:'稳定跨过每模块 60%，目标留 70% 缓冲', focus:['整套/半套模考','薄弱模块加练','固定表达自动化','时间管理'] },
]

export const weeklyMilestones = [
  '做一次低压力诊断；建立每天都能执行的学习节奏。',
  '把 A1 核心语法漏洞和最基础词形错误集中清掉。',
  '听懂慢速材料主旨，并能用 5–8 句复述。',
  '完成第一阶段复盘：词汇、语法、听读各找出 3 个主要问题。',
  '阅读开始按段落抓论点，不逐词翻译。',
  '听力开始做“先听主旨、再听细节”的两遍训练。',
  '每周至少 2 次连续写作和 2 次口语录音。',
  '用 B1/B2 过渡材料做一次四技能周测。',
  '熟悉 Goethe B2 四模块任务类型与时间限制。',
  '写作固定“立场—理由—例子—让步/反方—结论”骨架。',
  '口语固定 2–3 分钟短讲框架，并练回应搭档观点。',
  '第一次按真实时间做 Goethe 官方 B2 模拟训练。',
  '按模考结果只补最弱的 1–2 个模块，不平均用力。',
  '每周至少一次限时综合训练；把失分原因分类。',
  '目标：四模块模拟分数都稳定 ≥70%，而非偶尔刚过 60%。',
  '减新量、保复习；做最后模考并固定考试当天节奏。',
]

export const b2Chunks = [
  ['观点','Meines Erachtens ...','在我看来……'],['观点','Ich bin der Auffassung, dass ...','我认为……'],['结构','Einerseits ..., andererseits ...','一方面……另一方面……'],['结构','Hinzu kommt, dass ...','此外……'],
  ['论证','Ein wesentlicher Grund dafür ist, dass ...','一个重要原因是……'],['论证','Dafür spricht vor allem, dass ...','支持这一点的主要理由是……'],['论证','Dagegen lässt sich einwenden, dass ...','反过来可以指出……'],['举例','Ein gutes Beispiel dafür ist ...','一个很好的例子是……'],
  ['让步','Zwar ..., jedoch ...','虽然……但是……'],['结论','Zusammenfassend lässt sich sagen, dass ...','总的来说，可以说……'],['讨论','Da stimme ich dir/Ihnen nur teilweise zu.','这一点我只部分同意。'],['讨论','Ich sehe das etwas anders, weil ...','我的看法略有不同，因为……'],
  ['讨论','Was hältst du / halten Sie davon, wenn ...?','如果……你/您觉得如何？'],['口语','Zunächst möchte ich kurz auf ... eingehen.','首先我想简要谈谈……'],['口语','Ein weiterer wichtiger Punkt ist ...','另一个重要方面是……'],['口语','Damit komme ich zum letzten Punkt.','这样我进入最后一点。'],
  ['正式','Ich wende mich an Sie, weil ...','我写信给您是因为……'],['正式','Ich wäre Ihnen dankbar, wenn Sie ...','如果您能……我将非常感谢。'],['正式','Könnten Sie mir bitte mitteilen, ob ...?','能否请您告知是否……？'],['正式','Vielen Dank im Voraus für Ihre Rückmeldung.','预先感谢您的回复。'],
  ['连接','Darüber hinaus ...','除此之外……'],['连接','Im Gegensatz dazu ...','与此相反……'],['连接','Aus diesem Grund ...','出于这个原因……'],['连接','Unter diesen Umständen ...','在这种情况下……'],
  ['比较','Im Vergleich zu ...','与……相比……'],['影响','Das hat zur Folge, dass ...','这会导致……'],['条件','Vorausgesetzt, dass ...','前提是……'],['评价','Problematisch daran ist, dass ...','其中的问题在于……'],
] as const

export function defaultB2TargetDate(days=120) {
  const d=new Date(); d.setHours(12,0,0,0); d.setDate(d.getDate()+days)
  return localDate(d)
}

export function sprintDaysRemaining(target:string,timeZone?:string) {
  if(!target) return 120
  const today=timeZone?localDateInTimeZone(timeZone):localDate(new Date())
  return Math.max(0,dateKeyNumber(target)-dateKeyNumber(today))
}

export function sprintWeek(target:string,timeZone?:string) {
  // The sprint is a 120-day (roughly four-month) runway divided into 16 equal stages.
  // If the exam is already closer than 120 days, start at the corresponding later stage.
  const days=Math.min(120,sprintDaysRemaining(target,timeZone))
  const elapsed=120-days
  return Math.max(1,Math.min(16,Math.floor(elapsed/(120/16))+1))
}

export function sprintPhase(week:number) { return sprintPhases[Math.min(3,Math.max(0,Math.ceil(week/4)-1))] }

export function recommendedDailyNew(level:Settings['b2_current_level'],days:number) {
  const base=level==='A1'?28:level==='A2'?22:level==='B1'?16:12
  return Math.max(8,Math.min(30,base+(days<90?4:days<120?2:0)))
}

export function buildSprintTasks(settings:Settings, sessions:B2PracticeSession[]):SprintTask[]{
  const week=sprintWeek(settings.b2_target_date,settings.timezone)
  const phase=sprintPhase(week).id
  const budget=Math.max(60,settings.b2_daily_minutes)
  const today=localDateInTimeZone(settings.timezone)
  const todayLogs=sessions.filter(x=>x.date===today)
  const completed=new Map<B2TrainingArea,number>()
  for(const log of todayLogs)completed.set(log.area,(completed.get(log.area)||0)+log.minutes)

  const weights = phase===1
    ? settings.b2_current_level==='A1'
      ? {vocabulary:42,grammar:17,reading:10,listening:18,writing:7,speaking:6}
      : {vocabulary:29,grammar:18,reading:14,listening:20,writing:10,speaking:9}
    : phase===2
    ? {vocabulary:21,grammar:12,reading:18,listening:20,writing:15,speaking:14}
    : phase===3
    ? {vocabulary:14,grammar:8,reading:20,listening:20,writing:20,speaking:18}
    : {vocabulary:10,grammar:5,reading:20,listening:20,writing:23,speaking:22}

  const weekday=weekdayInTimeZone(settings.timezone)
  const outputFocus:B2TrainingArea = weekday%2===0?'writing':'speaking'
  weights[outputFocus]+=5
  if(outputFocus==='writing')weights.speaking-=3;else weights.writing-=3

  const recent=sessions.filter(s=>['reading','listening','writing','speaking'].includes(s.area)&&typeof s.score==='number').slice(-24)
  const scoredAreas=(['reading','listening','writing','speaking'] as B2TrainingArea[]).map(area=>{
    const xs=recent.filter(x=>x.area===area&&typeof x.score==='number').slice(-3)
    return {area,score:xs.length?xs.reduce((s,x)=>s+(x.score||0),0)/xs.length:100}
  }).sort((a,b)=>a.score-b.score)
  const weakest=scoredAreas[0]
  if(weakest&&weakest.score<70)weights[weakest.area]+=8
  const total=Object.values(weights).reduce((a,b)=>a+b,0)
  const mins=(area:B2TrainingArea)=>Math.max(10,Math.round(budget*weights[area]/total/5)*5)

  const tasks:SprintTask[]=[
    {id:`${today}:vocab`,area:'vocabulary',title:'FSRS + 教材词汇',detail:`到期复习优先；新词目标约 ${recommendedDailyNew(settings.b2_current_level,sprintDaysRemaining(settings.b2_target_date,settings.timezone))} 个，必须连例句和词形一起学。`,minutes:mins('vocabulary')},
    {id:`${today}:listen`,area:'listening',title:phase<=2?'精听 + 跟读':'B2 听力题型 / 复盘',detail:phase<=2?'一段材料至少两遍：第一遍主旨，第二遍细节；最后跟读或口头复述。':'按题型限时做；错题记录“没听见 / 词不懂 / 逻辑没跟上”。',minutes:mins('listening'),scoreRelevant:phase>=3},
    {id:`${today}:read`,area:'reading',title:phase<=2?'段落阅读':'B2 限时阅读',detail:phase<=2?'先找每段功能与论点，再处理生词；禁止第一遍逐词翻译。':'按 65 分钟整模块的速度切分训练，并记录正确率。',minutes:mins('reading'),scoreRelevant:phase>=3},
    {id:`${today}:grammar`,area:'grammar',title:'语法纠错',detail:phase===1?'只补会造成理解/输出错误的核心语法：语序、格、时态、从句、形容词词尾。':'从今天听读写说的真实错误反推语法，不再铺开背规则。',minutes:mins('grammar')},
    {id:`${today}:writing`,area:'writing',title:phase>=3?'B2 连续写作':phase===1?'句子化输出':'短写作',detail:phase>=3?'做论坛帖或正式信息：先限时完成，再只改结构、语法高频错和表达重复。':phase===1?'写 5–8 句（约 40–60 词）：只要求句子正确、能连起来，并主动用今天的表达块。':'写 80–120 词：观点 + 理由 + 例子，开始建立段落结构。',minutes:mins('writing'),scoreRelevant:phase>=3},
    {id:`${today}:speaking`,area:'speaking',title:phase>=3?'B2 连续口语':phase===1?'短口语 / 跟读后复述':'口头复述 / 表态',detail:phase>=3?'做 2–3 分钟短讲 + 观点回应；录音后只改 3 个最高频错误。':phase===1?'录 45–90 秒：自我介绍、复述或简单表态；允许慢，但不能只默读。':'录 1–2 分钟：复述、表态、给理由，不追求完美。',minutes:mins('speaking'),scoreRelevant:phase>=3},
  ]
  let finalTasks=tasks
  if(phase>=4 && (weekday===0||weekday===6)) {
    const vocab=tasks.find(t=>t.area==='vocabulary')!
    const grammar=tasks.find(t=>t.area==='grammar')!
    const output=tasks.find(t=>t.area===outputFocus)!
    finalTasks=[vocab,{...grammar,minutes:Math.min(grammar.minutes,15)},{id:`${today}:mock`,area:'mock',title:'周末模考',detail:'今天用模考替代常规听读训练。优先做完整模块；若时间不足，至少做两个模块并严格计时。',minutes:Math.min(180,Math.max(90,Math.round(budget*.7/5)*5)),scoreRelevant:true},{...output,minutes:Math.min(output.minutes,30)}]
  }
  return finalTasks.map(task=>({...task,detail:`${task.detail}${task.area!=='mock' && (completed.get(task.area as B2TrainingArea)||0)>=task.minutes?' · 今日已达到建议时长':''}`}))
}

export function moduleStats(sessions:B2PracticeSession[],area:B2TrainingArea){
  const xs=sessions.filter(x=>x.area===area&&typeof x.score==='number').slice(-8)
  const last=xs.at(-1)?.score
  const last3=xs.slice(-3)
  const avg=last3.length?Math.round(last3.reduce((s,x)=>s+(x.score||0),0)/last3.length):undefined
  return {last,avg,count:xs.length}
}

export function dailyChunk(date=new Date()){
  const key=Number(localDate(date).replaceAll('-',''))
  return b2Chunks[key%b2Chunks.length]
}

function localDate(d:Date){
  const y=d.getFullYear();const m=String(d.getMonth()+1).padStart(2,'0');const day=String(d.getDate()).padStart(2,'0')
  return `${y}-${m}-${day}`
}

function dateKeyNumber(key:string){
  const [y,m,d]=key.split('-').map(Number)
  return Math.floor(Date.UTC(y,m-1,d)/86400000)
}

function localDateInTimeZone(timeZone:string){
  return new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())
}

function weekdayInTimeZone(timeZone:string){
  const short=new Intl.DateTimeFormat('en-US',{timeZone,weekday:'short'}).format(new Date())
  return ({Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6} as Record<string,number>)[short] ?? new Date().getDay()
}
