#!/usr/bin/env python3
from __future__ import annotations
import json,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
raw=(ROOT/'src/data/textbook-v13.json').read_bytes()
textbook=json.loads(raw)
app=(ROOT/'src/App.tsx').read_text(encoding='utf-8')
b2=(ROOT/'src/b2.ts').read_text(encoding='utf-8')
goethe=(ROOT/'src/goethe.ts').read_text(encoding='utf-8')
content=(ROOT/'src/content.ts').read_text(encoding='utf-8')
cal=json.loads((ROOT/'src/data/goethe-a1-calibration.json').read_text(encoding='utf-8'))
pkg=json.loads((ROOT/'package.json').read_text())
sw=(ROOT/'public/sw.js').read_text()

assert len(textbook)==4563
assert hashlib.sha256(raw).hexdigest()=='dd64bc897005e5146bee60245a9fda7d40558ccf6e947e06eb9ff2a20ddcb9de'
assert sum(bool(x.get('study_ready')) for x in textbook)==3430
assert len({x['id'] for x in textbook})==4563
assert pkg['version']=='0.1.8'
assert 'deutsch-os-v1-8-shell' in sw
assert len(cal['matched_textbook_entry_ids'])==515
assert len(set(cal['matched_textbook_entry_ids']))==515
assert all(i in {x['id'] for x in textbook} for i in cal['matched_textbook_entry_ids'])
assert 'Goethe A1 官方词表匹配' in goethe
assert "level:'A1'" in goethe and "level:'A2'" in goethe and "level:'B1'" in goethe and "level:'B2'" in goethe
assert len(re.findall(r"id:'(?:a1|a2|b1|b2)-",goethe)) >= 45
assert '不会在 A1 起点时每天硬塞 B2 套话' in app
assert '材料来源与版本说明' in app
assert '只看未获 A1 官方匹配' in app
assert "'sd4-l1-abraten-5': { lemma:'abraten'" in content
assert "praeteritum:'riet ab'" in content and "partizip_ii:'abgeraten'" in content
assert "? {vocabulary:42,grammar:17,reading:10,listening:18,writing:7,speaking:6}" in b2
assert '写 5–8 句（约 40–60 词）' in b2
assert '录 45–90 秒' in b2
assert '<sup>1.8</sup>' in app
assert "version:'1.8'" in app
print('Deutsch OS 1.8 static validation: OK')
print('textbook raw entries=4563, study_ready raw=3430')
print('raw textbook sha256='+hashlib.sha256(raw).hexdigest())
print('Goethe A1 matched textbook entries=515')
print('level-aware Redemittel entries='+str(len(re.findall(r"id:'(?:a1|a2|b1|b2)-",goethe))))
