# Deutsch OS 1.8 — validation record

Release validation performed on 2026-09-01.

## Passed

- Base release is 1.7.2; no 1.7.2 vocabulary / FSRS / B2 practice data model was removed.
- Original textbook JSON integrity: 4563 / 4563 entries unchanged; 3430 raw entries remain `study_ready`.
- Raw `src/data/textbook-v13.json` SHA-256 remains `dd64bc897005e5146bee60245a9fda7d40558ccf6e947e06eb9ff2a20ddcb9de`, identical to 1.7.2.
- Per-book raw counts remain 1162/917, 1270/1032, 976/807, 1155/674 (total / `study_ready`).
- Goethe A1 calibration layer matches 515 textbook entry IDs (483 unique textbook lemmas) against the supplied A1 Wortliste study extract. No A2/B1/B2 item is falsely presented as an official per-word match.
- High-confidence content fixes stay in `src/content.ts`; the raw textbook JSON is not rewritten. The `abraten` entry now corrects the previous `braten` parse and its verb forms.
- Level-aware Redemittel bank contains 53 short original functional expressions across A1/A2/B1/B2; uploaded books are not copied into the deployable project.
- A1 Phase-1 training is vocabulary-first: the weighting gives roughly 40% of the daily budget to FSRS + textbook vocabulary while still keeping listening, grammar, reading and small daily output alive.
- Phase-1 output is deliberately low-load: 5–8 written sentences and a 45–90 second oral task, rather than premature B2 production.
- Current B2 exam dashboard from 1.7.2 is retained: Lesen 65, Hören 40, Schreiben 75, Sprechen 15 minutes; older uploaded B1/B2 books are visibly marked as language-training references rather than current-format authority.
- 16-week B2 milestones, practice logging, module score trends, Supabase RLS design, textbook unit ordering and cross-device FSRS merge logic are retained from 1.7.2.
- Service Worker cache key and package version are 1.8.
- `scripts/validate-v18.py` passes.
- All 14 TS/TSX source files (excluding `.d.ts`) pass TypeScript `transpileModule` syntax diagnostics with TypeScript 5.8.3.

## Deliberate limits

- 1.8 performs a real A1 Wortliste calibration first. A2/B1 official Wortlisten are treated as the next calibration layer rather than being inferred from textbook book number. B2 has no equivalent single official per-word list in this project; B2 remains task/skills driven.
- Goethe A1 matching is an automated lemma/reference match against the supplied A1 study extract. It is a calibration aid, not a claim that every sense, inflection or example in the textbook has been individually certified by Goethe.
- Uploaded copyrighted preparation books are used to identify training functions, themes and appropriate staging. Their full text, exercises and answer keys are not packaged into Deutsch OS.

## Build-environment caveat

This sandbox does not have the project npm dependencies cached and cannot resolve the npm registry from the container. Therefore a dependency-resolved `npm run check` / `npm run build` could not be completed here. The source-level TypeScript syntax diagnostics above do not replace the first real Cloudflare build. The first Pages deployment should still be treated as the final dependency/build-environment verification.
